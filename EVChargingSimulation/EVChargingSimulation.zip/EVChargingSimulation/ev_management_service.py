"""
EV Management Service
Backend service to handle EV management requests from JavaFX frontend
"""

import json
import socket
import threading
import time
from datetime import datetime, timedelta
from ev_input_manager import EVInputManager

class EVManagementService:
    def __init__(self, port=8766):
        self.port = port
        self.running = False
        self.server_socket = None
        self.ev_manager = EVInputManager()
        self.clients = []
        
    def start_service(self):
        """Start the EV management service"""
        try:
            self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.server_socket.bind(('localhost', self.port))
            self.server_socket.listen(5)
            self.running = True
            
            print(f"🔧 EV Management Service listening on port {self.port}")
            
            while self.running:
                try:
                    client_socket, address = self.server_socket.accept()
                    print(f"🔗 EV Management client connected: {address}")
                    
                    # Handle client in separate thread
                    client_thread = threading.Thread(
                        target=self.handle_client,
                        args=(client_socket, address),
                        daemon=True
                    )
                    client_thread.start()
                    
                except Exception as e:
                    if self.running:
                        print(f"❌ Error accepting EV management client: {e}")
                        
        except Exception as e:
            print(f"❌ EV Management Service error: {e}")
            
    def handle_client(self, client_socket, address):
        """Handle individual client requests"""
        try:
            self.clients.append(client_socket)
            
            while self.running:
                try:
                    # Receive request
                    data = client_socket.recv(4096)
                    if not data:
                        break
                        
                    request_str = data.decode('utf-8').strip()
                    if not request_str:
                        continue
                        
                    # Parse JSON request
                    try:
                        request = json.loads(request_str)
                        response = self.process_request(request)
                        
                        # Send response
                        response_str = json.dumps(response) + "\n"
                        client_socket.send(response_str.encode('utf-8'))
                        
                    except json.JSONDecodeError as e:
                        error_response = {
                            "status": "error",
                            "message": f"Invalid JSON: {e}"
                        }
                        response_str = json.dumps(error_response) + "\n"
                        client_socket.send(response_str.encode('utf-8'))
                        
                except socket.timeout:
                    continue
                except Exception as e:
                    print(f"❌ Error handling EV management request: {e}")
                    break
                    
        except Exception as e:
            print(f"❌ EV Management client handler error for {address}: {e}")
        finally:
            if client_socket in self.clients:
                self.clients.remove(client_socket)
            client_socket.close()
            print(f"🔗 EV Management client disconnected: {address}")
            
    def process_request(self, request):
        """Process different types of requests"""
        try:
            command = request.get("command", "")
            
            if command == "add_ev":
                return self.handle_add_ev(request)
            elif command == "list_evs":
                return self.handle_list_evs()
            elif command == "clear_evs":
                return self.handle_clear_evs()
            elif command == "get_stats":
                return self.handle_get_stats()
            elif command == "reload_evs":
                return self.handle_reload_evs()
            else:
                return {
                    "status": "error",
                    "message": f"Unknown command: {command}"
                }
                
        except Exception as e:
            return {
                "status": "error",
                "message": f"Error processing request: {e}"
            }
            
    def handle_add_ev(self, request):
        """Handle add EV request"""
        try:
            data = request.get("data", {})
            print(f"🔍 DEBUG: Received data: {data}")
              # Extract EV data with better error handling
            arrival_date = data.get("arrivalDate", "")
            arrival_time = data.get("arrivalTime", "")
            departure_date = data.get("departureDate", "")
            departure_time = data.get("departureTime", "")
            
            print(f"🔍 DEBUG: Times - Arrival: {arrival_date} {arrival_time}, Departure: {departure_date} {departure_time}")
            
            # Handle energy separately with better error handling
            try:
                energy = float(data.get("energy", 0))
                print(f"🔍 DEBUG: Energy: {energy}")
            except (ValueError, TypeError) as e:
                print(f"❌ DEBUG: Energy parsing error: {e}")
                return {
                    "status": "error",
                    "message": f"Invalid energy value: {data.get('energy')}. Must be a number."
                }
            
            # Validate data
            if not all([arrival_date, arrival_time, departure_date, departure_time]):
                missing_fields = []
                if not arrival_date: missing_fields.append("arrivalDate")
                if not arrival_time: missing_fields.append("arrivalTime") 
                if not departure_date: missing_fields.append("departureDate")
                if not departure_time: missing_fields.append("departureTime")
                
                return {
                    "status": "error",
                    "message": f"Missing fields: {', '.join(missing_fields)}"
                }
                
            if energy <= 0:
                return {
                    "status": "error", 
                    "message": f"Energy must be positive, received: {energy}"
                }
                  # Parse datetime
            arrival_datetime = datetime.strptime(f"{arrival_date} {arrival_time}", "%Y-%m-%d %H:%M")
            departure_datetime = datetime.strptime(f"{departure_date} {departure_time}", "%Y-%m-%d %H:%M")
            
            # Validate that departure is after arrival
            if departure_datetime <= arrival_datetime:
                return {
                    "status": "error",
                    "message": "Departure time must be after arrival time"
                }
              # Add EV using EV manager
            ev_id = self.ev_manager.add_custom_ev(
                connection_time=arrival_datetime,
                disconnect_time=departure_datetime,
                kwh_delivered=energy
            )
            
            return {
                "status": "success",
                "message": f"EV added successfully with ID: {ev_id}",
                "ev_id": ev_id,
                "total_custom_evs": len(self.ev_manager.custom_evs)
            }
            
        except Exception as e:
            return {
                "status": "error",
                "message": f"Error adding EV: {e}"
            }
            
    def handle_list_evs(self):
        """Handle list EVs request"""
        try:
            evs = []
            for ev in self.ev_manager.custom_evs:
                arrival = datetime.strptime(ev['connectionTime'], "%a, %d %b %Y %H:%M:%S GMT")
                departure = datetime.strptime(ev['disconnectTime'], "%a, %d %b %Y %H:%M:%S GMT")
                
                evs.append({
                    "sessionID": ev['sessionID'],
                    "arrivalTime": arrival.strftime("%Y-%m-%d %H:%M"),
                    "departureTime": departure.strftime("%Y-%m-%d %H:%M"),
                    "energyNeeded": ev['kWhDelivered']
                })
                
            return {
                "status": "success",
                "evs": evs,
                "total": len(evs)
            }
            
        except Exception as e:
            return {
                "status": "error",
                "message": f"Error listing EVs: {e}"
            }
            
    def handle_clear_evs(self):
        """Handle clear EVs request"""
        try:
            count = len(self.ev_manager.custom_evs)
            self.ev_manager.clear_all_custom_evs()
            
            return {
                "status": "success",
                "message": f"Cleared {count} custom EVs",
                "cleared_count": count
            }
            
        except Exception as e:
            return {
                "status": "error",
                "message": f"Error clearing EVs: {e}"
            }
            
    def handle_get_stats(self):
        """Handle get stats request"""
        try:
            return {
                "status": "success",
                "stats": {
                    "total_custom_evs": len(self.ev_manager.custom_evs),
                    "service_running": self.running,
                    "connected_clients": len(self.clients)
                }
            }
            
        except Exception as e:
            return {
                "status": "error",
                "message": f"Error getting stats: {e}"
            }
            
    def handle_reload_evs(self):
        """Handle reload custom EVs request"""
        try:
            # Reload custom EVs from file
            old_count = len(self.ev_manager.custom_evs)
            self.ev_manager.load_custom_evs()
            new_count = len(self.ev_manager.custom_evs)
            
            return {
                "status": "success",
                "message": f"Reloaded custom EVs: {new_count} total EVs (was {old_count})",
                "old_count": old_count,
                "new_count": new_count
            }
            
        except Exception as e:
            print(f"❌ Error reloading custom EVs: {e}")
            return {
                "status": "error",
                "message": f"Error reloading custom EVs: {e}"
            }

    def stop_service(self):
        """Stop the EV management service"""
        self.running = False
        if self.server_socket:
            self.server_socket.close()
        for client in self.clients:
            client.close()
        self.clients.clear()
        print("🛑 EV Management Service stopped")

def start_ev_management_service():
    """Start EV management service in separate thread"""
    service = EVManagementService()
    service_thread = threading.Thread(target=service.start_service, daemon=True)
    service_thread.start()
    return service

if __name__ == "__main__":
    # Test the service
    service = EVManagementService()
    try:
        service.start_service()
    except KeyboardInterrupt:
        print("\n🛑 Stopping EV Management Service...")
        service.stop_service()
