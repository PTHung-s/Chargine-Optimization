"""
Dual Charging Monitor UI - Optimization vs FCFS
Displays both optimization-based and FCFS charging systems side by side
"""

import tkinter as tk
from tkinter import ttk, scrolledtext
import threading
import queue
import time
from datetime import datetime, timedelta
import socket
import json

class DualChargingUI:
    def __init__(self, session_manager, simulation_clock, fcfs_manager):
        self.session_manager = session_manager
        self.simulation_clock = simulation_clock
        self.fcfs_manager = fcfs_manager
        
        self.root = tk.Tk()
        self.root.title("EV Charging Monitor - Optimization vs FCFS")
        self.root.geometry("1800x1000")
        self.root.configure(bg='#2c3e50')
        
        # Data containers
        self.optimization_data = {}
        self.fcfs_data = {}
        
        # Update interval (ms)
        self.update_interval = 500
        
        # Create UI
        self.create_widgets()
        
        # Start update loop
        self.update_display()
        
    def create_widgets(self):
        """Create the UI components"""
        
        # Header
        header_frame = tk.Frame(self.root, bg='#34495e', height=80)
        header_frame.pack(fill=tk.X, padx=5, pady=5)
        header_frame.pack_propagate(False)
        
        title = tk.Label(
            header_frame,
            text="🔋 EV Charging Monitor - Optimization vs FCFS",
            font=("Arial", 24, "bold"),
            bg='#34495e',
            fg='#ecf0f1'
        )
        title.pack(pady=15)
        
        # Status bar
        status_frame = tk.Frame(self.root, bg='#2c3e50')
        status_frame.pack(fill=tk.X, padx=5, pady=(0, 10))
        
        # Time display
        self.time_label = tk.Label(
            status_frame,
            text="Simulation Time: --:--:--",
            font=("Arial", 16, "bold"),
            bg='#2c3e50',
            fg='#3498db'
        )
        self.time_label.pack(side=tk.LEFT, padx=10)
        
        # Speed control
        speed_control_frame = tk.Frame(status_frame, bg='#2c3e50')
        speed_control_frame.pack(side=tk.RIGHT, padx=10)
        
        tk.Label(
            speed_control_frame,
            text="Speed:",
            font=("Arial", 12),
            bg='#2c3e50',
            fg='#95a5a6'
        ).pack(side=tk.LEFT, padx=(0, 5))
        
        self.speed_var = tk.DoubleVar(value=10.0)
        self.speed_scale = tk.Scale(
            speed_control_frame,
            from_=1,
            to=1000,
            orient=tk.HORIZONTAL,
            variable=self.speed_var,
            command=self.on_speed_change,
            length=150,
            bg='#34495e',
            fg='#ecf0f1',
            highlightbackground='#2c3e50',
            troughcolor='#2c3e50'
        )
        self.speed_scale.pack(side=tk.LEFT, padx=5)
        
        self.speed_label = tk.Label(
            speed_control_frame,
            text="10x",
            font=("Arial", 14, "bold"),
            bg='#2c3e50',
            fg='#e74c3c',
            width=5
        )
        self.speed_label.pack(side=tk.LEFT, padx=(5, 0))
        
        # Main content area - Split into two columns
        main_frame = tk.Frame(self.root, bg='#2c3e50')
        main_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Left column - Optimization System
        self.left_frame = tk.LabelFrame(
            main_frame,
            text="🎯 Optimization-Based Charging",
            font=("Arial", 14, "bold"),
            bg='#34495e',
            fg='#3498db',
            relief=tk.RAISED,
            bd=2
        )
        self.left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 5))
        
        # Right column - FCFS System
        self.right_frame = tk.LabelFrame(
            main_frame,
            text="🚗 First-Come-First-Serve (FCFS)",
            font=("Arial", 14, "bold"),
            bg='#34495e',
            fg='#e74c3c',
            relief=tk.RAISED,
            bd=2
        )
        self.right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(5, 0))
        
        # Create content for both columns
        self.create_optimization_panel()
        self.create_fcfs_panel()
        
    def create_optimization_panel(self):
        """Create the optimization system panel"""
        # Statistics
        stats_frame = tk.Frame(self.left_frame, bg='#34495e')
        stats_frame.pack(fill=tk.X, padx=10, pady=10)
        
        tk.Label(
            stats_frame,
            text="📊 Optimization Statistics",
            font=("Arial", 12, "bold"),
            bg='#34495e',
            fg='#ecf0f1'
        ).pack(anchor=tk.W)
        
        self.opt_stats_frame = tk.Frame(stats_frame, bg='#2c3e50')
        self.opt_stats_frame.pack(fill=tk.X, pady=5)
        
        # Create optimization statistics labels
        self.opt_stats_labels = {}
        stats_info = [
            ("Active EVs", "active_evs"),
            ("Charging", "currently_charging"),
            ("Completed", "completed_sessions"),
            ("Total Energy", "total_energy_delivered"),
            ("Avg Power", "average_power"),
            ("Total Power", "total_power")
        ]
        
        for i, (label_text, key) in enumerate(stats_info):
            row = i // 2
            col = i % 2
            
            label_frame = tk.Frame(self.opt_stats_frame, bg='#2c3e50')
            label_frame.grid(row=row, column=col, sticky="ew", padx=5, pady=2)
            
            tk.Label(
                label_frame,
                text=f"{label_text}:",
                font=("Arial", 10),
                bg='#2c3e50',
                fg='#95a5a6',
                anchor=tk.W,
                width=12
            ).pack(side=tk.LEFT)
            
            value_label = tk.Label(
                label_frame,
                text="--",
                font=("Arial", 10, "bold"),
                bg='#2c3e50',
                fg='#3498db',
                anchor=tk.W,
                width=10
            )
            value_label.pack(side=tk.LEFT)
            self.opt_stats_labels[key] = value_label
            
        # Configure grid weights
        self.opt_stats_frame.grid_columnconfigure(0, weight=1)
        self.opt_stats_frame.grid_columnconfigure(1, weight=1)
        
        # EV Table
        table_frame = tk.Frame(self.left_frame, bg='#34495e')
        table_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))
        
        tk.Label(
            table_frame,
            text="🚗 Active EVs (Optimization)",
            font=("Arial", 12, "bold"),
            bg='#34495e',
            fg='#ecf0f1'
        ).pack(anchor=tk.W)
        
        # Create treeview for optimization
        columns = ("ID", "Arrival", "Departure", "Needed", "Progress", "Power", "Station", "Status")
        self.opt_tree = ttk.Treeview(table_frame, columns=columns, show="headings", height=12)
        
        # Configure columns
        column_configs = [
            ("ID", 80, "EV ID"),
            ("Arrival", 60, "Arrival"),
            ("Departure", 60, "Departure"),
            ("Needed", 60, "Needed"),
            ("Progress", 70, "Progress"),
            ("Power", 60, "Power"),
            ("Station", 70, "Station"),
            ("Status", 80, "Status")
        ]
        
        for col, width, heading in column_configs:
            self.opt_tree.heading(col, text=heading, anchor=tk.W)
            self.opt_tree.column(col, width=width, anchor=tk.CENTER)
        
        # Scrollbar for optimization table
        opt_scrollbar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=self.opt_tree.yview)
        self.opt_tree.configure(yscroll=opt_scrollbar.set)
        
        self.opt_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, pady=5)
        opt_scrollbar.pack(side=tk.RIGHT, fill=tk.Y, pady=5)
        
    def create_fcfs_panel(self):
        """Create the FCFS system panel"""
        # Statistics
        stats_frame = tk.Frame(self.right_frame, bg='#34495e')
        stats_frame.pack(fill=tk.X, padx=10, pady=10)
        
        tk.Label(
            stats_frame,
            text="📊 FCFS Statistics",
            font=("Arial", 12, "bold"),
            bg='#34495e',
            fg='#ecf0f1'
        ).pack(anchor=tk.W)
        
        self.fcfs_stats_frame = tk.Frame(stats_frame, bg='#2c3e50')
        self.fcfs_stats_frame.pack(fill=tk.X, pady=5)
        
        # Create FCFS statistics labels
        self.fcfs_stats_labels = {}
        stats_info = [
            ("Active EVs", "active_evs"),
            ("Charging", "currently_charging"),
            ("In Queue", "waiting_in_queue"),
            ("Total Energy", "total_energy_delivered"),
            ("Avg Power", "average_power"),
            ("Power Usage", "power_utilization")
        ]
        
        for i, (label_text, key) in enumerate(stats_info):
            row = i // 2
            col = i % 2
            
            label_frame = tk.Frame(self.fcfs_stats_frame, bg='#2c3e50')
            label_frame.grid(row=row, column=col, sticky="ew", padx=5, pady=2)
            
            tk.Label(
                label_frame,
                text=f"{label_text}:",
                font=("Arial", 10),
                bg='#2c3e50',
                fg='#95a5a6',
                anchor=tk.W,
                width=12
            ).pack(side=tk.LEFT)
            
            value_label = tk.Label(
                label_frame,
                text="--",
                font=("Arial", 10, "bold"),
                bg='#2c3e50',
                fg='#e74c3c',
                anchor=tk.W,
                width=10
            )
            value_label.pack(side=tk.LEFT)
            self.fcfs_stats_labels[key] = value_label
            
        # Configure grid weights
        self.fcfs_stats_frame.grid_columnconfigure(0, weight=1)
        self.fcfs_stats_frame.grid_columnconfigure(1, weight=1)
        
        # EV Table
        table_frame = tk.Frame(self.right_frame, bg='#34495e')
        table_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))
        
        tk.Label(
            table_frame,
            text="🚗 Active EVs (FCFS)",
            font=("Arial", 12, "bold"),
            bg='#34495e',
            fg='#ecf0f1'
        ).pack(anchor=tk.W)
        
        # Create treeview for FCFS
        columns = ("ID", "Arrival", "Departure", "Needed", "Progress", "Power", "Station", "Status")
        self.fcfs_tree = ttk.Treeview(table_frame, columns=columns, show="headings", height=12)
        
        # Configure columns
        column_configs = [
            ("ID", 80, "EV ID"),
            ("Arrival", 60, "Arrival"),
            ("Departure", 60, "Departure"),
            ("Needed", 60, "Needed"),
            ("Progress", 70, "Progress"),
            ("Power", 60, "Power"),
            ("Station", 70, "Station"),
            ("Status", 80, "Status")
        ]
        
        for col, width, heading in column_configs:
            self.fcfs_tree.heading(col, text=heading, anchor=tk.W)
            self.fcfs_tree.column(col, width=width, anchor=tk.CENTER)
        
        # Scrollbar for FCFS table
        fcfs_scrollbar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=self.fcfs_tree.yview)
        self.fcfs_tree.configure(yscroll=fcfs_scrollbar.set)
        
        self.fcfs_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, pady=5)
        fcfs_scrollbar.pack(side=tk.RIGHT, fill=tk.Y, pady=5)
        
    def on_speed_change(self, value):
        """Handle speed slider change"""
        speed = float(value)
        self.simulation_clock.set_speed(speed)
        self.speed_label.config(text=f"{speed:.0f}x")
        
    def collect_optimization_data(self):
        """Collect data from optimization system"""
        try:
            current_time = self.simulation_clock.get_current_time()
            active_sessions = self.session_manager.active_sessions
            completed_sessions = self.session_manager.completed_sessions
            
            # Collect EV data
            ev_data = []
            for session in active_sessions:
                needed = session['kWhDelivered']
                delivered = session.get('energy_delivered', 0.0)
                remaining = session.get('remaining_energy', needed)
                power = session.get('current_charging_power', 0.0)
                progress = min((delivered / needed) * 100, 100) if needed > 0 else 100
                
                # Get station assignment
                station_id = self.get_station_assignment(session['sessionID'])
                
                # Determine status
                if progress >= 99.9:
                    status = "COMPLETED"
                elif power > 0.1:
                    status = "CHARGING"
                else:
                    status = "WAITING"
                    
                ev_data.append({
                    "id": session['sessionID'][:12],
                    "arrival_time": session['connectionTime_dt'].strftime('%H:%M'),
                    "departure_time": session['disconnectTime_dt'].strftime('%H:%M'),
                    "energy_needed": round(needed, 1),
                    "progress_percent": round(progress, 1),
                    "current_power": round(power, 1),
                    "station_id": station_id,
                    "status": status
                })
                
            # Collect statistics
            charging_sessions = [s for s in active_sessions if s.get('current_charging_power', 0) > 0.1]
            total_energy = sum(session.get('energy_delivered', 0) for session in active_sessions + completed_sessions)
            avg_power = sum(s.get('current_charging_power', 0) for s in charging_sessions) / max(1, len(charging_sessions))
            
            statistics = {
                "active_evs": len(active_sessions),
                "completed_sessions": len(completed_sessions),
                "currently_charging": len(charging_sessions),
                "total_energy_delivered": round(total_energy, 1),
                "average_power": round(avg_power, 1),
                "total_power": round(sum(s.get('current_charging_power', 0) for s in active_sessions), 1)
            }
            
            return {
                "evs": ev_data,
                "statistics": statistics,
                "simulation_time": current_time.strftime('%Y-%m-%d %H:%M:%S')
            }
            
        except Exception as e:
            print(f"❌ Error collecting optimization data: {e}")
            return None
            
    def get_station_assignment(self, session_id):
        """Get station assignment for optimization system"""
        try:
            if hasattr(self.session_manager, 'station_manager'):
                station_manager = self.session_manager.station_manager
                station_id = station_manager.get_station_assignment(session_id)
                return station_id if station_id else "Waiting"
            else:
                # Fallback
                hash_val = hash(session_id) % 5 + 1
                return f"Station_{hash_val}"
        except:
            return "Unknown"
            
    def collect_fcfs_data(self):
        """Collect data from FCFS system"""
        try:
            return {
                "evs": self.fcfs_manager.get_active_sessions(),
                "statistics": self.fcfs_manager.get_statistics(),
                "simulation_time": self.simulation_clock.get_current_time().strftime('%Y-%m-%d %H:%M:%S')
            }
        except Exception as e:
            print(f"❌ Error collecting FCFS data: {e}")
            return None
            
    def update_optimization_display(self, data):
        """Update optimization panel display"""
        if not data:
            return
            
        # Update statistics
        stats = data.get('statistics', {})
        for key, label in self.opt_stats_labels.items():
            value = stats.get(key, 0)
            if key in ['total_energy_delivered', 'average_power', 'total_power']:
                label.config(text=f"{value} kW")
            else:
                label.config(text=str(value))
                
        # Update EV table
        for item in self.opt_tree.get_children():
            self.opt_tree.delete(item)
            
        for ev in data.get('evs', []):
            self.opt_tree.insert('', 'end', values=(
                ev['id'],
                ev['arrival_time'],
                ev['departure_time'],
                f"{ev['energy_needed']} kWh",
                f"{ev['progress_percent']}%",
                f"{ev['current_power']} kW",
                ev['station_id'],
                ev['status']
            ))
            
    def update_fcfs_display(self, data):
        """Update FCFS panel display"""
        if not data:
            return
            
        # Update statistics
        stats = data.get('statistics', {})
        for key, label in self.fcfs_stats_labels.items():
            value = stats.get(key, 0)
            if key in ['total_energy_delivered', 'average_power']:
                label.config(text=f"{value} kW")
            elif key == 'power_utilization':
                label.config(text=f"{value}%")
            else:
                label.config(text=str(value))
                
        # Update EV table
        for item in self.fcfs_tree.get_children():
            self.fcfs_tree.delete(item)
            
        for ev in data.get('evs', []):
            self.fcfs_tree.insert('', 'end', values=(
                ev['id'],
                ev['arrival_time'],
                ev['departure_time'],
                f"{ev['energy_needed']} kWh",                f"{ev['progress_percent']}%",
                f"{ev['current_power']} kW",
                ev['station_id'],
                ev['status']
            ))
            
    def update_display(self):
        """Update the display with current data"""
        try:
            # Manually tick simulation clock
            self.simulation_clock.tick()
            
            # Update time display
            current_time = self.simulation_clock.get_current_time()
            self.time_label.config(text=f"Simulation Time: {current_time.strftime('%Y-%m-%d %H:%M:%S')}")
            
            # Update speed display
            speed = self.simulation_clock.speed_multiplier
            self.speed_var.set(speed)
            self.speed_label.config(text=f"{speed:.0f}x")
            
            # Collect and update optimization data
            opt_data = self.collect_optimization_data()
            self.update_optimization_display(opt_data)
            
            # Collect and update FCFS data
            fcfs_data = self.collect_fcfs_data()
            self.update_fcfs_display(fcfs_data)
            
        except Exception as e:
            print(f"❌ Display update error: {e}")
            
        # Schedule next update
        self.root.after(self.update_interval, self.update_display)
        
    def run(self):
        """Start the UI"""
        print("🚀 Starting Dual Charging Monitor UI...")
        self.root.mainloop()
        
    def destroy(self):
        """Cleanup and destroy the UI"""
        self.root.destroy()
