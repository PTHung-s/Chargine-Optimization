"""
Charging Monitor UI - Real-time EV Charging Status Display
A simple GUI to monitor EV charging progress in real-time
"""

import tkinter as tk
from tkinter import ttk, scrolledtext
import threading
import time
from datetime import datetime
from main import main as run_simulation
import queue

class ChargingMonitorUI:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("EV Charging Monitor - Real-time Status")
        self.root.geometry("1200x800")
        self.root.configure(bg='#f0f0f0')
        
        # Queue for thread-safe communication
        self.status_queue = queue.Queue()
        self.simulation_running = False
        self.simulation_thread = None
        
        # Create UI components
        self.create_widgets()
        
        # Start status update loop
        self.update_display()
        
    def create_widgets(self):
        """Create the main UI components"""
        
        # Title
        title_label = tk.Label(
            self.root, 
            text="🔋 EV Charging Monitor", 
            font=("Arial", 20, "bold"),
            bg='#f0f0f0',
            fg='#2c3e50'
        )
        title_label.pack(pady=10)
        
        # Control buttons frame
        control_frame = tk.Frame(self.root, bg='#f0f0f0')
        control_frame.pack(pady=5)
        
        # Start/Stop simulation button
        self.start_button = tk.Button(
            control_frame,
            text="🚀 Start Simulation",
            command=self.toggle_simulation,
            font=("Arial", 12, "bold"),
            bg='#27ae60',
            fg='white',
            padx=20,
            pady=5
        )
        self.start_button.pack(side=tk.LEFT, padx=5)
        
        # Speed control
        speed_frame = tk.Frame(control_frame, bg='#f0f0f0')
        speed_frame.pack(side=tk.LEFT, padx=20)
        
        tk.Label(speed_frame, text="Speed:", font=("Arial", 10), bg='#f0f0f0').pack(side=tk.LEFT)
        self.speed_var = tk.StringVar(value="10")
        speed_spinbox = tk.Spinbox(
            speed_frame,
            from_=1, to=100,
            textvariable=self.speed_var,
            width=5,
            font=("Arial", 10)
        )
        speed_spinbox.pack(side=tk.LEFT, padx=5)
        tk.Label(speed_frame, text="x", font=("Arial", 10), bg='#f0f0f0').pack(side=tk.LEFT)
        
        # Current time display
        self.time_label = tk.Label(
            self.root,
            text="Simulation Time: Not Started",
            font=("Arial", 14, "bold"),
            bg='#f0f0f0',
            fg='#34495e'
        )
        self.time_label.pack(pady=5)
        
        # Create main content frame with scrollbar
        main_frame = tk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        # EV Status Table
        self.create_ev_table(main_frame)
        
        # Log area
        self.create_log_area(main_frame)
        
    def create_ev_table(self, parent):
        """Create the EV status table"""
        table_frame = tk.LabelFrame(parent, text="🚗 Active EVs - Charging Status", font=("Arial", 12, "bold"))
        table_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Create Treeview
        columns = ("ID", "Arrival", "Departure", "Energy Needed", "Energy Delivered", "Remaining", "Progress", "Charging Power", "Status")
        self.ev_tree = ttk.Treeview(table_frame, columns=columns, show="headings", height=12)
        
        # Define column headings and widths
        column_configs = {
            "ID": ("EV ID", 120),
            "Arrival": ("Arrival Time", 100),
            "Departure": ("Departure Time", 100),
            "Energy Needed": ("Needed (kWh)", 100),
            "Energy Delivered": ("Delivered (kWh)", 110),
            "Remaining": ("Remaining (kWh)", 110),
            "Progress": ("Progress (%)", 80),
            "Charging Power": ("Power (kW)", 100),
            "Status": ("Status", 100)
        }
        
        for col, (heading, width) in column_configs.items():
            self.ev_tree.heading(col, text=heading)
            self.ev_tree.column(col, width=width, anchor="center")
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=self.ev_tree.yview)
        self.ev_tree.configure(yscrollcommand=scrollbar.set)
        
        self.ev_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
    def create_log_area(self, parent):
        """Create the log display area"""
        log_frame = tk.LabelFrame(parent, text="📝 Simulation Log", font=("Arial", 12, "bold"))
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        self.log_text = scrolledtext.ScrolledText(
            log_frame,
            height=8,
            font=("Consolas", 9),
            bg='#2c3e50',
            fg='#ecf0f1'
        )
        self.log_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
    def toggle_simulation(self):
        """Start or stop the simulation"""
        if not self.simulation_running:
            self.start_simulation()
        else:
            self.stop_simulation()
            
    def start_simulation(self):
        """Start the simulation in a separate thread"""
        self.simulation_running = True
        self.start_button.config(text="⏹️ Stop Simulation", bg='#e74c3c')
        
        # Start simulation thread
        self.simulation_thread = threading.Thread(target=self.run_simulation_thread, daemon=True)
        self.simulation_thread.start()
        
        self.log_message("🚀 Simulation started!")
        
    def stop_simulation(self):
        """Stop the simulation"""
        self.simulation_running = False
        self.start_button.config(text="🚀 Start Simulation", bg='#27ae60')
        self.log_message("⏹️ Simulation stopped!")
        
    def run_simulation_thread(self):
        """Run the simulation in a separate thread"""
        try:
            # This would integrate with your main simulation
            # For now, we'll simulate some data
            self.simulate_charging_data()
        except Exception as e:
            self.log_message(f"❌ Simulation error: {str(e)}")
            
    def simulate_charging_data(self):
        """Simulate charging data for demo purposes"""
        # Sample EV data
        sample_evs = [
            {"id": "EV001", "arrival": "08:00", "departure": "17:00", "needed": 45.5},
            {"id": "EV002", "arrival": "08:15", "departure": "16:30", "needed": 32.8},
            {"id": "EV003", "arrival": "09:00", "departure": "18:00", "needed": 58.2},
            {"id": "EV004", "arrival": "09:30", "departure": "15:45", "needed": 28.5},
            {"id": "EV005", "arrival": "10:00", "departure": "19:00", "needed": 41.7},
        ]
        
        # Initialize EVs
        for ev in sample_evs:
            ev["delivered"] = 0.0
            ev["power"] = 0.0
            ev["charging"] = False
            
        sim_time = datetime.now().replace(hour=8, minute=0, second=0, microsecond=0)
        
        while self.simulation_running:
            # Update simulation time
            time_str = sim_time.strftime("%Y-%m-%d %H:%M:%S")
            self.status_queue.put(("time", time_str))
            
            # Update EV charging
            for ev in sample_evs:
                if ev["delivered"] < ev["needed"]:
                    # Simulate charging
                    if ev["power"] == 0:
                        ev["power"] = min(50, (ev["needed"] - ev["delivered"]) * 2)  # Random power
                        ev["charging"] = True
                    
                    # Increment energy
                    increment = ev["power"] * (1/3600)  # Per second
                    ev["delivered"] = min(ev["needed"], ev["delivered"] + increment)
                    
                    if ev["delivered"] >= ev["needed"]:
                        ev["power"] = 0
                        ev["charging"] = False
                else:
                    ev["power"] = 0
                    ev["charging"] = False
            
            # Send data to UI
            self.status_queue.put(("evs", sample_evs.copy()))
            
            # Advance time
            sim_time = sim_time.replace(second=sim_time.second + 1)
            
            time.sleep(0.1)  # 100ms update rate
            
    def update_display(self):
        """Update the display with new data from the queue"""
        try:
            while not self.status_queue.empty():
                msg_type, data = self.status_queue.get_nowait()
                
                if msg_type == "time":
                    self.time_label.config(text=f"Simulation Time: {data}")
                    
                elif msg_type == "evs":
                    self.update_ev_table(data)
                    
                elif msg_type == "log":
                    self.log_message(data)
                    
        except queue.Empty:
            pass
            
        # Schedule next update
        self.root.after(100, self.update_display)
        
    def update_ev_table(self, evs):
        """Update the EV table with current data"""
        # Clear existing items
        for item in self.ev_tree.get_children():
            self.ev_tree.delete(item)
            
        # Add current EVs
        for ev in evs:
            remaining = ev["needed"] - ev["delivered"]
            progress = (ev["delivered"] / ev["needed"]) * 100 if ev["needed"] > 0 else 0
            
            if progress >= 100:
                status = "✅ Complete"
                status_color = "green"
            elif ev.get("charging", False):
                status = "⚡ Charging"
                status_color = "blue"
            else:
                status = "⏸️ Waiting"
                status_color = "orange"
                
            values = (
                ev["id"],
                ev["arrival"],
                ev["departure"],
                f"{ev['needed']:.1f}",
                f"{ev['delivered']:.1f}",
                f"{remaining:.1f}",
                f"{progress:.1f}%",
                f"{ev['power']:.1f}",
                status
            )
            
            item = self.ev_tree.insert("", "end", values=values)
            
            # Color coding based on status
            if progress >= 100:
                self.ev_tree.set(item, "Progress", "🟢 100%")
            elif progress >= 75:
                self.ev_tree.set(item, "Progress", f"🟡 {progress:.1f}%")
            elif progress >= 25:
                self.ev_tree.set(item, "Progress", f"🟠 {progress:.1f}%")
            else:
                self.ev_tree.set(item, "Progress", f"🔴 {progress:.1f}%")
                
    def log_message(self, message):
        """Add a message to the log"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        formatted_message = f"[{timestamp}] {message}\n"
        
        self.log_text.insert(tk.END, formatted_message)
        self.log_text.see(tk.END)
        
        # Limit log size
        lines = self.log_text.get("1.0", tk.END).split('\n')
        if len(lines) > 100:
            self.log_text.delete("1.0", "10.0")
            
    def run(self):
        """Start the UI"""
        self.log_message("🔋 EV Charging Monitor initialized")
        self.log_message("Click 'Start Simulation' to begin monitoring")
        self.root.mainloop()

if __name__ == "__main__":
    app = ChargingMonitorUI()
    app.run()
