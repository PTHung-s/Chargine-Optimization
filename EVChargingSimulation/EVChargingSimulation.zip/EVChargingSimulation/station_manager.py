"""
Station Manager Module
Manages persistent charging station assignments for EV sessions
"""

from datetime import datetime, timedelta

class StationManager:    
    def __init__(self, max_stations=50):
        """
        Initialize station manager
        
        Args:
            max_stations: Maximum number of charging stations available
        """
        self.max_stations = max_stations
        self.station_assignments = {}  # session_id -> station_id mapping
        self.station_occupancy = {}    # station_id -> session_id mapping (reverse lookup)
        
        # Create both legacy stations and OPT stations for compatibility
        self.station_availability = {}
        
        # Create OPT stations (primary for optimization algorithm)
        for i in range(1, 21):  # 20 OPT stations
            station_id = f'OPT_Station_{i}'
            self.station_availability[station_id] = None
            
        # Create legacy stations for backward compatibility
        for i in range(1, min(max_stations + 1, 21)):  # Up to 20 legacy stations            station_id = f'Station_{i}'
            self.station_availability[station_id] = None
        
    def assign_station(self, session_id):
        """
        Assign a station to a new EV session
        
        Args:
            session_id: ID of the EV session
            
        Returns:
            str: Station ID assigned to the session, or None if no stations available
        """
        # Check if session already has a station
        if session_id in self.station_assignments:
            return self.station_assignments[session_id]
        
        # Prefer OPT stations first, then fallback to legacy stations
        station_priority = []
        
        # Add OPT stations first (higher priority)
        for i in range(1, 21):
            station_priority.append(f'OPT_Station_{i}')
            
        # Add legacy stations as fallback
        for i in range(1, 21):
            station_priority.append(f'Station_{i}')
        
        # Find first available station in priority order
        for station_id in station_priority:
            if station_id in self.station_availability and self.station_availability[station_id] is None:
                # Assign this station to the session
                self.station_assignments[session_id] = station_id
                self.station_occupancy[station_id] = session_id
                self.station_availability[station_id] = session_id
                print(f"🔌 Assigned {station_id} to session {session_id[:15]}...")
                return station_id
        
        # No available stations
        print(f"❌ No available stations for session {session_id[:15]}...")
        return None
    
    def release_station(self, session_id):
        """
        Release a station when an EV session disconnects
        
        Args:
            session_id: ID of the EV session
        """
        if session_id in self.station_assignments:
            station_id = self.station_assignments[session_id]
            
            # Clear the assignment
            del self.station_assignments[session_id]
            if station_id in self.station_occupancy:
                del self.station_occupancy[station_id]
            self.station_availability[station_id] = None
            
            print(f"🔓 Released {station_id} from session {session_id[:15]}...")
            return station_id
        
        return None
    
    def get_station_assignment(self, session_id):
        """
        Get current station assignment for a session
        
        Args:
            session_id: ID of the EV session
            
        Returns:
            str: Station ID or None if not assigned
        """
        return self.station_assignments.get(session_id)
    
    def get_session_at_station(self, station_id):
        """
        Get session ID currently assigned to a station
        
        Args:
            station_id: ID of the station
            
        Returns:
            str: Session ID or None if station is free
        """
        return self.station_occupancy.get(station_id)
    
    def get_available_stations(self):
        """
        Get list of available station IDs
        
        Returns:
            list: List of available station IDs
        """
        return [station_id for station_id, occupant in self.station_availability.items() if occupant is None]
    
    def get_occupied_stations(self):
        """
        Get list of occupied stations with their sessions
        
        Returns:
            dict: Station ID -> Session ID mapping for occupied stations
        """
        return {station_id: occupant for station_id, occupant in self.station_availability.items() if occupant is not None}
    
    def get_station_status(self):
        """
        Get complete status of all stations
        
        Returns:
            dict: Complete station status information
        """
        status = {
            'total_stations': self.max_stations,
            'available_count': len(self.get_available_stations()),
            'occupied_count': len(self.get_occupied_stations()),
            'station_details': {}
        }
        
        for station_id in self.station_availability:
            occupant = self.station_availability[station_id]
            status['station_details'][station_id] = {
                'occupied': occupant is not None,
                'session_id': occupant,
                'available': occupant is None
            }
        
        return status
    
    def cleanup_disconnected_sessions(self, active_session_ids):
        """
        Clean up station assignments for sessions that are no longer active
        
        Args:
            active_session_ids: List of currently active session IDs
        """
        # Find sessions that have assignments but are no longer active
        assigned_sessions = list(self.station_assignments.keys())
        
        for session_id in assigned_sessions:
            if session_id not in active_session_ids:
                print(f"🧹 Cleaning up station assignment for disconnected session {session_id[:15]}...")
                self.release_station(session_id)
    
    def get_assignment_constraints_for_optimization(self, session_ids):
        """
        Get existing station assignments that should be preserved during optimization
        
        Args:
            session_ids: List of session IDs being optimized
            
        Returns:
            dict: session_id -> station_index mapping for existing assignments
        """
        constraints = {}
        
        for i, session_id in enumerate(session_ids):
            assigned_station = self.get_station_assignment(session_id)
            if assigned_station:
                # Convert station_id to station index for LP optimization
                try:
                    station_index = int(assigned_station.split('_')[1]) - 1  # Station_1 -> 0, Station_2 -> 1, etc.
                    constraints[session_id] = station_index
                except (ValueError, IndexError):
                    print(f"⚠️ Invalid station ID format: {assigned_station}")
        
        return constraints
    
    def validate_consistency(self):
        """
        Validate internal consistency of station assignments
        
        Returns:
            bool: True if consistent, False otherwise
        """
        # Check forward mapping consistency
        for session_id, station_id in self.station_assignments.items():
            if self.station_occupancy.get(station_id) != session_id:
                print(f"❌ Inconsistency: {session_id} -> {station_id} but station occupied by {self.station_occupancy.get(station_id)}")
                return False
            
            if self.station_availability.get(station_id) != session_id:
                print(f"❌ Inconsistency: {session_id} -> {station_id} but station availability shows {self.station_availability.get(station_id)}")
                return False
        
        # Check reverse mapping consistency
        for station_id, session_id in self.station_occupancy.items():
            if self.station_assignments.get(session_id) != station_id:
                print(f"❌ Inconsistency: {station_id} occupied by {session_id} but session assigned to {self.station_assignments.get(session_id)}")
                return False
        
        return True
    
    def debug_print_status(self):
        """Print debug information about current station status"""
        print(f"\n🔍 STATION MANAGER STATUS:")
        print(f"   📊 Total stations: {self.max_stations}")
        print(f"   🔌 Available: {len(self.get_available_stations())}")
        print(f"   🚗 Occupied: {len(self.get_occupied_stations())}")
        
        print(f"\n   📋 Station Details:")
        for station_id in sorted(self.station_availability.keys()):
            occupant = self.station_availability[station_id]
            status = "FREE" if occupant is None else f"OCCUPIED by {occupant[:15]}..."
            print(f"     {station_id}: {status}")
        
        # Validate consistency
        is_consistent = self.validate_consistency()
        print(f"\n   ✅ Consistency check: {'PASSED' if is_consistent else 'FAILED'}")
