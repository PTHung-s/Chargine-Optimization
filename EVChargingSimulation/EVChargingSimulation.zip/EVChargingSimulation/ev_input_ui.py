"""
EV Input UI - Simple Console Interface
Allows users to add custom EV sessions via command line
"""

from datetime import datetime, timedelta
from ev_input_manager import EVInputManager
import sys

class EVInputUI:
    def __init__(self):
        """Initialize the EV Input UI"""
        self.ev_manager = EVInputManager()
        self.ev_manager.load_custom_evs()  # Load existing custom EVs
        
    def display_banner(self):
        """Display welcome banner"""
        print("\n" + "="*60)
        print("🚗 EV CHARGING SIMULATION - CUSTOM EV INPUT")
        print("="*60)
        print("Add your own Electric Vehicle sessions to the simulation!")
        print()
        
    def get_datetime_input(self, prompt, default_time=None):
        """
        Get datetime input from user with validation
        
        Args:
            prompt: str - Prompt message
            default_time: datetime - Default time if user presses enter
            
        Returns:
            datetime: Parsed datetime
        """
        while True:
            try:
                if default_time:
                    user_input = input(f"{prompt} (default: {default_time.strftime('%Y-%m-%d %H:%M')}): ").strip()
                    if not user_input:
                        return default_time
                else:
                    user_input = input(f"{prompt}: ").strip()
                
                # Try different datetime formats
                formats = [
                    '%Y-%m-%d %H:%M',      # 2018-07-01 09:00
                    '%Y-%m-%d %H:%M:%S',   # 2018-07-01 09:00:00
                    '%d/%m/%Y %H:%M',      # 01/07/2018 09:00
                    '%m/%d/%Y %H:%M',      # 07/01/2018 09:00
                ]
                
                for fmt in formats:
                    try:
                        return datetime.strptime(user_input, fmt)
                    except ValueError:
                        continue
                
                # If no format worked, show error
                print("❌ Invalid datetime format. Please use: YYYY-MM-DD HH:MM")
                print("   Examples: 2018-07-01 09:00, 01/07/2018 14:30")
                
            except KeyboardInterrupt:
                print("\n👋 Cancelled by user")
                return None
            except Exception as e:
                print(f"❌ Error: {e}")
    
    def get_energy_input(self, prompt):
        """
        Get energy input from user with validation
        
        Args:
            prompt: str - Prompt message
            
        Returns:
            float: Energy in kWh
        """
        while True:
            try:
                user_input = input(f"{prompt}: ").strip()
                energy = float(user_input)
                
                if energy <= 0:
                    print("❌ Energy must be positive")
                    continue
                    
                if energy > 100:
                    print("⚠️  Warning: Very high energy (>100 kWh). Are you sure? (y/n)")
                    confirm = input().strip().lower()
                    if confirm not in ['y', 'yes']:
                        continue
                
                return energy
                
            except ValueError:
                print("❌ Invalid number. Please enter energy in kWh (e.g., 25.5)")
            except KeyboardInterrupt:
                print("\n👋 Cancelled by user")
                return None
    
    def add_custom_ev_interactive(self):
        """Interactive process to add a custom EV"""
        print("\n📝 ADD NEW CUSTOM EV")
        print("-" * 30)
        
        # Get arrival time
        print("\\n⏰ ARRIVAL TIME")
        default_arrival = datetime(2018, 7, 1, 9, 0)  # Default: July 1, 9 AM
        arrival_time = self.get_datetime_input(
            "When will the EV arrive? (YYYY-MM-DD HH:MM)", 
            default_arrival
        )
        if arrival_time is None:
            return False
        
        # Get departure time (default: 8 hours later)
        print("\\n⏰ DEPARTURE TIME")
        default_departure = arrival_time + timedelta(hours=8)
        departure_time = self.get_datetime_input(
            "When will the EV leave? (YYYY-MM-DD HH:MM)",
            default_departure
        )
        if departure_time is None:
            return False
        
        # Validate times
        if arrival_time >= departure_time:
            print("❌ Arrival time must be before departure time!")
            return False
        
        duration_hours = (departure_time - arrival_time).total_seconds() / 3600
        print(f"ℹ️  Parking duration: {duration_hours:.1f} hours")
        
        # Get energy needed
        print("\\n⚡ ENERGY NEEDED")
        energy_needed = self.get_energy_input("How much energy does the EV need? (kWh)")
        if energy_needed is None:
            return False
        
        # Calculate rough charging time
        avg_power = 18  # kW average charging power
        charging_time = energy_needed / avg_power
        print(f"ℹ️  Estimated charging time: {charging_time:.1f} hours at {avg_power}kW")
        
        if charging_time > duration_hours:
            print(f"⚠️  Warning: Charging time ({charging_time:.1f}h) > Parking duration ({duration_hours:.1f}h)")
            print("   The EV may not fully charge before departure.")
        
        # Confirm and create
        print("\\n📋 SUMMARY")
        print(f"   Arrival:   {arrival_time.strftime('%Y-%m-%d %H:%M')}")
        print(f"   Departure: {departure_time.strftime('%Y-%m-%d %H:%M')}")
        print(f"   Duration:  {duration_hours:.1f} hours")
        print(f"   Energy:    {energy_needed} kWh")
        
        confirm = input("\\nAdd this EV to simulation? (y/n): ").strip().lower()
        if confirm in ['y', 'yes']:
            try:
                custom_ev = self.ev_manager.add_custom_ev(arrival_time, departure_time, energy_needed)
                print("\\n✅ SUCCESS! Custom EV added to simulation.")
                print(f"   Session ID: {custom_ev['sessionID'][:40]}...")
                print(f"   Station ID: {custom_ev['stationID']}")
                return True
            except Exception as e:
                print(f"\\n❌ Error adding EV: {e}")
                return False
        else:
            print("\\n❌ Cancelled - EV not added")
            return False
    
    def show_custom_evs(self):
        """Show all custom EVs"""
        print("\\n📊 CUSTOM EVS SUMMARY")
        print("-" * 30)
        
        if not self.ev_manager.custom_evs:
            print("No custom EVs added yet.")
            return
        
        print(self.ev_manager.get_custom_ev_summary())
        
        print("\\nDETAILS:")
        for i, ev in enumerate(self.ev_manager.custom_evs, 1):
            arrival = datetime.strptime(ev['connectionTime'], '%a, %d %b %Y %H:%M:%S GMT')
            departure = datetime.strptime(ev['disconnectTime'], '%a, %d %b %Y %H:%M:%S GMT')
            done_charging = datetime.strptime(ev['doneChargingTime'], '%a, %d %b %Y %H:%M:%S GMT')
            
            print(f"  {i}. Session: {ev['sessionID'][:30]}...")
            print(f"     Arrival: {arrival.strftime('%Y-%m-%d %H:%M')}")
            print(f"     Departure: {departure.strftime('%Y-%m-%d %H:%M')}")
            print(f"     Done Charging: {done_charging.strftime('%Y-%m-%d %H:%M')}")
            print(f"     Energy: {ev['kWhDelivered']} kWh")
            print(f"     Station: {ev['stationID']}")
            print()
    
    def main_menu(self):
        """Display main menu and handle user choices"""
        while True:
            print("\\n🚗 MAIN MENU")
            print("-" * 20)
            print("1. Add new custom EV")
            print("2. Show custom EVs") 
            print("3. Save custom EVs to file")
            print("4. Clear all custom EVs")
            print("5. Exit")
            
            try:
                choice = input("\\nChoose an option (1-5): ").strip()
                
                if choice == '1':
                    self.add_custom_ev_interactive()
                    
                elif choice == '2':
                    self.show_custom_evs()
                    
                elif choice == '3':
                    self.ev_manager.save_custom_evs()
                    print("✅ Custom EVs saved to custom_evs.json")
                    
                elif choice == '4':
                    confirm = input("Are you sure you want to clear all custom EVs? (y/n): ").strip().lower()
                    if confirm in ['y', 'yes']:
                        self.ev_manager.clear_custom_evs()
                    
                elif choice == '5':
                    print("\\n👋 Goodbye!")
                    # Auto-save before exit
                    self.ev_manager.save_custom_evs()
                    break
                    
                else:
                    print("❌ Invalid choice. Please choose 1-5.")
                    
            except KeyboardInterrupt:
                print("\\n\\n👋 Goodbye!")
                self.ev_manager.save_custom_evs()
                break
            except Exception as e:
                print(f"❌ Unexpected error: {e}")
    
    def run(self):
        """Run the EV Input UI"""
        self.display_banner()
        self.main_menu()

# Quick add function for programmatic use
def quick_add_ev(arrival_str, departure_str, energy_kwh):
    """
    Quick function to add EV programmatically
    
    Args:
        arrival_str: str - Arrival time in 'YYYY-MM-DD HH:MM' format
        departure_str: str - Departure time in 'YYYY-MM-DD HH:MM' format  
        energy_kwh: float - Energy needed in kWh
        
    Returns:
        dict: Created EV session or None if error
    """
    try:
        ev_manager = EVInputManager()
        ev_manager.load_custom_evs()
        
        arrival = datetime.strptime(arrival_str, '%Y-%m-%d %H:%M')
        departure = datetime.strptime(departure_str, '%Y-%m-%d %H:%M')
        
        custom_ev = ev_manager.add_custom_ev(arrival, departure, energy_kwh)
        ev_manager.save_custom_evs()
        
        return custom_ev
        
    except Exception as e:
        print(f"❌ Error in quick_add_ev: {e}")
        return None

# Example usage
if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "quick":
        # Quick mode for testing
        print("🚀 Quick test mode...")
        ev = quick_add_ev("2018-07-01 10:00", "2018-07-01 16:00", 30.0)
        if ev:
            print(f"✅ Added test EV: {ev['sessionID'][:30]}...")
    else:
        # Interactive mode
        ui = EVInputUI()
        ui.run()
