# filepath: c:\Users\PhamT\Python\Project_a_AN\NewProject\session_manager.py
"""
Session Manager Module - Fixed Version
Manages EV charging sessions and their state with proper real-time energy tracking
"""

from datetime import datetime, timedelta
from station_manager import StationManager

class SessionManager:
    def __init__(self):
        self.active_sessions = []
        self.completed_sessions = []
        self.processed_sessions = set()  # Track which sessions we've already processed
        self.price_data = None  # Store price data for UI access
        self.data_loader = None  # Store data loader reference
        self.station_manager = StationManager(max_stations=80)  # Initialize station manager with more capacity
    
    def check_arrivals(self, all_sessions, current_time):
        """Check for new EV arrivals at current time"""
        new_arrivals = []
        
        for session in all_sessions:
            session_id = session['sessionID']
            arrival_time = session['connectionTime_dt']
            
            # Check if this session should arrive now (within last minute to avoid missing)
            time_diff = (current_time - arrival_time).total_seconds()
            
            if (0 <= time_diff <= 60 and  # Arrived within last minute
                session_id not in self.processed_sessions):
                
                new_arrivals.append(session)
                self.processed_sessions.add(session_id)
        
        return new_arrivals
    def add_active_session(self, session):
        """Add a new session to active list with proper initialization"""
        # Initialize tracking variables
        session['energy_delivered'] = 0.0  # Track how much energy has been delivered
        session['remaining_energy'] = session['kWhDelivered']  # Initialize remaining energy
        session['last_update_time'] = session['connectionTime_dt']
        session['last_energy_update'] = session['connectionTime_dt']
        session['prev_energy_delivered'] = 0.0  # For step-by-step tracking
        session['current_charging_power'] = 0.0  # Current charging power in kW
        session['charging_plan'] = []  # Future charging schedule
        
        # 🔌 NEW: Assign a charging station to this session
        station_id = self.station_manager.assign_station(session['sessionID'])
        session['assigned_station'] = station_id  # Store in session data
        
        if station_id:
            print(f"🔌 Session {session['sessionID'][:15]}... assigned to {station_id}")
        else:
            print(f"⚠️ Session {session['sessionID'][:15]}... could not be assigned a station (all occupied)")
        
        self.active_sessions.append(session)
    
    def get_active_sessions(self, current_time):
        """Get all currently active sessions"""
        active = []
        for session in self.active_sessions:
            # Check if session is still connected and needs energy
            if (session['connectionTime_dt'] <= current_time < session['disconnectTime_dt'] and
                session['remaining_energy'] > 0.01):  # Still needs energy
                active.append(session)
        
        return active
    
    def update_energy_delivered(self, current_time):
        """Update energy delivered for active sessions based on real-time charging"""
        for session in self.active_sessions:
            if 'last_energy_update' not in session:
                session['last_energy_update'] = session.get('connectionTime_dt', current_time)
            
            # Calculate time elapsed since last update
            time_elapsed = (current_time - session['last_energy_update']).total_seconds() / 3600  # hours
            
            if time_elapsed > 0 and session.get('current_charging_power', 0) > 0:
                # Find the current slot in future_schedule
                fraction = 1.0  # Default to full availability
                for schedule_entry in session.get('future_schedule', []):
                    if schedule_entry['time_start'] <= current_time < schedule_entry['time_end']:
                        # Calculate availability fraction for the slot
                        slot_start = schedule_entry['time_start']
                        slot_end = schedule_entry['time_end']
                        # session_start = max(session['connectionTime_dt'], slot_start)
                        session_start = max(session['virtual_arrival_time'], slot_start)
                        session_end = min(session['disconnectTime_dt'], slot_end)
                        # print(slot_start, slot_end, session_start, session_end)
                        if session_end > session_start:
                            fraction = (session_end - session_start).total_seconds() / 3600.0
                            fraction = min(fraction, 1.0)
                        else:
                            fraction = 0.0
                        break
                
                # Calculate energy delivered in this time period
                charging_power = session.get('current_charging_power', 0.0)

                energy_increment = charging_power * time_elapsed * 0.92 / fraction  # Adjust for availability and 90% efficiency
                # print("FRACTION:", fraction, "Charging Power:", charging_power,)
                if energy_increment > 0 and session['remaining_energy'] > 0:
                    # Update energy tracking
                    session['energy_delivered'] += energy_increment
                    session['remaining_energy'] = max(0, session['remaining_energy'] - energy_increment)
                    
                    # Debug: show energy increment
                    # if energy_increment > 0.001:
                    #     print(f"  ⚡ {session['sessionID'][:15]}... +{energy_increment:.3f} kWh "
                    #           f"(Power: {charging_power:.1f}kW × {time_elapsed:.3f}h × {fraction:.3f} availability)")
                    
                    # Ensure we don't over-charge
                    if session['energy_delivered'] > session['kWhDelivered']:
                        excess = session['energy_delivered'] - session['kWhDelivered']
                        session['energy_delivered'] = session['kWhDelivered']
                        session['remaining_energy'] = 0.0
                        session['current_charging_power'] = 0.0
                    # print(f"  🔋 {session['sessionID'][:15]}... COMPLETED!")
            
            session['last_energy_update'] = current_time
            if session['remaining_energy'] < 0:
                session['remaining_energy'] = 0

    def apply_optimization_results(self, opt_result, current_time):
        print(f"🔧 APPLYING OPTIMIZATION at {current_time.strftime('%H:%M:%S')}")
        print(f"   Optimization status: {opt_result.get('status', 'Unknown')}")
        print(f"   Number of time slots: {len(opt_result.get('charging_schedule', []))}")
        
        # ✅ STORE optimization result for UI access
        self.latest_optimization_result = opt_result
        self.latest_optimization_time = current_time
        
        # 🔧 CRITICAL FIX: Clear all existing future_schedule before applying new optimization
        print(f"   🔧 CLEARING existing future_schedule for all active sessions...")
        for session in self.active_sessions:
            session['virtual_arrival_time'] = current_time
            session['future_schedule'] = []  # Clear corrupted schedule data
        print(f"   ✅ Cleared future_schedule for {len(self.active_sessions)} sessions")
        
        # Debug: Print what we stored
        print(f"   ✅ Stored optimization result for UI access")
        print(f"   ✅ Available for get_full_charging_schedule()")
        
        # Get the charging schedule from optimization result
        schedule = opt_result.get('charging_schedule', [])
        optimization_timestamp = current_time
        
        for slot_index, slot in enumerate(schedule):
            # Căn chỉnh slot_start về đầu giờ
            slot_start = slot.get('time_start', current_time.replace(minute=0, second=0, microsecond=0) + timedelta(hours=slot_index))
            if slot_start.microsecond != 0 or slot_start.second != 0 or slot_start.minute != 0:
                slot_start = slot_start.replace(minute=0, second=0, microsecond=0)
            slot_end = slot_start + timedelta(hours=1)
            print(f"   Slot {slot_index}: {slot_start.strftime('%H:%M')}-{slot_end.strftime('%H:%M')}")
            
            if slot.get('stations'):
                for station in slot['stations']:
                    session_id = station.get('session_id')
                    base_charging_power = station.get('charging_power', 0.0)
                    print(f"     └─ {session_id[:15]}... = {base_charging_power:.2f} kW (LP direct)")
                    
                    # Find the corresponding active session
                    for session in self.active_sessions:
                        if session['sessionID'] == session_id:
                            # Store schedule information for this slot
                            schedule_entry = {
                                'time_start': slot_start,
                                'time_end': slot_end,
                                'charging_power': base_charging_power,
                                'slot_index': slot_index
                            }
                            
                            if 'future_schedule' not in session:
                                session['future_schedule'] = []
                            session['future_schedule'].append(schedule_entry)
                            
                            # 🔧 FIX: Only set current power for CURRENT slot (slot_index == 0)
                            if slot_index == 0:
                                last_calc_time = session.get('last_power_calculation_time')
                                
                                if last_calc_time != optimization_timestamp:
                                    session['current_charging_power'] = base_charging_power
                                    session['last_power_calculation_time'] = optimization_timestamp
                                    
                                    print(f"  🔧 DIRECT LP POWER: {session_id[:15]}... = {base_charging_power:.2f} kW")
                                else:
                                    print(f"  ♻️ REUSED POWER: {session_id[:15]}... = {session['current_charging_power']:.2f} kW")
                            break

    
    def apply_charging_decision(self, session_id, energy_amount, time_period):
        """Apply charging decision to a specific session"""
        for session in self.active_sessions:
            if session['sessionID'] == session_id:
                session['energy_delivered'] += energy_amount
                session['remaining_energy'] = max(0, session['remaining_energy'] - energy_amount)
                session['last_update_time'] = time_period
                break
    def remove_completed_sessions(self, current_time):
        """Remove sessions that have disconnected"""
        completed = []
        remaining_active = []
        
        for session in self.active_sessions:
            # Check if session is completed (fully charged or disconnected)
            if (current_time >= session['disconnectTime_dt']):  # Disconnected
                session['current_charging_power'] = 0.0  # Ensure no further charging
                
                # 🔓 NEW: Release the station when session disconnects
                station_id = session.get('assigned_station')
                if station_id:
                    self.station_manager.release_station(session['sessionID'])
                    print(f"🔓 Released {station_id} from disconnected session {session['sessionID'][:15]}...")
                
                completed.append(session)
                self.completed_sessions.append(session)
            else:
                remaining_active.append(session)
        
        self.active_sessions = remaining_active
        
        # 🧹 Cleanup any orphaned station assignments
        active_session_ids = [s['sessionID'] for s in self.active_sessions]
        self.station_manager.cleanup_disconnected_sessions(active_session_ids)
        
        return completed
    
    def get_session_by_id(self, session_id):
        """Get session by ID from active sessions"""
        for session in self.active_sessions:
            if session['sessionID'] == session_id:
                return session
        return None
    
    def get_charging_status(self):
        """Get current charging status of all active sessions"""
        status = {}
        for session in self.active_sessions:
            total_needed = session['kWhDelivered']
            delivered = session.get('energy_delivered', 0.0)
            progress = (delivered / total_needed * 100) if total_needed > 0 else 0
            
            status[session['sessionID']] = {
                'remaining_energy': session.get('remaining_energy', total_needed),
                'energy_delivered': delivered,
                'progress': min(progress, 100.0),  # Cap at 100%
                'charging_power': session.get('current_charging_power', 0.0),
                'disconnect_time': session['disconnectTime_dt']
            }
        return status
    
    def prepare_sessions_for_reoptimization(self, current_time):
        """
        Prepare all active sessions for re-optimization by updating their state
        to reflect current charging progress and virtual arrival time
        """
        updated_sessions = []
        
        for session in self.active_sessions:
            # Create a copy for LP solver
            updated_session = session.copy()
            
            # 1. Update virtual arrival time to current time
            # This tells LP solver to start planning from NOW, not original arrival
            original_arrival = updated_session['connectionTime_dt']
            updated_session['connectionTime_dt'] = current_time
            
            # 2. Update energy demand to reflect current remaining energy
            # LP should only plan for what's still needed
            original_demand = updated_session['kWhDelivered']
            current_remaining = session.get('remaining_energy', original_demand)
            updated_session['kWhDelivered'] = max(0.01, current_remaining)  # Minimum 0.01 to avoid division by zero
            
            # 3. Store original values for reference
            updated_session['original_arrival_time'] = original_arrival
            updated_session['original_demand'] = original_demand
            updated_session['energy_already_delivered'] = session.get('energy_delivered', 0.0)
            
            updated_sessions.append(updated_session)
            
            # Debug info
            print(f"  📊 Updated EV {session['sessionID'][:15]}... for re-optimization:")
            print(f"     Original arrival: {original_arrival.strftime('%H:%M')} → Virtual arrival: {current_time.strftime('%H:%M')}")
            print(f"     Original demand: {original_demand:.2f} kWh → Remaining: {current_remaining:.2f} kWh")
            print(f"     Already delivered: {session.get('energy_delivered', 0.0):.2f} kWh")
        
        return updated_sessions
    
    def update_sessions_after_reoptimization(self, updated_sessions):
        """
        After LP optimization, update the actual sessions with new charging plans
        but preserve the real tracking data
        """
        for updated_session in updated_sessions:
            session_id = updated_session['sessionID']
            
            # Find the corresponding real session
            for real_session in self.active_sessions:
                if real_session['sessionID'] == session_id:
                    # Update only the charging plan, keep real energy tracking
                    real_session['charging_plan'] = updated_session.get('charging_plan', [])
                    
                    # Keep the real arrival time and energy tracking
                    # Don't overwrite: connectionTime_dt, energy_delivered, remaining_energy
                    break

    def maintain_stable_charging_power(self, current_time):
        """
        Update charging power based on future schedule and reset for completed/disconnected sessions
        """
        for session in self.active_sessions:
            # Update current_charging_power from future_schedule
            found_slot = False
            for schedule_entry in session.get('future_schedule', []):
                if schedule_entry['time_start'] <= current_time < schedule_entry['time_end']:
                    session['current_charging_power'] = schedule_entry['charging_power']
                    found_slot = True
                    break
            
            # If no valid slot or session is done/disconnected, stop charging
            if not found_slot or session['remaining_energy'] <= 0.01 or \
               session['connectionTime_dt'] > current_time or \
               current_time >= session['disconnectTime_dt']:
                session['current_charging_power'] = 0.0

    
    def get_latest_optimization_result(self):
        """Get the latest optimization result for UI display"""
        return getattr(self, 'latest_optimization_result', None)
    
    def get_latest_optimization_time(self):
        """Get the time of the latest optimization"""
        return getattr(self, 'latest_optimization_time', None)
    
    def get_full_charging_schedule(self, current_time=None, time_range_hours=24):
        """Get complete charging schedule for UI display"""
        if current_time is None:
            current_time = self.get_latest_optimization_time() or datetime.now()
        
        schedule_data = []
        
        # Get the latest optimization result
        opt_result = self.get_latest_optimization_result()
        if not opt_result or not opt_result.get('charging_schedule'):
            return schedule_data
        
        # Create session lookup for quick access
        session_lookup = {session['sessionID']: session for session in self.active_sessions}
        
        # Process each time slot in the optimization result
        for slot_index, slot in enumerate(opt_result['charging_schedule']):
            slot_start = slot.get('time_start')
            if slot_start is None:
                # Calculate slot start based on optimization time and index
                opt_time = self.get_latest_optimization_time() or current_time
                slot_start = opt_time.replace(minute=0, second=0, microsecond=0) + timedelta(hours=slot_index)
            
            slot_end = slot_start + timedelta(hours=1)
            
            # Skip slots outside our time range
            if (slot_start - current_time).total_seconds() / 3600 > time_range_hours:
                break
            
            # Process stations in this slot
            slot_data = {
                'time_start': slot_start,
                'time_end': slot_end,
                'time_label': f"{slot_start.strftime('%H')}h-{slot_end.strftime('%H')}h",
                'total_power': 0.0,
                'stations': []
            }
            if slot.get('stations'):
                for station in slot['stations']:
                    session_id = station['session_id']
                    charging_power = station.get('charging_power', 0.0)
                    
                    # Get session details if available
                    session = session_lookup.get(session_id)
                    
                    # 🔌 NEW: Use persistent station assignment from StationManager
                    persistent_station_id = self.station_manager.get_station_assignment(session_id)
                    station_id = persistent_station_id or station.get('station_id', f'Station_{len(slot_data["stations"]) + 1}')
                    
                    station_data = {
                        'session_id': session_id[:20],  # Truncate for display
                        'charging_power': charging_power,
                        'station_id': station_id  # Use persistent assignment
                    }
                    
                    if session:
                        # Add session details
                        station_data.update({
                            'remaining_energy': session.get('remaining_energy', 0.0),
                            'total_demand': session.get('kWhDelivered', 0.0),
                            'progress': (session.get('energy_delivered', 0.0) / session.get('kWhDelivered', 1.0)) * 100,
                            'departure_time': session['disconnectTime_dt'].strftime('%H:%M'),
                            'is_current_slot': slot_index == 0
                        })
                    
                    slot_data['stations'].append(station_data)
                    slot_data['total_power'] += charging_power
            
            schedule_data.append(slot_data)
        
        return schedule_data
    
    @staticmethod
    def slot_overlap(slot_start, slot_end, target_start, target_end):
        """Check if two time slots overlap"""
        return slot_start < target_end and slot_end > target_start

    @staticmethod
    def format_time(start_time, end_time):
        """Format time range for display"""
        return f"{start_time.strftime('%H:%M')}-{end_time.strftime('%H:%M')}"
    
    def set_price_data(self, price_data, data_loader):
        """Set price data and data loader for price calculations"""
        self.price_data = price_data
        self.data_loader = data_loader
        
    def get_hourly_price(self, datetime_obj):
        """Get electricity price for specific datetime"""
        if self.price_data and self.data_loader:
            return self.data_loader.get_hourly_price(self.price_data, datetime_obj)
        return 0.0
        
    def get_price_reason(self, datetime_obj):
        """Get charging reason based on electricity price"""
        if self.price_data and self.data_loader:
            return self.data_loader.get_price_reason(self.price_data, datetime_obj)
        return "❓ Unknown"
    
    def reload_custom_evs(self):
        """Reload custom EVs during runtime and add them to simulation"""
        try:
            # Load new custom EVs
            new_custom_evs = self.data_loader.load_custom_evs()
            
            if not new_custom_evs:
                print("ℹ️ No new custom EVs to reload")
                return False
                
            print(f"🔄 Reloading {len(new_custom_evs)} custom EVs into simulation...")
            
            # Add to processed sessions for future arrivals
            current_time = self.simulation_clock.get_current_time()
            
            for custom_ev in new_custom_evs:
                # Parse arrival time
                arrival_time = self.data_loader.parse_time(custom_ev['connectionTime'])
                
                # Only add if arrival is in the future
                if arrival_time > current_time:
                    # Convert to session format
                    session = self.data_loader.create_session_from_data(custom_ev, arrival_time)
                    
                    # Add to session manager
                    if session['sessionID'] not in [s['sessionID'] for s in self.session_manager.processed_sessions]:
                        self.session_manager.processed_sessions.append(session)
                        print(f"✅ Added future custom EV: {session['sessionID'][:15]}... arriving at {arrival_time.strftime('%H:%M')}")
                    
            return True
            
        except Exception as e:
            print(f"❌ Error reloading custom EVs: {e}")
            return False