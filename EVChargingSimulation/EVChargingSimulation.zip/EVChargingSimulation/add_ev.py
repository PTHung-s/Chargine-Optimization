#!/usr/bin/env python3
"""
Add New EV Script
Simple command-line interface for adding new EVs to the simulation
"""

import sys
import os
from datetime import datetime, timedelta
from ev_input_manager import EVInputManager

def get_user_input():
    """Get EV information from user input"""
    print("🚗 Add New EV to Simulation")
    print("=" * 40)
    
    try:
        # Get arrival time
        print("\n📅 Arrival Time:")
        arrival_date = input("Enter arrival date (YYYY-MM-DD) [default: 2018-07-01]: ").strip()
        if not arrival_date:
            arrival_date = "2018-07-01"
            
        arrival_time = input("Enter arrival time (HH:MM) [default: 09:00]: ").strip()
        if not arrival_time:
            arrival_time = "09:00"
            
        arrival_datetime = datetime.strptime(f"{arrival_date} {arrival_time}", "%Y-%m-%d %H:%M")
        
        # Get departure time
        print("\n📅 Departure Time:")
        departure_hours = input("Enter parking duration in hours [default: 4]: ").strip()
        if not departure_hours:
            departure_hours = "4"
            
        departure_datetime = arrival_datetime + timedelta(hours=float(departure_hours))
        
        # Get energy needed
        print("\n🔋 Energy Needed:")
        energy_needed = input("Enter energy needed (kWh) [default: 20]: ").strip()
        if not energy_needed:
            energy_needed = "20"
            
        energy_needed = float(energy_needed)
        
        # Display summary
        print("\n📋 EV Summary:")
        print(f"   Arrival: {arrival_datetime.strftime('%Y-%m-%d %H:%M')}")
        print(f"   Departure: {departure_datetime.strftime('%Y-%m-%d %H:%M')}")
        print(f"   Energy Needed: {energy_needed} kWh")
        print(f"   Parking Duration: {departure_hours} hours")
        
        confirm = input("\n✅ Add this EV to simulation? (y/N): ").strip().lower()
        if confirm != 'y':
            print("❌ Cancelled")
            return None
            
        return {
            'arrival': arrival_datetime,
            'departure': departure_datetime,
            'energy_needed': energy_needed
        }
        
    except ValueError as e:
        print(f"❌ Invalid input: {e}")
        return None
    except KeyboardInterrupt:
        print("\n❌ Cancelled by user")
        return None

def main():
    """Main function"""
    print("🔋 EV Charging Simulation - Add New EV")
    print("=" * 50)
    
    # Initialize EV input manager
    ev_manager = EVInputManager()
    
    while True:
        print(f"\n📊 Current custom EVs: {len(ev_manager.custom_evs)}")
        
        choice = input("\nChoose action:\n1. Add new EV\n2. View current EVs\n3. Clear all custom EVs\n4. Exit\nChoice (1-4): ").strip()
        
        if choice == '1':
            # Add new EV
            ev_data = get_user_input()
            if ev_data:
                ev_id = ev_manager.add_ev(
                    arrival_time=ev_data['arrival'],
                    departure_time=ev_data['departure'],
                    energy_needed=ev_data['energy_needed']
                )
                print(f"✅ Added EV with ID: {ev_id}")
                
        elif choice == '2':
            # View current EVs
            if not ev_manager.custom_evs:
                print("📝 No custom EVs found")
            else:
                print(f"\n📋 Custom EVs ({len(ev_manager.custom_evs)}):")
                for i, ev in enumerate(ev_manager.custom_evs, 1):
                    arrival = datetime.strptime(ev['connectionTime'], "%a, %d %b %Y %H:%M:%S GMT")
                    departure = datetime.strptime(ev['disconnectTime'], "%a, %d %b %Y %H:%M:%S GMT")
                    print(f"   {i}. ID: {ev['sessionID'][:15]}...")
                    print(f"      Arrival: {arrival.strftime('%Y-%m-%d %H:%M')}")
                    print(f"      Departure: {departure.strftime('%Y-%m-%d %H:%M')}")
                    print(f"      Energy: {ev['kWhDelivered']} kWh")
                    print()
                    
        elif choice == '3':
            # Clear all custom EVs
            if ev_manager.custom_evs:
                confirm = input(f"❗ Delete all {len(ev_manager.custom_evs)} custom EVs? (y/N): ").strip().lower()
                if confirm == 'y':
                    ev_manager.clear_all_custom_evs()
                    print("✅ All custom EVs cleared")
            else:
                print("📝 No custom EVs to clear")
                
        elif choice == '4':
            print("👋 Goodbye!")
            break
            
        else:
            print("❌ Invalid choice. Please enter 1-4.")

if __name__ == "__main__":
    main()
