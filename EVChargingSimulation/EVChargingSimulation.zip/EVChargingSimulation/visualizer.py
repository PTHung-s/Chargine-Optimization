"""
Visualizer Module
Handles display and output of simulation results
"""

from datetime import datetime, timedelta

class Visualizer:
    def __init__(self):
        self.delta_time_minutes = 60  # 1 hour = 60 minutes
    
    def display_results(self, current_time, active_sessions, opt_data, opt_result, fcfs_result):
        """Display optimization results and charging schedules"""
        
        print(f"\n{'='*80}")
        print(f"OPTIMIZATION RESULTS AT {current_time.strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"{'='*80}")
        
        # Display problem overview
        print(f"Active EVs: {len(active_sessions)}")
        print(f"Optimization horizon: {opt_data['T']} hours")
        print(f"Grid capacity: {opt_data['C_grid']} kW")
        print(f"Max charging rate: {opt_data['s']} kW per station")
        
        # Display EV details
        print(f"\nActive EV Sessions:")
        for i, session in enumerate(active_sessions):
            print(f"  [{i}] {session['sessionID'][:25]}... | "
                  f"Needs: {session['remaining_energy']:.2f} kWh | "
                  f"Until: {session['disconnectTime_dt'].strftime('%H:%M')}")
        
        # Display optimization results
        print(f"\n{'─'*40} OPTIMAL SOLUTION {'─'*40}")
        if opt_result['status'] == 'Optimal':
            print(f"Status: {opt_result['status']} | Cost: ${opt_result['cost']:.2f}")
            self._display_charging_schedule("OPTIMAL", opt_result['charging_schedule'])
        else:
            print(f"Status: {opt_result['status']} | Cost: N/A")
        
        print(f"\n{'─'*42} FCFS SOLUTION {'─'*42}")
        if fcfs_result['status'] == 'Optimal':
            print(f"Status: {fcfs_result['status']} | Cost: ${fcfs_result['cost']:.2f}")
            self._display_charging_schedule("FCFS", fcfs_result['charging_schedule'])
        else:
            print(f"Status: {fcfs_result['status']} | Cost: N/A")
        
        # Calculate and display 24-hour power allocation
        if opt_result['status'] == 'Optimal':
            print(f"\n{'─'*35} 24-HOUR POWER ALLOCATION {'─'*35}")
            self._display_24hour_allocation(opt_result['charging_schedule'], "OPTIMAL")
        
        if fcfs_result['status'] == 'Optimal':
            self._display_24hour_allocation(fcfs_result['charging_schedule'], "FCFS")
    
    def _display_charging_schedule(self, method_name, schedule):
        """Display the charging schedule for next few hours"""
        print(f"\n{method_name} Charging Schedule (Next 6 hours):")
        print(f"{'Time':<8} {'Station':<8} {'EV_ID':<25} {'Power(kW)':<10} {'Energy(kWh)':<12}")
        print("─" * 75)
        
        displayed_hours = 0
        for slot in schedule:
            if displayed_hours >= 6:  # Limit display to 6 hours
                break
                
            time_str = slot['time'].strftime('%H:%M')
            
            if slot['stations']:
                for station in slot['stations']:
                    ev_id = station['session_id'][:22] + "..." if len(station['session_id']) > 22 else station['session_id']
                    print(f"{time_str:<8} {station['station_id']:<8} {ev_id:<25} "
                          f"{station['charging_power']:<10.2f} {station['energy_delivered']:<12.2f}")
                displayed_hours += 1
            else:
                print(f"{time_str:<8} {'---':<8} {'No charging':<25} {'0.00':<10} {'0.00':<12}")
                displayed_hours += 1
    
    def _display_24hour_allocation(self, schedule, method_name):
        """Display power allocation for full 24 hours broken down by delta_time"""
        print(f"\n{method_name} - 24-Hour Power Distribution:")
        print("Time intervals with charging activity:")
        
        # Convert schedule to 24-hour format with smaller time intervals
        power_allocation = self._create_24hour_power_list(schedule)
        
        # Display summary statistics
        total_intervals = len(power_allocation)
        active_intervals = sum(1 for p in power_allocation if p > 0)
        max_power = max(power_allocation) if power_allocation else 0
        avg_power = sum(power_allocation) / len(power_allocation) if power_allocation else 0
        
        print(f"  Total time intervals: {total_intervals}")
        print(f"  Active intervals: {active_intervals}")
        print(f"  Max power: {max_power:.2f} kW")
        print(f"  Average power: {avg_power:.2f} kW")
        
        # Display power profile (condensed view)
        print(f"  Power profile (showing every 4th interval):")
        print(f"  {'Time':<8} {'Power(kW)':<10}")
        print("  " + "─" * 20)
        
        start_time = schedule[0]['time'] if schedule else datetime.now()
        for i in range(0, min(len(power_allocation), 96), 4):  # Show every 4th interval (96 = 24h in 15min intervals)
            interval_time = start_time + timedelta(minutes=i * (self.delta_time_minutes))
            power = power_allocation[i]
            if power > 0.01:
                print(f"  {interval_time.strftime('%H:%M'):<8} {power:<10.2f}")
    
    def _create_24hour_power_list(self, schedule):
        """Create a list of power values for 24 hours with delta_time granularity"""
        # For now, using 1-hour granularity (can be made configurable)
        # Total intervals = 24 hours * (60 minutes / delta_time_minutes)
        intervals_per_hour = 60 // self.delta_time_minutes
        total_intervals = 24 * intervals_per_hour
        
        power_list = [0.0] * total_intervals
        
        for slot in schedule:
            if slot['stations']:
                # Calculate which interval this hour corresponds to
                hour = slot['hour'] if 'hour' in slot else 0
                
                # For simplicity, distribute power evenly across all intervals in this hour
                total_power = sum(station['charging_power'] for station in slot['stations'])
                
                start_interval = hour * intervals_per_hour
                end_interval = min(start_interval + intervals_per_hour, total_intervals)
                
                for i in range(start_interval, end_interval):
                    power_list[i] = total_power
        
        return power_list
    
    def display_simulation_status(self, current_time, active_count, completed_count, speed):
        """Display current simulation status"""
        print(f"\r[{current_time.strftime('%H:%M:%S')}] "
              f"Active: {active_count} | Completed: {completed_count} | Speed: {speed:.1f}x", 
              end='', flush=True)
    
    def display_ev_status_detail(self, current_time, session_manager):
        """Display detailed charging status for each EV"""
        active_sessions = session_manager.active_sessions
        
        if not active_sessions:
            return
            
        print(f"\n{'='*90}")
        print(f"DETAILED EV CHARGING STATUS AT {current_time.strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"{'='*90}")
        
        print(f"{'EV ID':<25} {'Delivered':<12} {'Remaining':<12} {'Progress':<10} {'Time Left':<12} {'Status':<10}")
        print("─" * 90)
        
        for session in active_sessions:
            ev_id = session['sessionID'][:22] + "..." if len(session['sessionID']) > 22 else session['sessionID']
            delivered = session.get('energy_delivered', 0.0)
            remaining = session.get('remaining_energy', session['kWhDelivered'])
            total_needed = session['kWhDelivered']
            
            # Calculate progress percentage
            if total_needed > 0:
                progress = (delivered / total_needed) * 100
            else:
                progress = 100.0
            
            # Calculate estimated time left
            disconnect_time = session['disconnectTime_dt']
            time_left = disconnect_time - current_time
            time_left_str = f"{int(time_left.total_seconds() / 3600):02d}:{int((time_left.total_seconds() % 3600) / 60):02d}"
            
            # Determine status
            if remaining <= 0.01:
                status = "COMPLETED"
            elif current_time >= disconnect_time:
                status = "DEPARTED"
            else:
                status = "CHARGING"
            
            print(f"{ev_id:<25} {delivered:<12.2f} {remaining:<12.2f} {progress:<10.1f}% {time_left_str:<12} {status:<10}")
    
    def display_charging_step_update(self, current_time, session_manager, step_duration_minutes=60):
        """Display energy changes in the last time step"""
        active_sessions = session_manager.active_sessions
        
        if not active_sessions:
            return
            
        print(f"\n{'─'*80}")
        print(f"CHARGING UPDATE - Last {step_duration_minutes} minutes ending at {current_time.strftime('%H:%M:%S')}")
        print(f"{'─'*80}")
        
        has_updates = False
        for session in active_sessions:
            # Check if this session had any energy delivery in the last step
            last_update = session.get('last_update_time', session['connectionTime_dt'])
            time_since_update = (current_time - last_update).total_seconds() / 60  # minutes
            
            if time_since_update <= step_duration_minutes + 5:  # Allow 5 min buffer
                delivered = session.get('energy_delivered', 0.0)
                remaining = session.get('remaining_energy', session['kWhDelivered'])
                
                # Calculate energy delivered in this step (approximate)
                energy_this_step = delivered - session.get('prev_energy_delivered', 0.0)
                session['prev_energy_delivered'] = delivered
                
                if energy_this_step > 0.01:  # Only show if significant energy was delivered
                    has_updates = True
                    ev_id = session['sessionID'][:30] + "..." if len(session['sessionID']) > 30 else session['sessionID']
                    print(f"  {ev_id:<35} +{energy_this_step:>6.2f} kWh → {remaining:>7.2f} kWh remaining")
        
        if not has_updates:
            print("  No charging activity in this time step")
    
    def display_station_allocation(self, current_time, opt_result, active_sessions):
        """Display current station allocation for each EV"""
        if opt_result['status'] != 'Optimal' or not opt_result['charging_schedule']:
            return
            
        print(f"\n{'─'*70}")
        print(f"STATION ALLOCATION AT {current_time.strftime('%H:%M:%S')}")
        print(f"{'─'*70}")
        
        # Get current time slot (first slot in schedule)
        current_slot = opt_result['charging_schedule'][0]
        
        if current_slot['stations']:
            print(f"{'Station':<10} {'EV ID':<30} {'Power (kW)':<12} {'Energy (kWh)':<15}")
            print("─" * 70)
            
            for station in current_slot['stations']:
                ev_id = station['session_id'][:27] + "..." if len(station['session_id']) > 27 else station['session_id']
                print(f"{station['station_id']:<10} {ev_id:<30} {station['charging_power']:<12.2f} {station['energy_delivered']:<15.2f}")
        else:
            print("No active charging stations at this time")
