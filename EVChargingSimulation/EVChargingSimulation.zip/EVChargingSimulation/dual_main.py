"""
Main script to run both optimization and FCFS charging systems side by side
Integrates both algorithms for comparison
"""

import threading
import time
from datetime import datetime, timedelta
from data_loader import DataLoader
from session_manager import SessionManager
from simulation_clock import SimulationClock
from fcfs_manager import FCFSChargingManager
from dual_charging_ui_clean import DualChargingUI
from simple_tcp_sender import SimpleTCPDataSender
from fcfs_data_sender import FCFSDataSender

class DualChargingSimulation:
    def __init__(self):
        # Initialize data loader
        self.data_loader = DataLoader()
        
        # Load data
        print("📊 Loading EV charging session data...")
        self.sessions_data = self.data_loader.load_sessions_data()
        self.price_data = self.data_loader.load_price_data()
        print(f"✅ Loaded {len(self.sessions_data)} sessions")
          # Initialize simulation clock
        self.simulation_clock = SimulationClock(
            start_time=datetime(2019, 1, 1, 0, 0, 0),
            end_time=datetime(2019, 1, 7, 23, 59, 59),
            speed_multiplier=10.0
        )
        
        # Initialize optimization system (existing)
        self.optimization_session_manager = SessionManager()
        self.optimization_session_manager.price_data = self.price_data
        self.optimization_session_manager.data_loader = self.data_loader
        
        # Initialize FCFS system (new)
        self.fcfs_manager = FCFSChargingManager(max_stations=20, max_total_power=300.0)
        
        # Data senders
        self.optimization_data_sender = SimpleTCPDataSender(
            self.optimization_session_manager, 
            self.simulation_clock, 
            port=8765
        )
        
        self.fcfs_data_sender = FCFSDataSender(
            self.fcfs_manager,
            self.simulation_clock,
            port=8766
        )
        
        # UI
        self.ui = DualChargingUI(
            self.optimization_session_manager,
            self.simulation_clock,
            self.fcfs_manager
        )
        
        # Control flags
        self.running = False
        self.paused = False        
    def start_simulation(self):
        """Start the dual charging simulation"""
        print("🚀 Starting Dual Charging Simulation...")
        
        self.running = True
        
        # Start data senders
        self.optimization_data_sender.start()
        self.fcfs_data_sender.start()
        
        # Start simulation threads
        optimization_thread = threading.Thread(target=self.run_optimization_simulation, daemon=True)
        fcfs_thread = threading.Thread(target=self.run_fcfs_simulation, daemon=True)
        
        optimization_thread.start()
        fcfs_thread.start()
        
        print("✅ Both simulation systems started!")
        
        # Start UI (this will block)
        self.ui.run()
        
    def run_optimization_simulation(self):
        """Run the optimization-based simulation"""
        print("🎯 Starting optimization simulation thread...")
        
        processed_sessions = set()
        
        while self.running:
            try:
                if not self.paused:
                    current_time = self.simulation_clock.get_current_time()
                    
                    # Check for new arrivals
                    new_arrivals = self.optimization_session_manager.check_arrivals(
                        self.sessions_data, current_time
                    )
                    
                    # Process new arrivals
                    for session in new_arrivals:
                        session_id = session['sessionID']
                        if session_id not in processed_sessions:
                            self.optimization_session_manager.add_active_session(session)
                            processed_sessions.add(session_id)
                            print(f"🚗 OPT: New arrival - {session_id[:15]}...")
                      # Update active sessions
                    self.optimization_session_manager.update_energy_delivered(current_time)
                    
                    # Remove completed sessions
                    self.optimization_session_manager.remove_completed_sessions(current_time)
                    time.sleep(0.1)  # Small delay to prevent excessive CPU usage
                
            except Exception as e:
                print(f"❌ Optimization simulation error: {e}")
                time.sleep(1)
                
    def run_fcfs_simulation(self):
        """Run the FCFS simulation"""
        print("🚗 Starting FCFS simulation thread...")
        
        processed_sessions = set()
        last_debug_time = time.time()
        
        while self.running:
            try:
                if not self.paused:
                    current_time = self.simulation_clock.get_current_time()
                    
                    # Debug every 5 seconds
                    now = time.time()
                    if now - last_debug_time > 5:
                        print(f"🕒 FCFS: Current simulation time: {current_time.strftime('%Y-%m-%d %H:%M:%S')}")
                        print(f"🚗 FCFS: Active sessions: {len(self.fcfs_manager.all_sessions)}")
                        last_debug_time = now
                    
                    # Check for new arrivals
                    for session in self.sessions_data:
                        session_id = session['sessionID']
                        arrival_time = session['connectionTime_dt']
                        
                        # Check if this session should arrive now
                        time_diff = (current_time - arrival_time).total_seconds()
                        
                        if (0 <= time_diff <= 60 and  # Arrived within last minute
                            session_id not in processed_sessions):
                            
                            self.fcfs_manager.add_session(session)
                            processed_sessions.add(session_id)
                            print(f"🚗 FCFS: New arrival - {session_id[:15]}...")
                    
                    # Update FCFS charging process
                    self.fcfs_manager.update_charging(current_time)
                    
                time.sleep(0.1)  # Small delay to prevent excessive CPU usage
                
            except Exception as e:
                print(f"❌ FCFS simulation error: {e}")
                time.sleep(1)
                
    def pause_simulation(self):
        """Pause the simulation"""
        self.paused = True
        print("⏸️ Simulation paused")
        
    def resume_simulation(self):
        """Resume the simulation"""
        self.paused = False
        print("▶️ Simulation resumed")
        
    def stop_simulation(self):
        """Stop the simulation"""
        print("🛑 Stopping simulation...")
        
        self.running = False
        
        # Stop data senders
        self.optimization_data_sender.stop()
        self.fcfs_data_sender.stop()
        
        # Stop simulation clock
        self.simulation_clock.stop()
        
        # Destroy UI
        self.ui.destroy()
        
        print("✅ Simulation stopped")

def main():
    """Main function"""
    print("🔋 EV Charging Simulation - Optimization vs FCFS")
    print("=" * 60)
    
    try:
        # Create and start simulation
        simulation = DualChargingSimulation()
        simulation.start_simulation()
        
    except KeyboardInterrupt:
        print("\n🛑 Simulation interrupted by user")
    except Exception as e:
        print(f"❌ Simulation error: {e}")
    finally:
        print("🏁 Simulation ended")

if __name__ == "__main__":
    main()
