"""
Optimization Module
Handles both optimal and FCFS charging algorithms
"""

import pulp
from datetime import datetime, timedelta

class OptimizationSolver:
    def __init__(self):
        pass
    def prepare_data(self, active_sessions, price_data, solar_data, max_data, current_time, optimization_horizon_hours, station_manager=None):
        """
        Prepare optimization data from raw inputs
        
        Args:
            active_sessions: List of active charging sessions
            price_data: Electricity price data
            solar_data: Solar generation data
            max_data: Maximum charging rates and grid capacity
            current_time: Current simulation time
            optimization_horizon_hours: Hours to optimize ahead
            station_manager: Station manager for consistent assignments (optional)
            
        Returns:
            dict: Data for optimization
        """
        if not active_sessions:
            return None
            
        T = optimization_horizon_hours
        N = len(active_sessions)
        
        # Build price vector
        p_grid = []
        for t in range(T):
            time_point = current_time + timedelta(hours=t)
            day_str = time_point.strftime("%Y-%m-%d")
            hour_index = time_point.hour
            price = price_data.get(day_str, [0]*24)[hour_index] if day_str in price_data else 0
            price = price / 1000  # Convert to appropriate units
            p_grid.append(price)
        
        # Build renewable energy vector
        R = []
        for t in range(T):
            time_point = current_time + timedelta(hours=t)
            solar_key = time_point.strftime("%Y%m%d")
            hour_index = time_point.hour
            if solar_key in solar_data and hour_index < len(solar_data[solar_key]):
                R_val = solar_data[solar_key][hour_index]["R(i)"]
            else:
                R_val = 0
            R.append(R_val)
          # Build availability matrix and requirements
        A_matrix = []
        L_req = []
        session_ids = []
        
        print(f"\n🔍 PREPARING DATA DEBUG:")
        print(f"   Current time: {current_time.strftime('%H:%M:%S')}")
        print(f"   Optimization horizon: {T} hours")
        for i, session in enumerate(active_sessions):
            # 🔧 CRITICAL FIX: Use virtual arrival time for re-optimization
            # For new EVs: use max(connectionTime_dt, current_time)
            # For existing EVs being re-optimized: connectionTime_dt is already updated to current_time
            original_arrival = session.get('original_arrival_time', session['connectionTime_dt'])
            virtual_arrival = session['connectionTime_dt']  # This is current_time for re-optimization
            session_start = max(virtual_arrival, current_time)
            session_end = session['disconnectTime_dt']
            
            print(f"\n   EV {i} ({session['sessionID'][:15]}...):")
            print(f"     Original connection: {original_arrival.strftime('%H:%M:%S')}")
            print(f"     Virtual arrival: {virtual_arrival.strftime('%H:%M:%S')}")
            print(f"     Current time: {current_time.strftime('%H:%M:%S')}")
            print(f"     Departure: {session_end.strftime('%H:%M:%S')}")
            print(f"     Effective start: {session_start.strftime('%H:%M:%S')}")
            
            # Calculate availability for each time slot
            availability = []

            # Làm tròn current_time về đầu giờ
            optimization_start = current_time.replace(minute=0, second=0, microsecond=0)
            print(f"     Optimization start (rounded): {optimization_start.strftime('%H:%M:%S')}")
            
            for t in range(T):
                slot_start = optimization_start + timedelta(hours=t)
                slot_end = slot_start + timedelta(hours=1)
                
                # Calculate overlap fraction
                effective_start = max(slot_start, session_start)
                effective_end = min(slot_end, session_end)
                
                if effective_end > effective_start:
                    fraction = (effective_end - effective_start).total_seconds() / 3600.0
                    fraction = min(fraction, 1.0)
                else:
                    fraction = 0.0
                
                availability.append(fraction)
                
                if t < 3:  # Only show first 3 slots to avoid spam
                    print(f"       Slot {t} ({slot_start.strftime('%H:%M')}-{slot_end.strftime('%H:%M')}): {fraction:.3f}")
            
            A_matrix.append(availability)
            
            # Use remaining energy requirement
            # remaining_energy = session.get('kWhDelivered', session.get('remaining_energy', 0))
            remaining_energy = session.get('remaining_demand', session['remaining_energy'])
            L_req.append(remaining_energy)
            session_ids.append(session['sessionID'])
            
            total_availability = sum(availability)
            print(f"     Total availability: {total_availability:.2f} hours")
            print(f"     Remaining energy: {remaining_energy:.2f} kWh")
        
        # System parameters
        s = max_data.get('max_charging_rate', 81)  # Max charging rate per station
        eta = 0.9  # Charging efficiency
        C_grid = max_data.get('grid_capacity', 300)  # Grid capacity
        delta_t = 1.0  # Time step in hours        
        return {
            'T': T,
            'N': N,
            'A': A_matrix,
            'L_req': L_req,
            's': s,
            'eta': eta,
            'p_grid': p_grid,
            'R': R,
            'C_grid': C_grid,
            'delta_t': delta_t,
            'current_time': current_time,
            'session_ids': session_ids,
            'station_manager': station_manager  # Add station_manager to data
        }

    def solve_optimization(self, data):
        """Solve the optimal charging problem using linear programming"""
        try:
            T = data['T']
            N = data['N']
            A = data['A']
            L_req = data['L_req']
            s = data['s']
            eta = data['eta']
            p_grid = data['p_grid']
            R_list = data['R']
            C_grid = data['C_grid']
            delta_t = data['delta_t']
            
            if N == 0:
                return {'status': 'No sessions', 'cost': 0, 'charging_schedule': []}
            
            # 🔍 CRITICAL DEBUG: Feasibility Analysis
            print(f"\n🔍 LP FEASIBILITY DEBUG:")
            print(f"   📊 Problem Size: {N} EVs, {T} time slots")
            print(f"   ⚡ Grid Capacity: {C_grid} kW")
            print(f"   🔋 Max Station Power: {s} kW")
            print(f"   ⏱️ Time Step: {delta_t} hours")
            print(f"   🌟 Efficiency: {eta}")
            
            # Check total demand vs total supply capacity
            total_demand = sum(L_req)
            total_supply_capacity = C_grid * T * delta_t
            print(f"   📈 Total Demand: {total_demand:.2f} kWh")
            print(f"   📉 Total Supply Capacity: {total_supply_capacity:.2f} kWh")
            print(f"   📊 Demand/Supply Ratio: {total_demand/total_supply_capacity:.3f}")
            
            # Check individual EV feasibility
            print(f"\n🔍 INDIVIDUAL EV FEASIBILITY:")
            infeasible_evs = []
            for i in range(N):
                available_slots = sum(A[i])
                max_possible_energy = available_slots * s * delta_t * eta
                demand = L_req[i]
                
                print(f"   EV {i}: Demand={demand:.2f} kWh, Available_slots={available_slots:.1f}, Max_possible={max_possible_energy:.2f} kWh")
                
                if demand > max_possible_energy + 0.001:  # Small tolerance
                    print(f"   ❌ EV {i} IMPOSSIBLE: Demand {demand:.2f} > Max_possible {max_possible_energy:.2f}")
                    infeasible_evs.append(i)
                elif demand > max_possible_energy * 0.95:  # 95% threshold
                    print(f"   ⚠️ EV {i} TIGHT: Demand very close to maximum possible")
            
            # Check renewable constraints
            print(f"\n🔍 RENEWABLE/GRID CONSTRAINTS:")
            problematic_slots = []
            for t in range(T):
                renewable_available = R_list[t] if t < len(R_list) else 0
                effective_capacity = C_grid + renewable_available
                max_possible_load = N * s  # All EVs at max power
                
                print(f"   Slot {t}: Grid={C_grid}, Renewable={renewable_available}, Effective={effective_capacity:.1f}, Max_load={max_possible_load}")
                
                if effective_capacity < max_possible_load * 0.5:  # If effective capacity is much less than potential load
                    print(f"   ⚠️ Slot {t} CONSTRAINED: Limited capacity vs potential demand")
                    problematic_slots.append(t)
            
            # Early termination if clearly infeasible
            if infeasible_evs:
                print(f"   ❌ EARLY TERMINATION: {len(infeasible_evs)} EVs have impossible demands")
                return {'status': 'Infeasible', 'cost': None, 'charging_schedule': [], 'debug_info': {
                    'infeasible_evs': infeasible_evs,
                    'reason': 'Individual EV demands exceed maximum possible energy'
                }}
            
            # Create the optimization problem
            problem = pulp.LpProblem("EV_Charging_Optimization", pulp.LpMinimize)
            
            # Decision variables
            Y = pulp.LpVariable.dicts("Y", ((i, t) for i in range(N) for t in range(T)),
                                      lowBound=0, cat=pulp.LpContinuous)
            S_plus = pulp.LpVariable.dicts("S_plus", (t for t in range(T)),
                                           lowBound=0, cat=pulp.LpContinuous)
            R_used = pulp.LpVariable.dicts("R_used", (t for t in range(T)),
                                           lowBound=0, cat=pulp.LpContinuous)
            
            # Objective function: minimize grid electricity cost
            problem += pulp.lpSum([p_grid[t] * S_plus[t] * delta_t for t in range(T)]), "Minimize_Cost"
            
            # Energy requirement constraints
            for i in range(N):
                available_slots = [t for t in range(T) if A[i][t] > 0]
                if available_slots:  # Only add constraint if EV has availability
                    problem += eta * pulp.lpSum([Y[(i, t)] * delta_t for t in available_slots]) >= L_req[i], f"EnergyReq_EV_{i}"
            
            # Power constraints
            for i in range(N):
                for t in range(T):
                    problem += Y[(i, t)] <= s, f"MaxPower_EV_{i}_t_{t}"
                    problem += Y[(i, t)] <= s * A[i][t], f"Presence_EV_{i}_t_{t}"
            
            # Grid and renewable constraints
            for t in range(T):
                total_load = pulp.lpSum([Y[(i, t)] for i in range(N)])
                problem += total_load - R_used[t] <= C_grid, f"GridLimit_t_{t}"
                problem += S_plus[t] >= total_load - R_used[t], f"SplusPositivity_t_{t}"
                problem += R_used[t] <= R_list[t], f"RenewableLimit_t_{t}"
              # Solve the problem
            print(f"\n⚡ STARTING LP SOLVER...")
            problem.solve(pulp.PULP_CBC_CMD(msg=0))
            status = pulp.LpStatus[problem.status]
            
            print(f"🔍 LP SOLVER RESULT: {status}")
            
            # DETAILED INFEASIBILITY ANALYSIS
            if status != 'Optimal':
                print(f"\n❌ LP INFEASIBILITY ANALYSIS:")
                print(f"   Status: {status}")
                
                # Check constraint violations
                print(f"\n🔍 CONSTRAINT ANALYSIS:")
                
                # Check energy constraints
                energy_violations = []
                for i in range(N):
                    available_slots = [t for t in range(T) if A[i][t] > 0]
                    if available_slots:
                        max_energy = sum(s * A[i][t] * delta_t * eta for t in available_slots)
                        demand = L_req[i]
                        if demand > max_energy:
                            energy_violations.append((i, demand, max_energy))
                            print(f"   ❌ EV {i}: Energy impossible - Demand {demand:.2f} > Max {max_energy:.2f}")
                
                # Check grid capacity issues
                grid_violations = []
                for t in range(T):
                    max_simultaneous_demand = sum(s for i in range(N) if A[i][t] > 0)
                    renewable = R_list[t] if t < len(R_list) else 0
                    effective_capacity = C_grid + renewable
                    if max_simultaneous_demand > effective_capacity:
                        grid_violations.append((t, max_simultaneous_demand, effective_capacity))
                        print(f"   ❌ Slot {t}: Grid overload - Demand {max_simultaneous_demand:.1f} > Capacity {effective_capacity:.1f}")
                
                # Check time horizon issues
                total_available_time = sum(sum(A[i]) for i in range(N)) * delta_t
                total_needed_time = sum(L_req[i] / (s * eta) for i in range(N))
                if total_needed_time > total_available_time:
                    print(f"   ❌ Time insufficient: Need {total_needed_time:.2f}h, Available {total_available_time:.2f}h")
                
                return {
                    'status': status, 
                    'cost': None, 
                    'charging_schedule': [],
                    'debug_info': {
                        'energy_violations': energy_violations,
                        'grid_violations': grid_violations,
                        'total_demand': sum(L_req),
                        'total_capacity': total_supply_capacity,
                        'problematic_slots': problematic_slots
                    }
                }
            
            if status == 'Optimal':
                obj_val = pulp.value(problem.objective)
                
                # Extract charging schedule
                charging_schedule = []
                for t in range(T):
                    time_slot = data['current_time'] + timedelta(hours=t)
                    slot_data = {
                        'time': time_slot,
                        'hour': t,
                        'stations': []
                    }
                    
                    for i in range(N):
                        charging_power = pulp.value(Y[(i, t)]) if Y[(i, t)] is not None else 0
                        if charging_power > 0.001:  # Only include if significant charging
                            slot_data['stations'].append({
                                'station_id': i,
                                'session_id': data['session_ids'][i],
                                'charging_power': charging_power,
                                'energy_delivered': charging_power * delta_t
                            })
                    
                    charging_schedule.append(slot_data)
                
                return {
                    'status': status,
                    'cost': obj_val,
                    'charging_schedule': charging_schedule
                }
            else:
                return {'status': status, 'cost': None, 'charging_schedule': []}
                
        except Exception as e:
            print(f"Optimization error: {e}")
            return {'status': 'Error', 'cost': None, 'charging_schedule': []}
    
    def solve_fcfs(self, data):
        """Solve using First-Come-First-Serve algorithm with grid constraints"""
        try:
            T = data['T']
            N = data['N']
            A = data['A']
            L_req = data['L_req']
            s = data['s']
            eta = data['eta']
            p_grid = data['p_grid']
            R_list = data['R']
            C_grid = data['C_grid']
            session_ids = data['session_ids']
            
            if N == 0:
                return {'status': 'No sessions', 'cost': 0, 'charging_schedule': []}
            
            # Track remaining energy needs (accounting for efficiency)
            needed = [L_req[i] / eta for i in range(N)]
            
            # Track charging decisions
            X = [[0.0] * T for _ in range(N)]
            
            STATION_LIMIT = 80  # Maximum number of stations
            
            # Process each time slot
            for t in range(T):
                grid_leftover = C_grid
                station_count = 0
                
                # Find sessions that need energy and are present
                available_sessions = []
                for i in range(N):
                    if needed[i] > 0.001 and A[i][t] > 0:
                        available_sessions.append(i)
                
                # Process in FCFS order (already sorted by arrival time)
                for i in available_sessions:
                    if station_count >= STATION_LIMIT or grid_leftover <= 0.001:
                        break
                    
                    # Calculate maximum deliverable energy
                    max_station_output = s * A[i][t]  # Station capacity * availability
                    deliverable = min(max_station_output, needed[i], grid_leftover)
                    
                    if deliverable > 0.001:
                        X[i][t] = deliverable
                        needed[i] -= deliverable
                        grid_leftover -= deliverable
                        station_count += 1
            
            # Calculate total cost
            total_cost = 0.0
            charging_schedule = []
            
            for t in range(T):
                time_slot = data['current_time'] + timedelta(hours=t)
                total_load_t = sum(X[i][t] for i in range(N))
                used_renewable = min(R_list[t], total_load_t)
                grid_usage = total_load_t - used_renewable
                cost_t = p_grid[t] * grid_usage
                total_cost += cost_t
                
                # Build schedule for this time slot
                slot_data = {
                    'time': time_slot,
                    'hour': t,
                    'stations': []
                }
                
                for i in range(N):
                    if X[i][t] > 0.001:
                        slot_data['stations'].append({
                            'station_id': i,
                            'session_id': session_ids[i],
                            'charging_power': X[i][t],
                            'energy_delivered': X[i][t]  # Since delta_t = 1
                        })
                
                charging_schedule.append(slot_data)
            
            return {
                'status': 'Optimal',
                'cost': total_cost,
                'charging_schedule': charging_schedule
            }
            
        except Exception as e:
            print(f"FCFS error: {e}")
            return {'status': 'Error', 'cost': None, 'charging_schedule': []}
