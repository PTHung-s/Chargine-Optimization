"""
Main module for Real-time EV Charging Simulation
Runs a real-time simulation clock that processes EV sessions as they arrive
"""

import json
from datetime import datetime, timedelta
from data_loader import DataLoader
from simulation_clock import SimulationClock
from session_manager import SessionManager
from optimization import OptimizationSolver
from visualizer import Visualizer

def main():
    print("=== Real-time EV Charging Simulation ===")
    
    # Initialize components
    data_loader = DataLoader()
    session_manager = SessionManager()
    optimizer = OptimizationSolver()
    visualizer = Visualizer()
    
    # Load data
    print("Loading data...")
    try:
        price_data, solar_data, final_gop_data, max_data = data_loader.load_all_data()
    except Exception as e:
        print(f"Error loading data: {e}")
        print("Please make sure all required data files exist in the correct locations.")
        return
    
    # Set simulation parameters
    start_date = datetime.strptime("25-04-2018", "%d-%m-%Y")
    end_date = datetime.strptime("27-04-2018", "%d-%m-%Y")  # 2 days for testing
    
    # Filter data for simulation period
    price_data = data_loader.filter_price_data(price_data, start_date, end_date)
    solar_data = data_loader.filter_solar_data(solar_data, start_date, end_date)
    
    # Prepare EV sessions
    sessions = data_loader.prepare_sessions(final_gop_data, start_date, end_date)
      # Initialize simulation clock with faster speed for testing
    simulation_clock = SimulationClock(
        start_time=start_date,
        end_time=end_date,
        speed_multiplier=50.0  # Start with 50x speed for faster testing
    )
    
    # Show first few EV arrival times
    if sessions:
        print(f"Simulation period: {start_date} to {end_date}")
        print(f"Total EV sessions: {len(sessions)}")
        print("\nFirst 5 EV arrivals:")
        for i, session in enumerate(sessions[:5]):
            print(f"  {i+1}. {session['connectionTime_dt'].strftime('%Y-%m-%d %H:%M:%S')} - "
                  f"EV {session['sessionID'][:20]}... ({session['kWhDelivered']:.1f} kWh)")
        
        first_arrival = sessions[0]['connectionTime_dt']
        time_to_first = (first_arrival - start_date).total_seconds() / 3600
        print(f"\nTime to first EV: {time_to_first:.1f} hours")
        print(f"At {simulation_clock.speed_multiplier}x speed: {time_to_first/simulation_clock.speed_multiplier*60:.1f} minutes")
    
    print(f"\nInitial speed: {simulation_clock.speed_multiplier}x")
    print("\nStarting simulation...")
    print("Commands:")
    print("  Type 'speed <number>' and press Enter to change speed (e.g., 'speed 100')")
    print("  Type 'status' and press Enter to show detailed EV status")
    print("  Type 'quit' and press Enter to exit")
    print("  Note: Input is handled in a separate thread, so you can type commands anytime")
    print("-" * 60)
      # Main simulation loop
    last_display_time = simulation_clock.get_current_time()
    step_counter = 0
    last_status_update = last_display_time
    
    # Find first EV arrival for countdown
    first_ev_time = sessions[0]['connectionTime_dt'] if sessions else None
    
    while simulation_clock.is_running():
        current_time = simulation_clock.get_current_time()
        
        # Show countdown to first EV every 30 seconds
        if first_ev_time and current_time < first_ev_time:
            time_diff = (current_time - last_status_update).total_seconds()
            if time_diff >= 30:  # Every 30 real seconds
                time_to_first = (first_ev_time - current_time).total_seconds() / 3600
                print(f"\r[{current_time.strftime('%H:%M:%S')}] "
                      f"Waiting for first EV... {time_to_first:.1f}h remaining "
                      f"(Speed: {simulation_clock.speed_multiplier:.0f}x)", end="", flush=True)
                last_status_update = current_time
        
        # Check for new arriving EVs
        new_arrivals = session_manager.check_arrivals(sessions, current_time)
        
        if new_arrivals:
            print(f"\n{'='*80}")
            print(f"🚗 NEW EV ARRIVALS at {current_time.strftime('%Y-%m-%d %H:%M:%S')}")
            print(f"{'='*80}")
            
            # Add new arrivals
            for ev in new_arrivals:
                print(f"  ✅ EV {ev['sessionID'][:20]}... arrived")
                print(f"     Needs: {ev['kWhDelivered']:.2f} kWh | Departs: {ev['disconnectTime_dt'].strftime('%H:%M:%S')}")
                session_manager.add_active_session(ev)
            
            # 🔥 CRITICAL: Prepare all sessions (old + new) for re-optimization
            print(f"\n📊 PREPARING FOR RE-OPTIMIZATION:")
            print(f"   Active EVs: {len(session_manager.active_sessions)}")
            
            # Update all sessions to current state for LP solver
            sessions_for_lp = session_manager.prepare_sessions_for_reoptimization(current_time)
            
            # Calculate optimization horizon
            earliest_departure = min([s['disconnectTime_dt'] for s in sessions_for_lp])
            optimization_horizon_hours = max(1, int((earliest_departure - current_time).total_seconds() / 3600))
            
            print(f"   Horizon: {current_time.strftime('%H:%M')} to {earliest_departure.strftime('%H:%M')}")
            print(f"   Duration: {optimization_horizon_hours} hours")
            
            print(f"\n⚡ SOLVING OPTIMIZATION...")
            
            # Prepare optimization data
            opt_data = optimizer.prepare_data(
                sessions_for_lp, price_data, solar_data, max_data, 
                current_time, optimization_horizon_hours
            )
            
            if opt_data:
                # Run optimization with prepared data
                opt_result = optimizer.solve_optimization(opt_data)
                fcfs_result = optimizer.solve_fcfs(opt_data)
                
                # Apply results to real sessions
                session_manager.apply_optimization_results(opt_result, current_time)
                session_manager.update_sessions_after_reoptimization(sessions_for_lp)
            else:
                print("   No optimization data prepared (no active sessions)")
                opt_result = {'status': 'No sessions', 'cost': 0, 'charging_schedule': []}
                fcfs_result = {'status': 'No sessions', 'cost': 0, 'charging_schedule': []}
        
        # Every 10 simulation steps, show energy updates
        step_counter += 1
        time_since_last_display = (current_time - last_display_time).total_seconds() / 60  # minutes
        
        if step_counter % 10 == 0 or time_since_last_display >= 60:  # Every 10 steps or every hour
            if session_manager.active_sessions:
                visualizer.display_charging_step_update(current_time, session_manager)
                visualizer.display_ev_status_detail(current_time, session_manager)
            last_display_time = current_time
        
        # Update remaining energy for active sessions
        session_manager.update_energy_delivered(current_time)
        
        # Remove completed sessions
        completed = session_manager.remove_completed_sessions(current_time)
        if completed:
            print(f"[{current_time.strftime('%H:%M:%S')}] {len(completed)} EVs completed charging")
            for ev in completed:
                print(f"  ✓ EV {ev['sessionID'][:20]}... finished - "
                      f"Delivered: {ev.get('energy_delivered', 0):.2f}/{ev['kWhDelivered']:.2f} kWh")
        
        # Show brief status update
        active_count = len(session_manager.active_sessions)
        completed_count = len(session_manager.completed_sessions)
        if active_count > 0:
            visualizer.display_simulation_status(current_time, active_count, completed_count, 
                                               simulation_clock.speed_multiplier)
        
        # Advance simulation clock
        simulation_clock.tick()
        
        # Check for user input (non-blocking)
        user_input = simulation_clock.check_user_input()
        if user_input:
            if user_input.startswith('speed '):
                try:
                    new_speed = float(user_input.split()[1])
                    simulation_clock.set_speed(new_speed)
                    print(f"\nSpeed changed to {new_speed}x")
                except ValueError:
                    print("\nInvalid speed value")
            elif user_input == 'status':
                print("\n" + "="*60)
                visualizer.display_ev_status_detail(current_time, session_manager)
                print("="*60)
            elif user_input == 'quit':
                break
    
    print("\nSimulation completed!")

if __name__ == "__main__":
    main()