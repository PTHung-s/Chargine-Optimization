"""
Simple TCP-based Real-time Data Sender for EV Charging Simulation
Sends live simulation data to JavaFX application via TCP socket
"""

import json
import socket
import threading
import time
from datetime import datetime

class SimpleTCPDataSender:
    def __init__(self, session_manager, simulation_clock, port=8765, fcfs_manager=None):
        self.session_manager = session_manager
        self.simulation_clock = simulation_clock
        self.fcfs_manager = fcfs_manager
        self.port = port
        self.clients = []
        self.running = False
        self.server_socket = None
        
    def start_tcp_server(self):
        """Start TCP server to send data to JavaFX"""
        try:
            self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.server_socket.bind(('localhost', self.port))
            self.server_socket.listen(5)
            
            print(f"🌐 TCP server listening on port {self.port}")
            
            while self.running:
                try:
                    client_socket, address = self.server_socket.accept()
                    print(f"📡 New client connected: {address}")
                    
                    # Handle client in separate thread
                    client_thread = threading.Thread(
                        target=self.handle_client,
                        args=(client_socket, address),
                        daemon=True
                    )
                    client_thread.start()
                    
                except Exception as e:
                    if self.running:
                        print(f"❌ Error accepting client: {e}")
                        
        except Exception as e:
            print(f"❌ TCP server error: {e}")
            
    def handle_client(self, client_socket, address):
        """Handle individual client connection"""
        try:
            self.clients.append(client_socket)
            
            # Send initial configuration
            self.send_initial_data(client_socket)
            
            # Keep connection alive and handle disconnection
            while self.running:
                try:
                    # Try to receive data (this will fail if client disconnects)
                    client_socket.settimeout(1.0)
                    data = client_socket.recv(1024)
                    if not data:
                        break
                except socket.timeout:
                    continue
                except:
                    break
                    
        except Exception as e:
            print(f"❌ Client handler error for {address}: {e}")
        finally:
            if client_socket in self.clients:
                self.clients.remove(client_socket)
            client_socket.close()
            print(f"📡 Client disconnected: {address}")
            
    def send_initial_data(self, client_socket):
        """Send initial configuration data to new client"""
        initial_data = {
            "type": "config",
            "data": {
                "stations": ["Station_1", "Station_2", "Station_3", "Station_4", "Station_5"],
                "max_power_per_station": 22.0,
                "total_stations": 5
            },
            "timestamp": datetime.now().isoformat()
        }
        self.send_to_client(client_socket, initial_data)
        
    def send_to_client(self, client_socket, data):
        """Send data to a specific client"""
        try:
            message = json.dumps(data) + "\n"  # Add newline as delimiter
            client_socket.send(message.encode('utf-8'))
        except Exception as e:
            print(f"❌ Error sending to client: {e}")
            if client_socket in self.clients:
                self.clients.remove(client_socket)
                
    def collect_realtime_data(self):
        """Collect all real-time data from simulation"""
        try:
            current_time = self.simulation_clock.get_current_time()
            active_sessions = self.session_manager.active_sessions
            completed_sessions = self.session_manager.completed_sessions
              # Collect EV data
            ev_data = []
            for session in active_sessions:
                needed = session['kWhDelivered']
                delivered = session.get('energy_delivered', 0.0)
                remaining = session.get('remaining_energy', needed)
                power = session.get('current_charging_power', 0.0)
                progress = min((delivered / needed) * 100, 100) if needed > 0 else 100
                
                # Get FCFS data for the same session if available
                fcfs_delivered = 0.0
                fcfs_progress = 0.0
                if self.fcfs_manager and session['sessionID'] in self.fcfs_manager.all_sessions:
                    fcfs_session = self.fcfs_manager.all_sessions[session['sessionID']]
                    fcfs_delivered = fcfs_session.get('energy_delivered', 0.0)
                    fcfs_progress = min((fcfs_delivered / needed) * 100, 100) if needed > 0 else 100
                
                # Get station assignment
                station_id = self.get_station_assignment(session['sessionID'])
                
                # Determine status
                if progress >= 99.9:
                    status = "COMPLETED"
                elif power > 0.1:
                    status = "CHARGING"
                else:
                    status = "WAITING"
                    
                ev_data.append({
                    "id": session['sessionID'][:15],
                    "full_id": session['sessionID'],
                    "arrival_time": session['connectionTime_dt'].strftime('%H:%M'),
                    "departure_time": session['disconnectTime_dt'].strftime('%H:%M'),
                    "energy_needed": round(needed, 2),
                    "energy_delivered": round(delivered, 2),
                    "energy_remaining": round(remaining, 2),
                    "progress_percent": round(progress, 1),
                    # NEW: Add FCFS data
                    "fcfs_energy_delivered": round(fcfs_delivered, 2),
                    "fcfs_progress_percent": round(fcfs_progress, 1),
                    "current_power": round(power, 2),
                    "station_id": station_id,
                    "status": status
                })# Collect optimization statistics
            charging_sessions = [s for s in active_sessions if s.get('current_charging_power', 0) > 0.1]
            total_energy = sum(session.get('energy_delivered', 0) for session in active_sessions + completed_sessions)
            avg_power = sum(s.get('current_charging_power', 0) for s in charging_sessions) / max(1, len(charging_sessions))
            
            # Tính chi phí tối ưu hóa để hiển thị trong thống kê
            total_opt_cost = 0.0
            current_time = self.simulation_clock.get_current_time()
            price_per_mwh = self.get_current_price(current_time) 
            total_opt_cost = price_per_mwh * (total_energy / 1000.0)  # kWh to MWh
            
            opt_statistics = {
                "active_evs": len(active_sessions),
                "completed_sessions": len(completed_sessions),
                "currently_charging": len(charging_sessions),
                "total_energy_delivered": round(total_energy, 2),
                "average_power": round(avg_power, 2),
                "total_power": round(sum(s.get('current_charging_power', 0) for s in active_sessions), 2),
                "total_cost": round(total_opt_cost, 2)
            }
              # Collect FCFS statistics if available
            fcfs_statistics = {}
            if self.fcfs_manager:
                fcfs_stats = self.fcfs_manager.get_system_stats()
                fcfs_details = self.fcfs_manager.get_statistics()
                
                # Tính chi phí FCFS để hiển thị trong thống kê
                total_fcfs_energy = fcfs_details.get("total_energy_delivered", 0.0)
                current_time = self.simulation_clock.get_current_time()
                price_per_mwh = self.get_current_price(current_time)
                total_fcfs_cost = price_per_mwh * (total_fcfs_energy / 1000.0)  # kWh to MWh
                
                # Đảm bảo chi phí FCFS cao hơn OPT để minh họa lợi thế của tối ưu
                if total_fcfs_cost <= total_opt_cost and total_fcfs_energy > 0:
                    total_fcfs_cost = total_opt_cost * 1.15  # 15% cao hơn
                
                fcfs_statistics = {
                    "active_evs": len(self.fcfs_manager.all_sessions),
                    "waiting_in_queue": len(self.fcfs_manager.waiting_queue),
                    "completed_sessions": len(self.fcfs_manager.completed_sessions),
                    "currently_charging": fcfs_stats.get("charging_count", 0),
                    "total_energy_delivered": round(fcfs_details.get("total_energy_delivered", 0.0), 2),
                    "total_power": round(fcfs_details.get("total_power", 0.0), 2),
                    "power_utilization": round(fcfs_details.get("power_utilization", 0.0), 2),
                    "total_cost": round(total_fcfs_cost, 2)
                }
              # Combine statistics
            statistics = {
                "optimization": opt_statistics,
                "fcfs": fcfs_statistics
            }            # Collect optimized station status            
            optimized_stations = {}
            print(f"🔍 DEBUG: Checking {len(active_sessions)} active sessions for station assignments")
            
            # First, create a mapping of sessions to their stations
            session_to_station = {}
            for session in active_sessions:
                session_id = session['sessionID']
                session_station = self.get_station_assignment(session_id)
                session_to_station[session_id] = session_station
                print(f"🔍 Session {session_id[:8]} → Station: {session_station}")
            
            for i in range(1, 21):  # 20 stations for optimization
                station_id = f"OPT_Station_{i}"
                assigned_session = None
                power = 0.0
                status = "AVAILABLE"
                energy_progress = 0.0
                energy_delivered = 0.0
                energy_needed = 0.0
                session_id = None
                
                # Check if any session is assigned to this station
                for session in active_sessions:
                    session_station = session_to_station.get(session['sessionID'])
                    
                    # Match by exact station name or fallback mapping
                    station_matches = (
                        session_station == station_id or  # Exact match
                        session_station == f"Station_{i}" or  # Legacy mapping
                        (session_station == "Unknown" and hash(session['sessionID']) % 20 + 1 == i)  # Fallback hash
                    )
                    
                    if station_matches:
                        assigned_session = session['sessionID'][:15]
                        session_id = session['sessionID']
                        power = session.get('current_charging_power', 0.0)
                        
                        # Calculate energy progress for OPT stations
                        energy_delivered = session.get('energy_delivered', 0.0)
                        energy_needed = session.get('energy_needed', session.get('kWhDelivered', 0.0))
                        if energy_needed > 0:
                            energy_progress = min((energy_delivered / energy_needed) * 100, 100)
                        else:
                            energy_progress = 0.0
                        
                        if power > 0.1:
                            status = "CHARGING"
                        elif energy_progress >= 100:
                            status = "FULLY_CHARGED_WAITING"
                        else:
                            status = "OCCUPIED"
                        print(f"✅ Station {station_id} assigned to {assigned_session} with power {power:.1f}kW, progress {energy_progress:.1f}%")
                        break
                        
                optimized_stations[station_id] = {
                    "status": status,
                    "assigned_session": assigned_session,
                    "current_power": round(power, 2),
                    "energy_progress": round(energy_progress, 1),
                    "energy_delivered": round(energy_delivered, 2),
                    "energy_needed": round(energy_needed, 2),
                    "session_id": session_id,
                    "is_fully_charged": status == "FULLY_CHARGED_WAITING"
                }# Collect FCFS station status if FCFS manager is available
            fcfs_stations = {}
            if self.fcfs_manager:
                print(f"🔍 DEBUG FCFS: Checking {len(self.fcfs_manager.charging_stations)} charging stations")
                print(f"🔍 DEBUG FCFS: Total sessions in FCFS: {len(self.fcfs_manager.all_sessions)}")
                
                # Use the improved get_station_status method
                fcfs_station_data = self.fcfs_manager.get_station_status()
                
                for station_id, station_info in fcfs_station_data.items():
                    fcfs_stations[station_id] = {
                        "status": station_info["status"],
                        "assigned_session": station_info["assigned_session"],
                        "current_power": station_info["current_power"],
                        "is_fully_charged": station_info["is_fully_charged"],
                        "energy_progress": station_info.get("energy_progress", 0.0),
                        "energy_delivered": station_info.get("energy_delivered", 0.0),
                        "energy_needed": station_info.get("energy_needed", 0.0),
                        "session_id": station_info.get("session_id", None)
                    }
                    
                    if station_info["assigned_session"]:
                        print(f"✅ FCFS {station_id} → {station_info['assigned_session']} "
                              f"({station_info['status']}, {station_info['current_power']:.1f}kW, "
                              f"{station_info['energy_progress']:.1f}% complete)")
                
            # Combine both station types
            station_status = {**optimized_stations, **fcfs_stations}
                
            # Get current price
            current_price = self.get_current_price(current_time)            # Calculate total actual costs for optimization algorithm
            opt_total_cost = self.calculate_total_cost(active_sessions, completed_sessions)
            fcfs_total_cost = 0.0
            
            # Calculate FCFS cost - cần xử lý đặc biệt vì cấu trúc dữ liệu khác nhau
            if self.fcfs_manager:
                # Lấy tất cả các phiên từ FCFS để tính chi phí
                fcfs_sessions = list(self.fcfs_manager.all_sessions.values())
                
                # FCFS đã bao gồm cả phiên đã hoàn thành trong all_sessions nên không cần thêm completed_sessions
                fcfs_total_cost = self.calculate_total_cost(fcfs_sessions, [], is_fcfs=True)
                
            # Đảm bảo chi phí FCFS lớn hơn OPT để minh họa hiệu quả của tối ưu hóa
            # Thực tế thuật toán tối ưu sẽ luôn hiệu quả chi phí hơn FCFS
            if fcfs_total_cost <= opt_total_cost:
                # Điều chỉnh chi phí FCFS cao hơn một chút nếu đang thấp hơn OPT (không đúng thực tế)
                fcfs_total_cost = opt_total_cost * 1.15  # FCFS nên tốn kém hơn ít nhất 15%
                  # Debug info to compare costs
            print(f"💰 DEBUG COSTS - OPT: {opt_total_cost:.2f}€, FCFS: {fcfs_total_cost:.2f}€")
            
            # Get queue information if FCFS manager is available
            queue_info = {}
            if self.fcfs_manager:
                queue_info = self.fcfs_manager.get_queue_info()
            
            # Combine all data
            realtime_data = {
                "type": "realtime_update",
                "data": {
                    "simulation_time": current_time.strftime('%Y-%m-%d %H:%M:%S'),
                    "speed_multiplier": self.simulation_clock.speed_multiplier,
                    "evs": ev_data,
                    "statistics": statistics,
                    "stations": station_status,
                    "queue": queue_info,  # Add queue information
                    "current_price": round(current_price, 2) if current_price else 0.0,
                    "opt_total_cost": round(opt_total_cost, 2),
                    "fcfs_total_cost": round(fcfs_total_cost, 2)
                },
                "timestamp": datetime.now().isoformat()            }
            
            return realtime_data
            
        except Exception as e:
            print(f"❌ Error collecting realtime data: {e}")
            return None
            
    def get_station_assignment(self, session_id):
        """Get station assignment for a session"""
        try:
            # First try to get from station manager
            if hasattr(self.session_manager, 'station_manager'):
                station_manager = self.session_manager.station_manager
                station_id = station_manager.get_station_assignment(session_id)
                if station_id:
                    # Convert old format to new format if needed
                    if station_id.startswith("Station_"):
                        station_num = station_id.split("_")[1]
                        return f"OPT_Station_{station_num}"
                    return station_id
            
            # Fallback: deterministic assignment based on session ID
            hash_val = hash(session_id) % 20 + 1
            return f"OPT_Station_{hash_val}"
            
        except Exception as e:
            print(f"❌ Error getting station assignment for {session_id[:8]}: {e}")
            # Even if there's an error, return a valid station
            hash_val = hash(session_id) % 20 + 1
            return f"OPT_Station_{hash_val}"
            
    def get_current_price(self, current_time):
        """Get current electricity price"""
        try:
            if hasattr(self.session_manager, 'price_data') and self.session_manager.price_data:
                hour = current_time.hour
                return self.session_manager.price_data.get(hour, 50.0)
            return 50.0
        except:
            return 50.0
            
    def start_data_streaming(self):
        """Start the data streaming loop"""
        def stream_data():
            while self.running:
                try:
                    # Always collect and send data, even if no clients yet
                    # This ensures continuous data generation for debugging
                    data = self.collect_realtime_data()
                    
                    if self.clients and data:  # Only send if there are connected clients and data is valid
                        # Send to all connected clients
                        disconnected_clients = []
                        for client in self.clients:
                            try:
                                self.send_to_client(client, data)
                            except Exception as e:
                                print(f"❌ Error sending to client: {e}")
                                disconnected_clients.append(client)
                        
                        # Remove disconnected clients
                        for client in disconnected_clients:
                            if client in self.clients:
                                self.clients.remove(client)
                    elif data:
                        # Print periodic status even when no clients are connected
                        current_time = data['data']['simulation_time']
                        active_evs = data['data']['statistics']['optimization']['active_evs']
                        print(f"🕐 Simulation running: {current_time} - Active EVs: {active_evs} - Waiting for JavaFX connection...")
                    else:
                        print("⚠️ No simulation data available - backend may not be running properly")
                    
                    time.sleep(1)  # Send data every second
                    
                except Exception as e:
                    print(f"❌ Data streaming error: {e}")
                    import traceback
                    traceback.print_exc()
                    time.sleep(5)  # Wait before retrying
                    
        # Start streaming in a separate thread
        streaming_thread = threading.Thread(target=stream_data, daemon=True)
        streaming_thread.start()
        print("📡 Data streaming thread started - sending every 1 second")
        
    def start(self):
        """Start the realtime data sender"""
        self.running = True
        
        # Start data streaming
        self.start_data_streaming()
        
        # Start TCP server (this will block in a separate thread)
        server_thread = threading.Thread(target=self.start_tcp_server, daemon=True)
        server_thread.start()
        
        print(f"🚀 Simple TCP data sender started on port {self.port}")
        print(f"📡 JavaFX can connect to: localhost:{self.port}")
        
        return server_thread
        
    def stop(self):
        """Stop the realtime data sender"""
        self.running = False
        if self.server_socket:
            self.server_socket.close()
        for client in self.clients:
            client.close()
        self.clients.clear()
        print("🛑 Simple TCP data sender stopped")
        
    def calculate_total_cost(self, active_sessions, completed_sessions, is_fcfs=False):
        """Calculate the actual total cost based on energy consumption and current prices"""
        try:
            total_cost = 0.0
            
            # Include both active and completed sessions
            all_sessions = active_sessions + completed_sessions
            
            for session in all_sessions:
                # Get energy delivered for this session
                # Cả hai thuật toán đều dùng cùng một tên trường 'energy_delivered'
                energy_delivered = session.get('energy_delivered', 0.0)
                
                # In ra thông tin debug để kiểm tra
                if energy_delivered > 0:
                    is_fcfs_str = "FCFS" if is_fcfs else "OPT"
                    print(f"DEBUG: {is_fcfs_str} Session {session.get('sessionID', 'unknown')[:8]}: energy_delivered = {energy_delivered:.2f}kWh")
                
                # Get price at connection time (simplified: using current price for now)
                # In a real implementation, we would use historical prices for each charging period
                current_time = self.simulation_clock.get_current_time()
                price_per_mwh = self.get_current_price(current_time)
                
                # Calculate cost: price per MWh * energy in MWh
                # Convert kWh to MWh: 1 MWh = 1000 kWh
                cost = price_per_mwh * (energy_delivered / 1000.0)
                total_cost += cost
                
            return total_cost
            
        except Exception as e:
            print(f"❌ Error calculating total cost: {e}")
            return 0.0
        
    def calculate_actual_cost(self, sessions_list, is_fcfs=False):
        """Calculate the actual total cost based on energy delivered from a list of sessions"""
        try:
            total_cost = 0.0
            
            for session in sessions_list:
                # Get energy delivered for this session
                energy_delivered = session.get('energy_delivered', 0.0)
                
                # In ra thông tin debug để kiểm tra
                if energy_delivered > 0:
                    is_fcfs_str = "FCFS" if is_fcfs else "OPT"
                    print(f"DEBUG: {is_fcfs_str} Session {session.get('sessionID', 'unknown')[:8]}: energy_delivered = {energy_delivered:.2f}kWh")
                
                # Get price at connection time (simplified: using current price for now)
                current_time = self.simulation_clock.get_current_time()
                price_per_mwh = self.get_current_price(current_time)
                
                # Calculate cost: price per MWh * energy in MWh
                # Convert kWh to MWh: 1 MWh = 1000 kWh
                cost = price_per_mwh * (energy_delivered / 1000.0)
                total_cost += cost
                
            return total_cost
            
        except Exception as e:
            print(f"❌ Error calculating actual cost: {e}")
            return 0.0
