"""
Integrated Charging Monitor UI with Tabbed Interface
Connects with the real EV charging simulation to display live data
Features: EV Monitor tab and Charging Schedule tab
"""

import tkinter as tk
from tkinter import ttk, scrolledtext
import threading
import queue
import time
from datetime import datetime, timedelta
from datetime import datetime, timedelta

class IntegratedChargingUI:
    def __init__(self, session_manager, simulation_clock, fcfs_manager=None):
        self.session_manager = session_manager
        self.simulation_clock = simulation_clock
        self.fcfs_manager = fcfs_manager
        
        self.root = tk.Tk()
        self.root.title("EV Charging Monitor - Live Simulation")
        self.root.geometry("1600x1000")
        self.root.configure(bg='#2c3e50')
        
        # Update interval (ms)
        self.update_interval = 500
        
        # Create UI
        self.create_widgets()
        
        # Start update loop
        self.update_display()
        
    def create_widgets(self):
        """Create the UI components"""
        
        # Header
        header_frame = tk.Frame(self.root, bg='#34495e', height=80)
        header_frame.pack(fill=tk.X, padx=5, pady=5)
        header_frame.pack_propagate(False)
        
        title = tk.Label(
            header_frame,
            text="🔋 EV Charging Station Monitor",
            font=("Arial", 24, "bold"),
            bg='#34495e',
            fg='#ecf0f1'
        )
        title.pack(pady=15)
        
        # Status bar with speed control
        status_frame = tk.Frame(self.root, bg='#2c3e50')
        status_frame.pack(fill=tk.X, padx=5, pady=(0, 10))
        
        # Left side - Time display
        self.time_label = tk.Label(
            status_frame,
            text="Simulation Time: --:--:--",
            font=("Arial", 16, "bold"),
            bg='#2c3e50',
            fg='#3498db'
        )
        self.time_label.pack(side=tk.LEFT, padx=10)
        
        # Right side - Speed control
        speed_control_frame = tk.Frame(status_frame, bg='#2c3e50')
        speed_control_frame.pack(side=tk.RIGHT, padx=10)
        
        # Speed label
        tk.Label(
            speed_control_frame,
            text="Speed:",
            font=("Arial", 12),
            bg='#2c3e50',
            fg='#95a5a6'
        ).pack(side=tk.LEFT, padx=(0, 5))
        
        # Speed slider
        self.speed_var = tk.DoubleVar(value=10.0)
        self.speed_scale = tk.Scale(
            speed_control_frame,
            from_=1,
            to=1000,
            orient=tk.HORIZONTAL,
            variable=self.speed_var,
            command=self.on_speed_change,
            length=150,
            bg='#34495e',
            fg='#ecf0f1',
            highlightbackground='#2c3e50',
            troughcolor='#2c3e50'
        )
        self.speed_scale.pack(side=tk.LEFT, padx=5)
        
        # Speed display
        self.speed_label = tk.Label(
            speed_control_frame,
            text="10x",
            font=("Arial", 14, "bold"),
            bg='#2c3e50',
            fg='#e74c3c',
            width=5
        )
        self.speed_label.pack(side=tk.LEFT, padx=(5, 0))
        
        # Create notebook for tabs
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Configure notebook style
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("TNotebook", background="#2c3e50", borderwidth=0)
        style.configure("TNotebook.Tab", 
                       background="#34495e", 
                       foreground="#ecf0f1",
                       padding=[12, 8],
                       font=("Arial", 11, "bold"))
        style.map("TNotebook.Tab",
                 background=[("selected", "#3498db")],
                 foreground=[("selected", "#ffffff")])
          # Tab 1: EV Monitor (Optimization)
        self.monitor_frame = tk.Frame(self.notebook, bg='#2c3e50')
        self.notebook.add(self.monitor_frame, text="🎯 Optimization Monitor")
        self.create_monitor_tab_content()
        
        # Tab 2: FCFS Monitor (if available)
        if self.fcfs_manager:
            self.fcfs_frame = tk.Frame(self.notebook, bg='#2c3e50')
            self.notebook.add(self.fcfs_frame, text="🚗 FCFS Monitor")
            self.create_fcfs_tab_content()
        
        # Tab 3: Charging Schedule
        self.schedule_frame = tk.Frame(self.notebook, bg='#2c3e50')
        self.notebook.add(self.schedule_frame, text="📅 Charging Schedule")
        self.create_schedule_tab_content()
        
    def create_ev_table(self, parent):
        """Create the main EV status table"""
        table_frame = tk.LabelFrame(
            parent,
            text="🚗 Active Electric Vehicles",
            font=("Arial", 14, "bold"),
            bg='#34495e',
            fg='#ecf0f1',
            relief=tk.RAISED,
            bd=2
        )
        table_frame.pack(fill=tk.BOTH, expand=True)
          # Create treeview
        columns = ("ID", "Arrival", "Departure", "Needed", "Delivered", "Remaining", "Progress", "Power", "Station", "Status")
        self.ev_tree = ttk.Treeview(table_frame, columns=columns, show="headings", height=15)
        
        # Configure columns
        column_configs = [
            ("ID", 120, "EV Session ID"),
            ("Arrival", 80, "Arrival Time"),
            ("Departure", 80, "Departure Time"),
            ("Needed", 80, "Energy Needed (kWh)"),
            ("Delivered", 80, "Energy Delivered (kWh)"),
            ("Remaining", 80, "Remaining (kWh)"),
            ("Progress", 100, "Charging Progress"),
            ("Power", 80, "Current Power (kW)"),
            ("Station", 90, "Station Assignment"),
            ("Status", 120, "Current Status")
        ]
        
        for col, width, heading in column_configs:
            self.ev_tree.heading(col, text=heading, anchor=tk.W)
            self.ev_tree.column(col, width=width, anchor=tk.CENTER)
        
        # Style the treeview
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Treeview", 
                       background="#2c3e50",
                       foreground="#ecf0f1",
                       fieldbackground="#34495e")
        style.configure("Treeview.Heading",
                       background="#34495e",
                       foreground="#ecf0f1",
                       font=("Arial", 10, "bold"))
        
        # Scrollbar
        scrollbar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=self.ev_tree.yview)
        self.ev_tree.configure(yscroll=scrollbar.set)
        
        # Pack
        self.ev_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5, pady=5)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y, pady=5)
        
    def create_statistics_panel(self, parent):
        """Create the statistics panel"""
        stats_frame = tk.LabelFrame(
            parent,
            text="📊 Real-time Statistics",
            font=("Arial", 12, "bold"),
            bg='#34495e',
            fg='#ecf0f1',
            relief=tk.RAISED,
            bd=2,
            height=200
        )
        stats_frame.pack(fill=tk.X, pady=(0, 10))
        stats_frame.pack_propagate(False)
        
        # Statistics labels
        self.stats_labels = {}
        stats_items = [
            ("active", "Active EVs:", "0"),
            ("completed", "Completed:", "0"),
            ("total_energy", "Total Energy:", "0.0 kWh"),
            ("avg_power", "Avg Power:", "0.0 kW"),
            ("charging", "Currently Charging:", "0")
        ]
        
        for i, (key, label, initial) in enumerate(stats_items):
            row_frame = tk.Frame(stats_frame, bg='#34495e')
            row_frame.pack(fill=tk.X, padx=10, pady=2)
            
            tk.Label(
                row_frame,
                text=label,
                font=("Arial", 11),
                bg='#34495e',
                fg='#bdc3c7',
                width=15,
                anchor='w'
            ).pack(side=tk.LEFT)
            
            value_label = tk.Label(
                row_frame,
                text=initial,
                font=("Arial", 11, "bold"),
                bg='#34495e',
                fg='#3498db',
                anchor='e'
            )
            value_label.pack(side=tk.RIGHT)
            
            self.stats_labels[key] = value_label
            
    def create_log_panel(self, parent):
        """Create the log panel"""
        log_frame = tk.LabelFrame(
            parent,
            text="📝 Activity Log",
            font=("Arial", 12, "bold"),
            bg='#34495e',
            fg='#ecf0f1',
            relief=tk.RAISED,
            bd=2
        )
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        self.log_text = scrolledtext.ScrolledText(
            log_frame,
            height=15,
            font=("Consolas", 9),
            bg='#2c3e50',
            fg='#ecf0f1',
            insertbackground='#ecf0f1',
            selectbackground='#3498db'
        )
        self.log_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
    def update_display(self):
        """Update the display with current simulation data"""
        try:
            # Update time
            current_time = self.simulation_clock.get_current_time()
            speed = self.simulation_clock.speed_multiplier
            
            self.time_label.config(text=f"Simulation Time: {current_time.strftime('%H:%M:%S')}")
            
            # Update speed display and sync slider if needed
            if abs(self.speed_var.get() - speed) > 0.1:  # Only update if different
                self.speed_var.set(speed)
            self.speed_label.config(text=f"{speed:.0f}x")
              # Update EV table
            self.update_ev_table()
              # Update statistics
            self.update_statistics()
            
            # Update FCFS data if available
            if self.fcfs_manager:
                self.update_fcfs_display()
            
            # Update schedule view (without debug prints)
            self.update_schedule_view()
            
            # Update station overview
            self.update_station_overview()
            
        except Exception as e:
            self.log_message(f"❌ Update error: {str(e)}")
        
        # Schedule next update
        self.root.after(self.update_interval, self.update_display)
        
    def get_station_assignment(self, session_id):
        """Get current station assignment for a session from optimization schedule"""
        try:
            # Get current schedule data
            current_time = self.simulation_clock.get_current_time()
            schedule = self.session_manager.get_full_charging_schedule(current_time, 1) # Only check current hour
            
            if not schedule:
                return "N/A"
            
            # Check current time slot for this session
            for slot in schedule:
                if slot.get('stations'):
                    for station in slot['stations']:
                        # Match session ID (truncated comparison)
                        if session_id[:20] == station.get('session_id', '')[:20]:
                            return station.get('station_id', 'N/A')
            
            return "Waiting"
        except Exception as e:
            print(f"❌ Error getting station assignment for {session_id}: {e}")
            return "N/A"
        
    def get_station_assignment_with_status(self, session, power, progress):
        """Get station assignment with status display format like [1] Charging, [2] Waiting, [3] Completed"""
        try:
            # First try to get persistent station assignment from StationManager
            station_manager = self.session_manager.station_manager
            station_id = station_manager.get_station_assignment(session['sessionID'])
            
            if not station_id:
                # Fallback to optimization schedule if no persistent assignment
                station_id = self.get_station_assignment(session['sessionID'])
                if station_id == "Waiting" or station_id == "N/A":
                    return "⏳ Waiting for Station"
            
            if station_id and station_id not in ["Waiting", "N/A"]:
                # Extract station number from station_id (e.g., "Station_1" -> "1")
                try:
                    if "Station_" in station_id:
                        station_num = station_id.split("_")[1]
                    else:
                        station_num = str(station_id)
                except:
                    station_num = "?"
                
                # Determine status based on progress and power
                if progress >= 99.9:
                    status_text = "Completed"
                    status_icon = "✅"
                elif power > 0.1:
                    status_text = "Charging"
                    status_icon = "⚡"
                else:
                    status_text = "Waiting"
                    status_icon = "⏸️"
                
                return f"{status_icon} [{station_num}] {status_text}"
            else:
                return "⏳ Waiting for Station"
                
        except Exception as e:
            print(f"❌ Error getting station assignment with status for {session['sessionID']}: {e}")
            return "❓ Unknown"

    def update_ev_table(self):
        """Update the EV table with current session data"""
        # Clear existing items
        for item in self.ev_tree.get_children():
            self.ev_tree.delete(item)
          # Get current active sessions
        active_sessions = self.session_manager.active_sessions
        
        # Also get completed sessions that are still connected (waiting to leave)
        current_time = self.simulation_clock.get_current_time()
        completed_but_connected = []
        for session in self.session_manager.completed_sessions:
            # Check if completed but still within disconnect time
            if session['disconnectTime_dt'] > current_time:
                completed_but_connected.append(session)
        
        # Combine active and completed-but-connected sessions
        all_sessions_to_display = active_sessions + completed_but_connected
        for session in all_sessions_to_display:
            # Extract data
            session_id = session['sessionID'][:15] + "..." if len(session['sessionID']) > 15 else session['sessionID']
            arrival = session['connectionTime_dt'].strftime('%H:%M')
            departure = session['disconnectTime_dt'].strftime('%H:%M')
            needed = session['kWhDelivered']
            delivered = session.get('energy_delivered', 0.0)
            remaining = session.get('remaining_energy', needed)
            power = session.get('current_charging_power', 0.0)
            
            # Calculate progress
            if needed > 0:
                progress = min((delivered / needed) * 100, 100)
            else:
                progress = 100
                
            # Determine status
            if progress >= 99.9:
                # Check if still connected or already left
                if session in self.session_manager.completed_sessions:
                    if session['disconnectTime_dt'] > current_time:
                        status = "🔋 Ready to Leave"
                        progress_display = "🟢 100%"
                    else:
                        status = "✅ Left Station"
                        progress_display = "🟢 100%"
                else:
                    status = "✅ Complete"
                    progress_display = "🟢 100%"
            elif power > 0.1:
                status = "⚡ Charging"
                if progress >= 75:
                    progress_display = f"🟢 {progress:.1f}%"
                elif progress >= 50:
                    progress_display = f"🟡 {progress:.1f}%"                
                elif progress >= 25:
                    progress_display = f"🟠 {progress:.1f}%"
                else:
                    progress_display = f"🔴 {progress:.1f}%"
            else:
                status = "⏸️ Waiting"
                progress_display = f"⚪ {progress:.1f}%"
              # Get station assignment with status
            station_assignment = self.get_station_assignment_with_status(session, power, progress)
            
            # Insert row
            values = (
                session_id,
                arrival,
                departure,
                f"{needed:.1f}",
                f"{delivered:.1f}",
                f"{remaining:.1f}",
                progress_display,
                f"{power:.1f}",
                station_assignment,
                status
            )
            
            self.ev_tree.insert("", "end", values=values)
            
    def update_statistics(self):
        """Update the statistics panel"""
        active_sessions = self.session_manager.active_sessions
        completed_sessions = self.session_manager.completed_sessions
        
        # Calculate statistics
        active_count = len(active_sessions)
        completed_count = len(completed_sessions)
        
        total_energy = sum(session.get('energy_delivered', 0) for session in active_sessions + completed_sessions)
        
        charging_sessions = [s for s in active_sessions if s.get('current_charging_power', 0) > 0.1]
        charging_count = len(charging_sessions)
        
        avg_power = sum(s.get('current_charging_power', 0) for s in charging_sessions) / max(1, charging_count)
        
        # Update labels
        self.stats_labels['active'].config(text=str(active_count))
        self.stats_labels['completed'].config(text=str(completed_count))
        self.stats_labels['total_energy'].config(text=f"{total_energy:.1f} kWh")
        self.stats_labels['avg_power'].config(text=f"{avg_power:.1f} kW")
        self.stats_labels['charging'].config(text=str(charging_count))
        
    def log_message(self, message):
        """Add a message to the log"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        formatted_message = f"[{timestamp}] {message}\n"
        
        self.log_text.insert(tk.END, formatted_message)
        self.log_text.see(tk.END)
          # Limit log size
        lines = self.log_text.get("1.0", tk.END).split('\n')
        if len(lines) > 200:
            self.log_text.delete("1.0", "50.0")
    def on_speed_change(self, value):
        """Handle speed slider change"""
        try:
            new_speed = float(value)
            self.simulation_clock.set_speed(new_speed)
            self.speed_label.config(text=f"{new_speed:.0f}x")
            self.log_message(f"⚡ Speed changed to {new_speed:.0f}x")
        except Exception as e:
            self.log_message(f"❌ Error changing speed: {e}")
            
    def run(self):
        """Start the UI"""
        self.log_message("🔋 EV Charging Monitor started")
        self.log_message("Monitoring live simulation data...")
        
        try:
            self.root.mainloop()
        except KeyboardInterrupt:
            self.log_message("🛑 Monitor stopped by user")

    def create_monitor_tab_content(self):
        """Create content for the EV Monitor tab"""
        # Main content frame for monitor tab
        content_frame = tk.Frame(self.monitor_frame, bg='#2c3e50')
        content_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Left side - EV Table
        left_frame = tk.Frame(content_frame, bg='#2c3e50')
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 5))
        
        self.create_ev_table(left_frame)
        
        # Right side - Statistics and Log
        right_frame = tk.Frame(content_frame, bg='#2c3e50', width=400)
        right_frame.pack(side=tk.RIGHT, fill=tk.Y, padx=(5, 0))
        right_frame.pack_propagate(False)
        
        self.create_statistics_panel(right_frame)
        self.create_log_panel(right_frame)
        
    def create_schedule_tab_content(self):
        """Create content for the Charging Schedule tab"""
        # Main content frame for schedule tab
        content_frame = tk.Frame(self.schedule_frame, bg='#2c3e50')
        content_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Header for schedule
        header_frame = tk.Frame(content_frame, bg='#34495e', height=60)
        header_frame.pack(fill=tk.X, pady=(0, 10))
        header_frame.pack_propagate(False)
        
        schedule_title = tk.Label(
            header_frame,
            text="📅 Charging Schedule & Calendar View",
            font=("Arial", 18, "bold"),
            bg='#34495e',
            fg='#ecf0f1'
        )
        schedule_title.pack(pady=15)
        
        # Schedule controls frame
        controls_frame = tk.Frame(content_frame, bg='#2c3e50', height=80)
        controls_frame.pack(fill=tk.X, pady=(0, 10))
        controls_frame.pack_propagate(False)
        
        # Time range selector
        time_frame = tk.Frame(controls_frame, bg='#2c3e50')
        time_frame.pack(side=tk.LEFT, padx=10, pady=10)
        
        tk.Label(
            time_frame,
            text="Time Range:",
            font=("Arial", 12, "bold"),
            bg='#2c3e50',
            fg='#ecf0f1'
        ).pack(side=tk.LEFT, padx=(0, 10))
        
        # Time range options
        self.time_range_var = tk.StringVar(value="24h")
        time_options = ["1h", "6h", "12h", "24h", "7d"]
        
        for option in time_options:
            rb = tk.Radiobutton(
                time_frame,
                text=option,
                variable=self.time_range_var,
                value=option,
                font=("Arial", 10),
                bg='#2c3e50',
                fg='#ecf0f1',
                selectcolor='#3498db',
                activebackground='#34495e',
                command=self.update_schedule_view
            )
            rb.pack(side=tk.LEFT, padx=5)
        
        # Schedule display frame
        schedule_display_frame = tk.LabelFrame(
            content_frame,
            text="🗓️ Charging Station Schedule",
            font=("Arial", 14, "bold"),
            bg='#34495e',
            fg='#ecf0f1',
            relief=tk.RAISED,
            bd=2
        )
        schedule_display_frame.pack(fill=tk.BOTH, expand=True)
          # Create schedule treeview
        schedule_columns = ("Time", "Station_1", "Station_2", "Station_3", "Station_4", "Station_5", "Total_Power", "Price")
        self.schedule_tree = ttk.Treeview(schedule_display_frame, columns=schedule_columns, show="headings", height=20)
        
        # Configure schedule columns
        column_configs = [
            ("Time", 100, "Time Slot"),
            ("Station_1", 120, "Station 1"),
            ("Station_2", 120, "Station 2"),
            ("Station_3", 120, "Station 3"),
            ("Station_4", 120, "Station 4"),
            ("Station_5", 120, "Station 5"),
            ("Total_Power", 100, "Total Power (kW)"),
            ("Price", 80, "Price (€/MWh)")
        ]
        
        for col, width, heading in column_configs:
            self.schedule_tree.heading(col, text=heading, anchor=tk.W)
            self.schedule_tree.column(col, width=width, anchor=tk.CENTER)
        
        # Schedule scrollbar
        schedule_scrollbar = ttk.Scrollbar(schedule_display_frame, orient=tk.VERTICAL, command=self.schedule_tree.yview)
        self.schedule_tree.configure(yscroll=schedule_scrollbar.set)
        
        # Pack schedule components
        self.schedule_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5, pady=5)
        schedule_scrollbar.pack(side=tk.RIGHT, fill=tk.Y, pady=5)
          # Initialize schedule view
        self.update_schedule_view()
        
    def update_schedule_view(self):
        """Update the charging schedule view with electricity pricing"""
        try:
            # Get full schedule from session manager
            full_schedule = self.session_manager.get_full_charging_schedule()
            
            if not full_schedule:
                # Clear and show empty message
                for item in self.schedule_tree.get_children():
                    self.schedule_tree.delete(item)
                self.schedule_tree.insert('', 'end', values=(
                    "No schedule available", "", "", "", "", "", "", ""
                ))
                return
            
            print(f"✅ Retrieved {len(full_schedule)} time slots from optimization")
            
            # Clear existing items
            for item in self.schedule_tree.get_children():
                self.schedule_tree.delete(item)
            
            # Display each time slot with pricing information
            for slot_idx, slot in enumerate(full_schedule):
                time_label = slot['time_label']
                time_start = slot['time_start']
                total_power = slot['total_power']
                
                # Get electricity price for this time slot
                hourly_price = self.session_manager.get_hourly_price(time_start)
                price_reason = self.session_manager.get_price_reason(time_start)                # Prepare station data for display with status
                station_data = ["", "", "", "", ""]  # 5 stations max
                total_stations = len(slot['stations'])
                
                for i, station in enumerate(slot['stations'][:5]):  # Show max 5 stations
                    # Extract station number and create status display
                    station_id = station.get('station_id', f'Station_{i+1}')
                    try:
                        if "Station_" in station_id:
                            station_num = station_id.split("_")[1]
                        else:
                            station_num = str(station_id)
                    except:
                        station_num = str(i+1)
                    
                    # Get session details for status
                    charging_power = station.get('charging_power', 0.0)
                    progress = station.get('progress', 0.0)
                    
                    # Determine status
                    if progress >= 99.9:
                        status = "✅ Completed"
                    elif charging_power > 0.1:
                        status = "⚡ Charging"
                    else:
                        status = "⏸️ Waiting"
                    
                    # Format: [1] Status (SessionID..PowerkW)
                    station_info = f"[{station_num}] {status} ({station['session_id'][:8]}..{charging_power:.1f}kW)"
                    
                    if i < len(station_data):
                        station_data[i] = station_info
                
                # Add overflow indicator if more than 5 stations
                if total_stations > 5:
                    if station_data[4]:  # If 5th slot is used
                        station_data[4] = f"...+{total_stations-4} more"
                    else:
                        # Find first empty slot for overflow indicator
                        for i in range(5):
                            if not station_data[i]:
                                station_data[i] = f"...+{total_stations-i} more"
                                break
                
                # Insert main row with price information
                values = (
                    time_label,
                    station_data[0],
                    station_data[1], 
                    station_data[2],
                    station_data[3],
                    station_data[4],
                    f"{total_power:.1f} kW",
                    f"{hourly_price:.2f}"
                )
                
                # Add row with color coding based on price
                item_id = self.schedule_tree.insert('', 'end', values=values)
                
                # Add price reason as a child row for context
                if len(slot['stations']) > 0:
                    reason_values = (
                        f"  └─ {price_reason}",
                        "", "", "", "", "", "", ""
                    )
                    self.schedule_tree.insert(item_id, 'end', values=reason_values)
            
            print(f"📅 Schedule display updated with {len(full_schedule)} slots and pricing")
            
        except Exception as e:
            print(f"❌ Error updating schedule view: {e}")
            import traceback
            traceback.print_exc()
            
            # Show error in the table
            for item in self.schedule_tree.get_children():
                self.schedule_tree.delete(item)
            self.schedule_tree.insert('', 'end', values=(
                f"Error: {str(e)}", "", "", "", "", "", "", ""
            ))
    
    def get_charging_schedule_for_time(self, slot_start, slot_end):
        """Get charging schedule for specific time with flexible matching"""
        try:
           
            full_schedule = self.session_manager.get_full_charging_schedule(slot_start)
            if not full_schedule:
                return []
            
            schedule_items = []
            for slot in full_schedule:
               
                if (slot['time_start'] < slot_end and slot['time_end'] > slot_start):
                    for station in slot['stations']:
                        schedule_items.append({
                            'session_id': station['session_id'],
                            'power': f"{station['charging_power']:.1f} kW",
                            'slot_time': f"{slot['time_start'].strftime('%H:%M')}-{slot['time_end'].strftime('%H:%M')}",
                            'remaining': f"{station.get('remaining_energy', 0):.1f} kWh",
                            'departure': station.get('departure_time', 'N/A'),
                            'progress': f"{station.get('progress', 0):.0f}%"
                        })
            
            return schedule_items
        except Exception as e:
            print(f"Error getting charging schedule: {e}")
            return []

    def update_station_overview(self):
        """Update station overview display"""
        try:
            # Get station status from StationManager
            station_manager = self.session_manager.station_manager
            station_status = station_manager.get_station_status()
            
            # Create station overview text
            overview_text = f"\n🔌 STATION OVERVIEW ({station_status['total_stations']} stations)\n"
            overview_text += f"  📊 Available: {station_status['available_count']} | Occupied: {station_status['occupied_count']}\n\n"
            
            # Show detailed station status
            for station_id, details in station_status['station_details'].items():
                station_num = station_id.split("_")[1] if "Station_" in station_id else station_id
                
                if details['occupied']:
                    session_id = details['session_id'][:15] + "..." if len(details['session_id']) > 15 else details['session_id']
                    
                    # Get session details to determine status
                    session = self.session_manager.get_session_by_id(details['session_id'])
                    if session:
                        power = session.get('current_charging_power', 0.0)
                        progress = (session.get('energy_delivered', 0.0) / session.get('kWhDelivered', 1.0)) * 100
                        
                        if progress >= 99.9:
                            status = "✅ Completed"
                        elif power > 0.1:
                            status = "⚡ Charging"
                        else:
                            status = "⏸️ Waiting"
                        
                        overview_text += f"  [{station_num}] {status} - {session_id} ({power:.1f}kW)\n"
                    else:
                        overview_text += f"  [{station_num}] 🔌 Occupied - {session_id}\n"
                # else:
                #     overview_text += f"  [{station_num}] 🟢 Available\n"
            
            # Update log with station overview periodically
            current_time = self.simulation_clock.get_current_time()
            if not hasattr(self, 'last_station_log') or (current_time - self.last_station_log).total_seconds() > 30:
                self.log_message(overview_text)
                self.last_station_log = current_time
                
        except Exception as e:
            print(f"❌ Error updating station overview: {e}")

    def create_fcfs_tab_content(self):
        """Create FCFS monitoring tab content"""
        # FCFS Info Panel
        info_frame = tk.Frame(self.fcfs_frame, bg='#2c3e50')
        info_frame.pack(fill=tk.X, padx=10, pady=10)
        
        tk.Label(
            info_frame,
            text="🚗 First-Come-First-Serve (FCFS) Charging System",
            font=("Arial", 16, "bold"),
            bg='#2c3e50',
            fg='#e74c3c'
        ).pack(anchor=tk.W)
        
        tk.Label(
            info_frame,
            text="📋 Algorithm: Vehicles are served in arrival order | Max Stations: 20 | Max Power: 300 kWh",
            font=("Arial", 10),
            bg='#2c3e50',
            fg='#95a5a6'
        ).pack(anchor=tk.W, pady=(5, 0))
        
        # Connection Status for FCFS
        self.fcfs_connection_frame = tk.Frame(info_frame, bg='#2c3e50')
        self.fcfs_connection_frame.pack(fill=tk.X, pady=(10, 0))
        
        self.fcfs_connection_label = tk.Label(
            self.fcfs_connection_frame,
            text="📡 FCFS Data Connection: Checking...",
            font=("Arial", 10, "bold"),
            bg='#2c3e50',
            fg='#f39c12'
        )
        self.fcfs_connection_label.pack(side=tk.LEFT)
        
        # FCFS Statistics Panel
        self.create_fcfs_statistics_panel(self.fcfs_frame)
        
        # FCFS EV Table
        self.create_fcfs_ev_table(self.fcfs_frame)
        
        # FCFS Station Status
        self.create_fcfs_station_panel(self.fcfs_frame)
        
    def create_fcfs_statistics_panel(self, parent):
        """Create FCFS statistics panel"""
        stats_frame = tk.LabelFrame(
            parent,
            text="📊 FCFS Real-time Statistics",
            font=("Arial", 12, "bold"),
            bg='#34495e',
            fg='#ecf0f1',
            relief=tk.RAISED,
            bd=2,
            height=150
        )
        stats_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        stats_frame.pack_propagate(False)
        
        # Create grid for statistics
        stats_grid = tk.Frame(stats_frame, bg='#34495e')
        stats_grid.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # FCFS Statistics
        self.fcfs_stats_labels = {}
        fcfs_stats_info = [
            ("Active EVs", "active_evs", 0, 0),
            ("In Queue", "waiting_in_queue", 0, 1),
            ("Currently Charging", "currently_charging", 0, 2),
            ("Completed Sessions", "completed_sessions", 1, 0),
            ("Total Energy (kWh)", "total_energy_delivered", 1, 1),
            ("Power Usage (%)", "power_utilization", 1, 2),
        ]
        
        for label_text, key, row, col in fcfs_stats_info:
            # Label
            tk.Label(
                stats_grid,
                text=f"{label_text}:",
                font=("Arial", 10),
                bg='#34495e',
                fg='#95a5a6',
                anchor=tk.W
            ).grid(row=row*2, column=col, sticky="ew", padx=5, pady=2)
            
            # Value
            value_label = tk.Label(
                stats_grid,
                text="--",
                font=("Arial", 12, "bold"),
                bg='#34495e',
                fg='#e74c3c',
                anchor=tk.W
            )
            value_label.grid(row=row*2+1, column=col, sticky="ew", padx=5, pady=2)
            self.fcfs_stats_labels[key] = value_label
        
        # Configure grid weights
        for i in range(3):
            stats_grid.grid_columnconfigure(i, weight=1)
    
    def create_fcfs_ev_table(self, parent):
        """Create FCFS EV status table"""
        table_frame = tk.LabelFrame(
            parent,
            text="🚗 FCFS Active Electric Vehicles",
            font=("Arial", 14, "bold"),
            bg='#34495e',
            fg='#ecf0f1',
            relief=tk.RAISED,
            bd=2
        )
        table_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 10))
        
        # Create treeview for FCFS
        columns = ("ID", "Arrival", "Departure", "Needed", "Delivered", "Progress", "Power", "Station", "Status")
        self.fcfs_ev_tree = ttk.Treeview(table_frame, columns=columns, show="headings", height=10)
        
        # Configure columns
        column_configs = [
            ("ID", 100, "EV Session ID"),
            ("Arrival", 70, "Arrival Time"),
            ("Departure", 70, "Departure Time"),
            ("Needed", 70, "Energy Needed (kWh)"),
            ("Delivered", 70, "Energy Delivered (kWh)"),
            ("Progress", 80, "Charging Progress"),
            ("Power", 70, "Current Power (kW)"),
            ("Station", 100, "Station/Queue Position"),
            ("Status", 90, "Current Status")
        ]
        
        for col, width, heading in column_configs:
            self.fcfs_ev_tree.heading(col, text=heading, anchor=tk.W)
            self.fcfs_ev_tree.column(col, width=width, anchor=tk.CENTER)
        
        # Scrollbar for FCFS table
        fcfs_scrollbar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=self.fcfs_ev_tree.yview)
        self.fcfs_ev_tree.configure(yscroll=fcfs_scrollbar.set)
        
        # Pack
        self.fcfs_ev_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5, pady=5)
        fcfs_scrollbar.pack(side=tk.RIGHT, fill=tk.Y, pady=5)
    
    def create_fcfs_station_panel(self, parent):
        """Create FCFS station status panel"""
        station_frame = tk.LabelFrame(
            parent,
            text="🔌 FCFS Charging Stations Status (20 Stations)",
            font=("Arial", 12, "bold"),
            bg='#34495e',
            fg='#ecf0f1',
            relief=tk.RAISED,
            bd=2,
            height=120
        )
        station_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        station_frame.pack_propagate(False)
        
        # Create grid for stations
        self.fcfs_station_grid = tk.Frame(station_frame, bg='#34495e')
        self.fcfs_station_grid.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Create station status labels
        self.fcfs_station_labels = {}
        for i in range(20):
            station_id = f"FCFS_Station_{i+1}"
            row = i // 10
            col = i % 10
            
            station_label = tk.Label(
                self.fcfs_station_grid,
                text=f"S{i+1}\n⚫",
                font=("Arial", 8, "bold"),
                bg='#34495e',
                fg='#95a5a6',
                width=6,
                height=2,
                relief=tk.RAISED,
                bd=1
            )            
            station_label.grid(row=row, column=col, padx=1, pady=1)
            self.fcfs_station_labels[station_id] = station_label
        
        # Configure grid weights
        for i in range(10):
            self.fcfs_station_grid.grid_columnconfigure(i, weight=1)
            
    def update_fcfs_display(self):
        """Update FCFS tab with current data"""
        try:
            if not self.fcfs_manager:
                return
                
            # Update connection status
            session_count = len(self.fcfs_manager.all_sessions)
            if session_count > 0:
                self.fcfs_connection_label.config(
                    text=f"📡 FCFS Data Connection: Active ({session_count} sessions)",
                    fg='#27ae60'
                )
            else:
                self.fcfs_connection_label.config(
                    text="📡 FCFS Data Connection: Ready (0 sessions)",
                    fg='#f39c12'
                )
            
            # Update FCFS statistics
            self.update_fcfs_statistics()
            
            # Update FCFS EV table
            self.update_fcfs_ev_table()
            
            # Update FCFS station status
            self.update_fcfs_station_status()
                
        except Exception as e:
            self.log_message(f"❌ FCFS display update error: {str(e)}")
            self.fcfs_connection_label.config(
                    text=f"📡 FCFS Data Connection: Active ({session_count} sessions)",
                    fg='#27ae60'
                )
        else:
                self.fcfs_connection_label.config(
                    text="📡 FCFS Data Connection: Ready (0 sessions)",
                    fg='#f39c12'
                )
            
            # Update FCFS statistics
        self.update_fcfs_statistics()
        
        # Update FCFS EV table
        self.update_fcfs_ev_table()
        
        # Update FCFS station status
        self.update_fcfs_station_status()
            
    def update_fcfs_statistics(self):
        """Update FCFS statistics panel"""
        try:
            if not self.fcfs_manager:
                return
                
            stats = self.fcfs_manager.get_system_stats()
            
            # Map the keys to the UI labels
            mapping = {
                'charging_count': 'currently_charging',
                'waiting_count': 'waiting_in_queue',
                'completed_count': 'completed_sessions',
                'total_energy': 'total_energy_delivered'
            }
            
            # Update each label if it exists
            for fcfs_key, ui_key in mapping.items():
                if ui_key in self.fcfs_stats_labels and fcfs_key in stats:
                    value = stats[fcfs_key]
                    if isinstance(value, (int, float)):
                        if isinstance(value, float):
                            self.fcfs_stats_labels[ui_key].config(text=f"{value:.1f}")
                        else:
                            self.fcfs_stats_labels[ui_key].config(text=str(value))
            
            # Also update total counts
            if 'active_evs' in self.fcfs_stats_labels:
                active_count = stats.get('charging_count', 0) + stats.get('waiting_count', 0)
                self.fcfs_stats_labels['active_evs'].config(text=str(active_count))
                
            # Update power utilization
            if 'power_utilization' in self.fcfs_stats_labels:
                self.fcfs_stats_labels['power_utilization'].config(
                    text=f"{stats.get('power_utilization', 0):.1f}%"
                )
            
        except Exception as e:
            print(f"❌ FCFS stats update error: {e}")    
    def update_fcfs_ev_table(self):
        """Update FCFS EV table"""
        try:
            if not self.fcfs_manager:
                return
                
            # Clear existing rows
            for item in self.fcfs_ev_tree.get_children():
                self.fcfs_ev_tree.delete(item)
            
            # Add current FCFS sessions
            for session_id, session in self.fcfs_manager.all_sessions.items():
                self.fcfs_ev_tree.insert('', 'end', values=(
                    session_id[:20],  # Session ID
                    session['arrival_time'].strftime('%H:%M'),  # Arrival Time
                    session['departure_time'].strftime('%H:%M'),  # Departure Time
                    f"{session['energy_needed']:.1f}",  # Energy Needed
                    f"{session['energy_delivered']:.1f}",  # Energy Delivered
                    f"{(session['energy_delivered']/max(session['energy_needed'], 0.1)*100):.1f}%",  # Progress
                    f"{session['current_power']:.1f}",  # Current Power
                    session.get('assigned_station', 'Queue'),  # Station/Queue
                    session['status'].title()  # Status
                ))
        except Exception as e:
            print(f"❌ FCFS EV table update error: {e}")
            
    def update_fcfs_station_status(self):
        """Update FCFS station status"""
        try:
            if not self.fcfs_manager:
                return
                
            # Update station indicators based on FCFS charging stations
            for station_id, session in self.fcfs_manager.charging_stations.items():
                if station_id in self.fcfs_station_labels:
                    station_label = self.fcfs_station_labels[station_id]
                    
                    if session:  # Station is occupied
                        # Get session ID for tooltip
                        short_id = session['sessionID'][:10] + "..." if len(session['sessionID']) > 10 else session['sessionID']
                        power = session.get('current_power', 0.0)
                        
                        if power > 0.1:  # Actively charging
                            station_label.config(
                                text=f"{station_id.split('_')[-1]}\n⚡",
                                fg='#2ecc71',  # Green
                                bg='#27ae60'
                            )
                            # Add tooltip with details
                            station_tooltip = f"EV: {short_id}\nPower: {power:.1f}kW"
                            station_label.tooltip = station_tooltip  # Custom attribute for tooltip
                        else:  # Connected but not charging
                            station_label.config(
                                text=f"{station_id.split('_')[-1]}\n🚗",
                                fg='#f39c12',  # Orange
                                bg='#d35400'
                            )
                    else:  # Station is empty
                        station_label.config(
                            text=f"{station_id.split('_')[-1]}\n⚫",
                            fg='#95a5a6',  # Gray
                            bg='#34495e'
                        )
            
        except Exception as e:
            print(f"❌ FCFS station status update error: {e}")

# Function to launch UI with simulation
def launch_charging_monitor_ui(session_manager, simulation_clock):
    """Launch the charging monitor UI"""
    try:
        ui = IntegratedChargingUI(session_manager, simulation_clock)
        print("✅ UI components created successfully")
        ui.run()
        return ui
    except Exception as e:
        print(f"❌ UI creation failed: {e}")
        raise
