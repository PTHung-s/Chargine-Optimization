"""
EV Input Launcher
Quick access to EV input functionality
"""

import sys
import os

def print_menu():
    """Print the main menu"""
    print("🚗 EV CHARGING SIMULATION - CUSTOM EV INPUT")
    print("=" * 50)
    print("Choose an option:")
    print()
    print("1. 🖥️  Interactive UI - Add EVs with guided interface")
    print("2. 🚀 Quick Add - Add EV with command line")  
    print("3. 📊 View Custom EVs - Show all added custom EVs")
    print("4. 🧪 Run Demo - See examples and test functionality")
    print("5. 🔧 Integration Test - Test with simulation")
    print("6. 📖 Help - Show documentation")
    print("7. 🚪 Exit")
    print()

def run_interactive_ui():
    """Run the interactive UI"""
    try:
        from ev_input_ui import EVInputUI
        ui = EVInputUI()
        ui.run()
    except Exception as e:
        print(f"❌ Error running interactive UI: {e}")

def run_quick_add():
    """Run quick add with user input"""
    try:
        from ev_input_ui import quick_add_ev
        
        print("🚀 QUICK ADD EV")
        print("-" * 20)
        print("Enter EV details (or press Ctrl+C to cancel):")
        
        arrival = input("Arrival time (YYYY-MM-DD HH:MM): ").strip()
        departure = input("Departure time (YYYY-MM-DD HH:MM): ").strip()
        energy = float(input("Energy needed (kWh): ").strip())
        
        ev = quick_add_ev(arrival, departure, energy)
        if ev:
            print(f"✅ Successfully added EV!")
            print(f"   Session ID: {ev['sessionID'][:40]}...")
        else:
            print("❌ Failed to add EV")
            
    except KeyboardInterrupt:
        print("\\n👋 Cancelled")
    except Exception as e:
        print(f"❌ Error in quick add: {e}")

def view_custom_evs():
    """View all custom EVs"""
    try:
        from ev_input_manager import EVInputManager
        
        ev_manager = EVInputManager()
        ev_manager.load_custom_evs()
        
        print("📊 CUSTOM EVS")
        print("-" * 20)
        
        if not ev_manager.custom_evs:
            print("No custom EVs found.")
            print("Use option 1 or 2 to add some!")
        else:
            print(ev_manager.get_custom_ev_summary())
            
    except Exception as e:
        print(f"❌ Error viewing custom EVs: {e}")

def run_demo():
    """Run demo"""
    try:
        import subprocess
        print("🧪 Running demo...")
        subprocess.run([sys.executable, "demo_ev_input.py"])
    except Exception as e:
        print(f"❌ Error running demo: {e}")

def run_integration_test():
    """Test integration with simulation"""
    try:
        import subprocess
        print("🔧 Testing integration with simulation...")
        subprocess.run([sys.executable, "demo_ev_input.py", "integration"])
    except Exception as e:
        print(f"❌ Error running integration test: {e}")

def show_help():
    """Show help documentation"""
    help_text = """
📖 EV INPUT HELP
================

OVERVIEW:
This tool allows you to add custom Electric Vehicle (EV) sessions to the 
EV Charging Simulation. Custom EVs will be included alongside the original 
data when running simulations.

REQUIRED INPUTS:
- Arrival Time: When the EV arrives at the charging station (YYYY-MM-DD HH:MM)
- Departure Time: When the EV leaves the charging station (YYYY-MM-DD HH:MM)  
- Energy Needed: How much energy the EV needs to charge (kWh)

AUTOMATIC GENERATION:
The system automatically generates:
- Session ID: Unique identifier for the EV session
- Station ID: Which charging station the EV uses
- User ID: Random user identifier
- Done Charging Time: When the EV finishes charging (based on power/energy)

FILE STORAGE:
- Custom EVs are saved to: custom_evs.json
- They are automatically loaded when the simulation runs
- You can backup/restore by copying this file

INTEGRATION:
- Custom EVs are automatically included in the main simulation
- They appear alongside original EVs in the UI
- They follow the same optimization and FCFS algorithms

EXAMPLES:
- Morning commuter: 08:00 arrival, 17:00 departure, 25 kWh
- Lunch visitor: 12:00 arrival, 14:00 departure, 10 kWh
- Evening event: 18:00 arrival, 23:00 departure, 35 kWh

TIPS:
- Make sure arrival < departure time
- Typical EV charging: 10-50 kWh
- Consider realistic parking durations
- Test with demo mode first

For technical details, see: ev_input_manager.py, ev_input_ui.py
"""
    print(help_text)

def main():
    """Main launcher function"""
    while True:
        try:
            print_menu()
            choice = input("Enter choice (1-7): ").strip()
            
            if choice == '1':
                run_interactive_ui()
            elif choice == '2':
                run_quick_add()
            elif choice == '3':
                view_custom_evs()
            elif choice == '4':
                run_demo()
            elif choice == '5':
                run_integration_test()
            elif choice == '6':
                show_help()
            elif choice == '7':
                print("👋 Goodbye!")
                break
            else:
                print("❌ Invalid choice. Please enter 1-7.")
                
            input("\\nPress Enter to continue...")
            print("\\n" + "="*60 + "\\n")
            
        except KeyboardInterrupt:
            print("\\n\\n👋 Goodbye!")
            break
        except Exception as e:
            print(f"❌ Unexpected error: {e}")
            input("Press Enter to continue...")

if __name__ == "__main__":
    main()
