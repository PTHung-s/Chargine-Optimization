"""
FCFS Data Sender for EV Charging Simulation
Sends FCFS charging data to UI via TCP socket
"""

import json
import socket
import threading
import time
from datetime import datetime

class FCFSDataSender:
    def __init__(self, fcfs_manager, simulation_clock, port=8766):
        self.fcfs_manager = fcfs_manager
        self.simulation_clock = simulation_clock
        self.port = port
        self.clients = []
        self.running = False
        self.server_socket = None
        
    def start_tcp_server(self):
        """Start TCP server to send FCFS data to UI"""
        try:
            self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.server_socket.bind(('localhost', self.port))
            self.server_socket.listen(5)
            
            print(f"🌐 FCFS TCP server listening on port {self.port}")
            
            while self.running:
                try:
                    client_socket, address = self.server_socket.accept()
                    print(f"📡 FCFS: New client connected: {address}")
                    
                    # Handle client in separate thread
                    client_thread = threading.Thread(
                        target=self.handle_client,
                        args=(client_socket, address),
                        daemon=True
                    )
                    client_thread.start()
                    
                except Exception as e:
                    if self.running:
                        print(f"❌ FCFS: Error accepting client: {e}")
                        
        except Exception as e:
            print(f"❌ FCFS TCP server error: {e}")
            
    def handle_client(self, client_socket, address):
        """Handle individual client connection"""
        try:
            self.clients.append(client_socket)
            
            # Send initial configuration
            self.send_initial_data(client_socket)
            
            # Keep connection alive and handle disconnection
            while self.running:
                try:
                    # Try to receive data (this will fail if client disconnects)
                    client_socket.settimeout(1.0)
                    data = client_socket.recv(1024)
                    if not data:
                        break
                except socket.timeout:
                    continue
                except:
                    break
                    
        except Exception as e:
            print(f"❌ FCFS: Client handler error for {address}: {e}")
        finally:
            if client_socket in self.clients:
                self.clients.remove(client_socket)
            client_socket.close()
            print(f"📡 FCFS: Client disconnected: {address}")
            
    def send_initial_data(self, client_socket):
        """Send initial configuration data to new client"""
        station_list = [f"FCFS_Station_{i}" for i in range(1, self.fcfs_manager.max_stations + 1)]
        
        initial_data = {
            "type": "fcfs_config",
            "data": {
                "stations": station_list,
                "max_power_per_station": 22.0,
                "total_stations": self.fcfs_manager.max_stations,
                "max_total_power": self.fcfs_manager.max_total_power,
                "algorithm": "first_come_first_serve"
            },
            "timestamp": datetime.now().isoformat()
        }
        self.send_to_client(client_socket, initial_data)
        
    def send_to_client(self, client_socket, data):
        """Send data to a specific client"""
        try:
            message = json.dumps(data) + "\n"  # Add newline as delimiter
            client_socket.send(message.encode('utf-8'))
        except Exception as e:
            print(f"❌ FCFS: Error sending to client: {e}")
            if client_socket in self.clients:
                self.clients.remove(client_socket)
                
    def collect_fcfs_data(self):
        """Collect all FCFS real-time data"""
        try:
            current_time = self.simulation_clock.get_current_time()
            
            # Get data from FCFS manager
            active_sessions = self.fcfs_manager.get_active_sessions()
            station_status = self.fcfs_manager.get_station_status()
            statistics = self.fcfs_manager.get_statistics()
            
            # Combine all data
            fcfs_data = {
                "type": "fcfs_update",
                "data": {
                    "simulation_time": current_time.strftime('%Y-%m-%d %H:%M:%S'),
                    "speed_multiplier": self.simulation_clock.speed_multiplier,
                    "evs": active_sessions,
                    "statistics": statistics,
                    "stations": station_status,
                    "algorithm": "FCFS",
                    "queue_info": {
                        "waiting_count": len([s for s in active_sessions if s['status'] == 'WAITING']),
                        "max_queue_position": max([s.get('queue_position', 0) for s in active_sessions if s.get('queue_position')], default=0)
                    }
                },
                "timestamp": datetime.now().isoformat()
            }
            
            return fcfs_data
            
        except Exception as e:
            print(f"❌ FCFS: Error collecting data: {e}")
            return None
            
    def start_data_streaming(self):
        """Start the FCFS data streaming loop"""
        def stream_data():
            while self.running:
                try:
                    if self.clients:  # Only send if there are connected clients
                        data = self.collect_fcfs_data()
                        if data:
                            # Send to all connected clients
                            disconnected_clients = []
                            for client in self.clients:
                                try:
                                    self.send_to_client(client, data)
                                except Exception as e:
                                    print(f"❌ FCFS: Error sending to client: {e}")
                                    disconnected_clients.append(client)
                            
                            # Remove disconnected clients
                            for client in disconnected_clients:
                                if client in self.clients:
                                    self.clients.remove(client)
                    
                    time.sleep(1)  # Send data every second
                    
                except Exception as e:
                    print(f"❌ FCFS: Data streaming error: {e}")
                    time.sleep(5)  # Wait before retrying
                    
        # Start streaming in a separate thread
        streaming_thread = threading.Thread(target=stream_data, daemon=True)
        streaming_thread.start()
        
    def start(self):
        """Start the FCFS data sender"""
        self.running = True
        
        # Start data streaming
        self.start_data_streaming()
        
        # Start TCP server (this will block in a separate thread)
        server_thread = threading.Thread(target=self.start_tcp_server, daemon=True)
        server_thread.start()
        
        print(f"🚀 FCFS data sender started on port {self.port}")
        print(f"📡 UI can connect to: localhost:{self.port}")
        
        return server_thread
        
    def stop(self):
        """Stop the FCFS data sender"""
        self.running = False
        if self.server_socket:
            self.server_socket.close()
        for client in self.clients:
            client.close()
        self.clients.clear()
        print("🛑 FCFS data sender stopped")
