"""
EV Input Manager
Allows users to add custom EV sessions to the simulation
"""

import json
import uuid
from datetime import datetime, timedelta
import random
import string

class EVInputManager:
    def __init__(self, data_file_path="caltech/final_gop.json"):
        """
        Initialize EV input manager
        
        Args:
            data_file_path: Path to the main data file        """
        self.data_file_path = data_file_path
        self.custom_evs = {}  # Store custom EVs grouped by date (same structure as final_gop.json)
        
    def generate_session_id(self, connection_time):
        """Generate a realistic session ID based on connection time"""
        # Format: siteID_clusterID_stationID_spaceID_timestamp
        site_id = random.randint(1, 99)
        cluster_id = random.randint(1, 99)
        station_id = random.randint(1, 999)
        space_id = random.randint(1, 999)
        
        timestamp = connection_time.strftime('%Y-%m-%d %H:%M:%S.%f')
        return f"{site_id}_{cluster_id}_{station_id}_{space_id}_{timestamp}"
    
    def generate_station_id(self):
        """Generate a realistic station ID"""
        site = random.randint(1, 99)
        cluster = random.randint(1, 99)
        station = random.randint(1, 99)
        space = random.randint(1, 999)
        return f"{site}-{cluster}-{station}-{space}"
    
    def generate_user_id(self):
        """Generate a random user ID"""
        return ''.join(random.choices(string.ascii_lowercase + string.digits, k=12))
    
    def generate_space_id(self):
        """Generate a realistic space ID"""
        state = random.choice(['CA', 'NY', 'TX', 'FL'])
        number = random.randint(100, 999)
        return f"{state}-{number}"
    
    def calculate_done_charging_time(self, connection_time, disconnect_time, kwh_delivered):
        """
        Calculate realistic done charging time based on charging power and energy needed
        
        Args:
            connection_time: When EV arrived
            disconnect_time: When EV will leave  
            kwh_delivered: Energy needed (kWh)
            
        Returns:
            datetime: When charging will be completed
        """
        # Assume average charging power of 15-20 kW (realistic for Level 2 charging)
        avg_power = random.uniform(15.0, 20.0)  # kW
        
        # Calculate charging time needed (hours)
        charging_hours = kwh_delivered / avg_power
        
        # Done charging time = connection time + charging duration
        done_charging = connection_time + timedelta(hours=charging_hours)
        
        # Ensure done charging is not after disconnect time
        if done_charging > disconnect_time:
            # If charging takes longer than stay duration, done charging = disconnect time
            done_charging = disconnect_time - timedelta(minutes=1)  # Leave 1 minute buffer
            
        return done_charging
    
    def create_custom_ev(self, connection_time, disconnect_time, kwh_delivered):
        """
        Create a custom EV session with user inputs
        
        Args:
            connection_time: datetime - When EV arrives
            disconnect_time: datetime - When EV leaves
            kwh_delivered: float - Energy needed in kWh
            
        Returns:
            dict: Complete EV session data
        """
        # Generate unique IDs
        session_id = self.generate_session_id(connection_time)
        station_id = self.generate_station_id()
        user_id = self.generate_user_id()
        space_id = self.generate_space_id()
        
        # Generate cluster and site IDs from station ID
        station_parts = station_id.split('-')
        site_id = f"00{station_parts[0]:0>2}"[-4:]  # Format as 4-digit site ID
        cluster_id = f"00{station_parts[1]:0>2}"[-4:]  # Format as 4-digit cluster ID
        
        # Calculate done charging time
        done_charging_time = self.calculate_done_charging_time(
            connection_time, disconnect_time, kwh_delivered
        )
        
        # Create the EV session object
        ev_session = {
            "_id": str(uuid.uuid4()),
            "userInputs": "CUSTOM_USER_INPUT",  # Mark as user-created
            "sessionID": session_id,
            "stationID": station_id,
            "spaceID": space_id,
            "siteID": site_id,
            "clusterID": cluster_id,
            "connectionTime": connection_time.strftime('%a, %d %b %Y %H:%M:%S GMT'),
            "disconnectTime": disconnect_time.strftime('%a, %d %b %Y %H:%M:%S GMT'),
            "kWhDelivered": round(kwh_delivered, 3),
            "doneChargingTime": done_charging_time.strftime('%a, %d %b %Y %H:%M:%S GMT'),
            "timezone": "America/Los_Angeles",  # Constant timezone
            "userID": user_id
        }
        
        return ev_session
    
    def add_custom_ev(self, connection_time, disconnect_time, kwh_delivered):
        """
        Add a custom EV to the simulation
        
        Args:
            connection_time: datetime - When EV arrives
            disconnect_time: datetime - When EV leaves  
            kwh_delivered: float - Energy needed in kWh
            
        Returns:
            dict: The created EV session
        """
        # Validate inputs
        if connection_time >= disconnect_time:
            raise ValueError("Connection time must be before disconnect time")
        
        if kwh_delivered <= 0:
            raise ValueError("Energy delivered must be positive")
          # Create the EV session
        ev_session = self.create_custom_ev(connection_time, disconnect_time, kwh_delivered)
        
        # Group by date (same format as final_gop.json: "dd-MMM-yyyy")
        date_key = connection_time.strftime("%d-%b-%Y")
        
        # Add to custom EVs dictionary
        if date_key not in self.custom_evs:
            self.custom_evs[date_key] = []
        self.custom_evs[date_key].append(ev_session)
        
        # Save to file automatically
        self.save_custom_evs()
        
        print(f"✅ Added custom EV: {ev_session['sessionID'][:30]}...")
        print(f"   Arrival: {connection_time.strftime('%Y-%m-%d %H:%M')}")
        print(f"   Departure: {disconnect_time.strftime('%Y-%m-%d %H:%M')}")
        print(f"   Energy: {kwh_delivered} kWh")
        print(f"   Done Charging: {datetime.strptime(ev_session['doneChargingTime'], '%a, %d %b %Y %H:%M:%S GMT').strftime('%Y-%m-%d %H:%M')}")
        
        return ev_session
    def get_custom_evs_for_date(self, target_date):
        """
        Get custom EVs for a specific date
        
        Args:
            target_date: datetime.date - Target date
            
        Returns:
            list: Custom EV sessions for that date
        """
        date_str = target_date.strftime('%d-%b-%Y')
        
        # Return EVs for that specific date from dictionary
        return self.custom_evs.get(date_str, [])
    
    def integrate_with_simulation_data(self, original_data, target_date):
        """
        Integrate custom EVs with original simulation data
        
        Args:
            original_data: dict - Original data from JSON file
            target_date: datetime.date - Target simulation date
            
        Returns:
            dict: Combined data with custom EVs
        """
        date_str = target_date.strftime('%d-%b-%Y')
        
        # Create a copy of original data
        combined_data = original_data.copy()
        
        # Get custom EVs for the target date
        custom_evs = self.get_custom_evs_for_date(target_date)
        
        if custom_evs:
            if date_str in combined_data:
                # Add to existing date
                combined_data[date_str].extend(custom_evs)
            else:
                # Create new date entry
                combined_data[date_str] = custom_evs
            
            print(f"✅ Integrated {len(custom_evs)} custom EVs for {date_str}")
        return combined_data
    
    def save_custom_evs(self, filename="custom_evs.json"):
        """Save custom EVs to a separate file"""
        try:
            with open(filename, 'w') as f:
                json.dump(self.custom_evs, f, indent=2)
            total_evs = sum(len(evs) for evs in self.custom_evs.values())
            print(f"✅ Saved {total_evs} custom EVs to {filename}")
        except Exception as e:
            print(f"❌ Error saving custom EVs: {e}")
    
    def load_custom_evs(self, filename="custom_evs.json"):
        """Load custom EVs from file"""
        try:
            with open(filename, 'r') as f:
                loaded_data = json.load(f)
                
                # Handle both old format (list) and new format (dict)
                if isinstance(loaded_data, list):
                    print(f"ℹ️ Converting old format custom EVs to new date-grouped format")
                    # Convert old list format to new dict format
                    self.custom_evs = {}
                    for ev in loaded_data:
                        # Extract date from connectionTime
                        try:
                            conn_time = datetime.strptime(ev['connectionTime'], "%a, %d %b %Y %H:%M:%S GMT")
                            date_key = conn_time.strftime("%d-%b-%Y")
                            if date_key not in self.custom_evs:
                                self.custom_evs[date_key] = []
                            self.custom_evs[date_key].append(ev)
                        except Exception as e:
                            print(f"⚠️ Skipping invalid EV data: {e}")
                    
                    # Save in new format
                    self.save_custom_evs(filename)
                else:
                    # Already in correct dict format
                    self.custom_evs = loaded_data
                    
            total_evs = sum(len(evs) for evs in self.custom_evs.values())
            print(f"✅ Loaded {total_evs} custom EVs from {filename}")
        except FileNotFoundError:
            print(f"ℹ️ No custom EVs file found: {filename}")
            self.custom_evs = {}
        except Exception as e:
            print(f"❌ Error loading custom EVs: {e}")
            self.custom_evs = {}
    
    def clear_custom_evs(self):
        """Clear all custom EVs"""
        self.custom_evs.clear()
        print("✅ Cleared all custom EVs")
    def get_custom_ev_summary(self):
        """Get summary of custom EVs"""
        if not self.custom_evs:
            return "No custom EVs added"
        
        total_energy = 0
        total_count = 0
        dates = set()
        
        for date_key, evs in self.custom_evs.items():
            for ev in evs:
                total_energy += ev['kWhDelivered']
                total_count += 1
                connection_time = datetime.strptime(ev['connectionTime'], '%a, %d %b %Y %H:%M:%S GMT')
                dates.add(connection_time.date())
            summary = f"""
Custom EV Summary:
- Total EVs: {total_count}
- Total Energy: {total_energy:.1f} kWh
- Date Range: {len(dates)} different dates
- Average Energy per EV: {total_energy/total_count:.1f} kWh
"""
        return summary

# Example usage and testing
if __name__ == "__main__":
    # Create EV input manager
    ev_manager = EVInputManager()
    
    # Example: Add a custom EV
    # Arrives at 9:00 AM, leaves at 5:00 PM, needs 25 kWh
    arrival = datetime(2018, 7, 1, 9, 0, 0)
    departure = datetime(2018, 7, 1, 17, 0, 0) 
    energy = 25.0
    
    custom_ev = ev_manager.add_custom_ev(arrival, departure, energy)
    
    # Print summary
    print(ev_manager.get_custom_ev_summary())
    
    # Save to file
    ev_manager.save_custom_evs()
