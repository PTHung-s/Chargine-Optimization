"""
First-Come-First-Serve (FCFS) Charging Manager
Manages EV charging stations using first-come-first-serve algorithm
"""

from datetime import datetime, timedelta
import threading
import time

class FCFSChargingManager:
    def __init__(self, max_stations=20, max_total_power=300.0, step_time_seconds=1.0, simulation_clock=None):
        """
        Initialize FCFS charging manager
        
        Args:
            max_stations: Maximum number of charging stations
            max_total_power: Maximum total power available (kWh)
        """
        self.max_stations = max_stations
        self.max_total_power = max_total_power
        self.step_time_seconds = step_time_seconds  # Simulation time step in seconds
        self.simulation_clock = simulation_clock
        
        # Station management
        self.charging_stations = {}  # station_id -> session_info
        self.waiting_queue = []      # List of sessions waiting for charging
        self.completed_sessions = [] # List of completed sessions
        
        # Session tracking
        self.all_sessions = {}       # session_id -> session_data
        self.session_states = {}     # session_id -> state ('waiting', 'charging', 'completed', 'departed')
          # Power management
        self.current_total_power = 0.0
        
        # Initialize charging stations
        for i in range(1, max_stations + 1):
            self.charging_stations[f"FCFS_Station_{i}"] = None
            
    def add_session(self, session):
        """Add a new EV session to the system"""
        session_id = session['sessionID']
        
        # Debug: Print session arrival time
        arrival_time = session['connectionTime_dt']
        departure_time = session['disconnectTime_dt']
        print(f"🚗 FCFS: Adding session {session_id[:15]}... arrival: {arrival_time.strftime('%Y-%m-%d %H:%M:%S')}")
          # Initialize session data for FCFS
        fcfs_session = {
            'sessionID': session_id,
            'arrival_time': arrival_time,
            'departure_time': departure_time,
            'energy_needed': session.get('remaining_energy', session.get('kWhDelivered', 0)),
            'energy_delivered': 0.0,
            'energy_remaining': session.get('remaining_energy', session.get('kWhDelivered', 0)),
            'current_power': 0.0,
            'assigned_station': None,
            'queue_position': None,
            'charging_start_time': None,
            'charging_end_time': None,
            'status': 'waiting'
        }
        
        self.all_sessions[session_id] = fcfs_session
        self.session_states[session_id] = 'waiting'
        
        # Add to waiting queue
        self.waiting_queue.append(fcfs_session)
        self.waiting_queue.sort(key=lambda x: x['arrival_time'])  # Sort by arrival time
        
        # Update queue positions
        self._update_queue_positions()
        
        print(f"🚗 FCFS: Added session {session_id[:15]}... to queue (position {fcfs_session['queue_position']})")
        
    def _update_queue_positions(self):
        """Update queue positions for all waiting sessions"""
        for i, session in enumerate(self.waiting_queue):
            session['queue_position'] = i + 1
    def _find_available_station(self):
        """Find an available charging station"""
        for station_id, occupant in self.charging_stations.items():
            if occupant is None:
                return station_id
        return None
    def _calculate_initial_charging_power(self, session, current_time):
        """
        Calculate charging power for a session when it starts charging
        Formula: min(max_station_power, remaining_energy / min(1_hour, remaining_time))
        """
        remaining_energy = session['energy_remaining']
        
        # Calculate remaining time at station (similar to session_manager.py)
        remaining_time_seconds = (session['departure_time'] - current_time).total_seconds()
        remaining_time_hours = remaining_time_seconds / 3600.0
        
        # Use minimum of 1 hour or actual remaining time
        effective_time = min(1.0, remaining_time_hours)
        
        if effective_time <= 0:
            return 0.0
        
        # Calculate required power to finish in effective time
        required_power = remaining_energy / effective_time
        
        # Limit to maximum station power (22kW)
        max_station_power = 22.0
        charging_power = min(max_station_power, required_power)
        
        print(f"🔋 FCFS Power Calc for {session['sessionID'][:15]}...")
        print(f"   Remaining energy: {remaining_energy:.1f}kWh")
        print(f"   Remaining time: {remaining_time_hours:.2f}h, effective: {effective_time:.2f}h")
        print(f"   Required power: {required_power:.1f}kW, limited to: {charging_power:.1f}kW")
        
        return charging_power
            
        return power_distribution
        
    def update_charging(self, current_time):
        """Update charging process for current time step"""
        changes_made = False
        need_power_update = False
          # Process departures first (including fully charged waiting cars)
        for session_id in list(self.all_sessions.keys()):
            session = self.all_sessions[session_id]
            
            if (session['status'] in ['charging', 'waiting', 'fully_charged_waiting'] and 
                current_time >= session['departure_time']):
                self._process_departure(session, current_time)
                changes_made = True
                need_power_update = True  # Update power when a car departs
                
        # Process charging completions
        for session_id in list(self.all_sessions.keys()):
            session = self.all_sessions[session_id]
            
            if (session['status'] == 'charging' and 
                session['energy_remaining'] <= 0.1):
                self._complete_charging(session, current_time)
                changes_made = True
                need_power_update = True  # Update power when charging completes
                
        # Assign waiting sessions to available stations
        new_charging = False
        available_station = self._find_available_station()
        while available_station and self.waiting_queue:
            next_session = self.waiting_queue.pop(0)
            self._start_charging(next_session, available_station, current_time)
            self._update_queue_positions()
            available_station = self._find_available_station()
            changes_made = True
            new_charging = True
          # Update power distribution ONLY when new cars start charging or leave
        if new_charging or need_power_update:
            # When new cars arrive, recalculate power for ALL charging sessions
            # to ensure fair distribution within total power limit
            self._rebalance_power_on_change(current_time)
          # Always update energy delivered based on current power (but don't change power)
        for session in self.all_sessions.values():
            if session['status'] == 'charging':                # Get the step time from simulation clock if available, otherwise use default
                step_time = self.step_time_seconds
                if self.simulation_clock:
                    # Calculate step time based on simulation clock's speed multiplier
                    # Default to 1 second * speed_multiplier if simulation clock is available
                    step_time = 1.0 * self.simulation_clock.speed_multiplier
                
                # Calculate energy delivered in this time step
                energy_step = session['current_power'] * (step_time / 3600)  # Convert to kWh
                session['energy_delivered'] += energy_step
                session['energy_remaining'] = max(0, session['energy_needed'] - session['energy_delivered'])
                
                # Debug log for energy update
                if session['energy_delivered'] % 1 < energy_step:  # Log every ~1 kWh
                    print(f"⚡ FCFS Energy: {session['sessionID'][:8]}... +{energy_step:.3f}kWh with {session['current_power']:.1f}kW " 
                          f"(step: {step_time:.2f}s) → {session['energy_delivered']:.2f}/{session['energy_needed']:.1f}kWh")
                
                changes_made = True
        return changes_made
        
    def _start_charging(self, session, station_id, current_time):
        """Start charging a session at a station"""
        session['assigned_station'] = station_id
        session['status'] = 'charging'
        session['charging_start_time'] = current_time
        session['queue_position'] = None
        
        # Calculate charging power using the new formula
        # min(max_station_power, remaining_energy / min(1_hour, remaining_time))
        charging_power = self._calculate_initial_charging_power(session, current_time)
        session['current_power'] = charging_power
        
        self.charging_stations[station_id] = session
        self.session_states[session['sessionID']] = 'charging'        
        print(f"🔌 FCFS: Started charging session {session['sessionID'][:15]}... at {station_id} with power {charging_power:.1f}kW")
        
    def _complete_charging(self, session, current_time):
        """Complete charging for a session but keep it in station until departure"""
        station_id = session['assigned_station']
        session['status'] = 'fully_charged_waiting'  # NEW: Keep in station but not charging
        session['charging_end_time'] = current_time
        session['current_power'] = 0.0
        session['energy_remaining'] = 0.0
        session['energy_delivered'] = session['energy_needed']
        
        # DON'T free the station yet - keep it occupied until departure
        # Station will be freed in _process_departure()
        
        self.session_states[session['sessionID']] = 'fully_charged_waiting'
        print(f"🔋 FCFS: Session {session['sessionID'][:15]}... fully charged at {station_id}, waiting for departure")
        
    def _process_departure(self, session, current_time):
        """Process session departure and properly free the station"""
        station_id = session['assigned_station']
        old_status = session['status']
        
        # Free the station when departing
        if station_id and station_id in self.charging_stations:
            self.charging_stations[station_id] = None
            print(f"🏁 FCFS: Freed station {station_id} (was occupied by {session['sessionID'][:15]}...)")
            
        session['status'] = 'departed'
        session['departure_actual_time'] = current_time
        session['assigned_station'] = None
        session['current_power'] = 0.0
        
        # Remove from waiting queue if still waiting
        if session in self.waiting_queue:
            self.waiting_queue.remove(session)
            self._update_queue_positions()
            
        # Move to completed list if not already there
        if session not in self.completed_sessions:
            self.completed_sessions.append(session)
        
        self.session_states[session['sessionID']] = 'departed'
        
        print(f"🚗� FCFS: Session {session['sessionID'][:15]}... departed from {station_id} (was {old_status})")
        
        # Note: No duplicate logic - station is already freed above
        
    def get_station_status(self):
        """Get current status of all stations"""
        station_status = {}
        
        for station_id, session in self.charging_stations.items():
            if session is None:
                station_status[station_id] = {
                    "status": "AVAILABLE",
                    "assigned_session": None,
                    "current_power": 0.0,
                    "is_fully_charged": False,
                    "session_id": None,
                    "energy_progress": 0.0
                }
            else:
                # Determine precise status based on session state
                if session['status'] == 'charging':
                    status = "CHARGING"
                elif session['status'] == 'fully_charged_waiting':
                    status = "FULLY_CHARGED_WAITING"
                else:
                    status = "OCCUPIED"
                
                # Calculate progress percentage
                progress = 0.0
                if session['energy_needed'] > 0:
                    progress = min((session['energy_delivered'] / session['energy_needed']) * 100, 100)
                
                station_status[station_id] = {
                    "status": status,
                    "assigned_session": session['sessionID'][:15],
                    "current_power": round(session['current_power'], 2),
                    "is_fully_charged": session['status'] == 'fully_charged_waiting',
                    "session_id": session['sessionID'],
                    "energy_progress": round(progress, 1),
                    "energy_delivered": round(session['energy_delivered'], 2),
                    "energy_needed": round(session['energy_needed'], 2)
                }
                
        return station_status
        
    def get_queue_info(self):
        """Get information about waiting queue"""
        queue_data = []
        
        for i, session in enumerate(self.waiting_queue):
            queue_data.append({
                "position": i + 1,
                "session_id": session['sessionID'][:15],
                "full_session_id": session['sessionID'],
                "arrival_time": session['arrival_time'].strftime('%H:%M'),
                "departure_time": session['departure_time'].strftime('%H:%M'),
                "energy_needed": round(session['energy_needed'], 2)
            })
        
        return {
            "queue_length": len(self.waiting_queue),
            "queue_sessions": queue_data
        }
    
    def get_active_sessions(self):
        """Get all active sessions (waiting + charging)"""
        active = []
        
        for session in self.all_sessions.values():
            if session['status'] in ['waiting', 'charging']:
                progress = min((session['energy_delivered'] / session['energy_needed']) * 100, 100) if session['energy_needed'] > 0 else 100
                
                active.append({
                    "id": session['sessionID'][:15],
                    "full_id": session['sessionID'],
                    "arrival_time": session['arrival_time'].strftime('%H:%M'),
                    "departure_time": session['departure_time'].strftime('%H:%M'),
                    "energy_needed": round(session['energy_needed'], 2),
                    "energy_delivered": round(session['energy_delivered'], 2),
                    "energy_remaining": round(session['energy_remaining'], 2),
                    "progress_percent": round(progress, 1),
                    "current_power": round(session['current_power'], 2),
                    "station_id": session['assigned_station'] or f"Queue #{session['queue_position']}" if session['queue_position'] else "Waiting",
                    "status": session['status'].upper(),
                    "queue_position": session['queue_position']
                })
        return active
        
    def get_statistics(self):
        """Get charging statistics"""
        active_sessions = [s for s in self.all_sessions.values() if s['status'] in ['waiting', 'charging']]
        charging_sessions = [s for s in active_sessions if s['status'] == 'charging']
        
        total_energy = sum(s['energy_delivered'] for s in self.all_sessions.values())
        total_power = sum(s['current_power'] for s in charging_sessions)
        avg_power = total_power / max(1, len(charging_sessions))
        
        # Calculate power efficiency
        max_possible_power = len(charging_sessions) * 22.0  # Max per station
        power_efficiency = (total_power / max_possible_power * 100) if max_possible_power > 0 else 0
        
        return {
            "active_evs": len(active_sessions),
            "completed_sessions": len(self.completed_sessions),
            "currently_charging": len(charging_sessions),
            "waiting_in_queue": len([s for s in active_sessions if s['status'] == 'waiting']),
            "total_energy_delivered": round(total_energy, 2),
            "average_power": round(avg_power, 2),
            "total_power": round(total_power, 2),
            "power_utilization": round((total_power / self.max_total_power) * 100, 1),
            "power_efficiency": round(power_efficiency, 1),
            "stations_occupied": len([s for s in self.charging_stations.values() if s is not None]),
            "stations_available": len([s for s in self.charging_stations.values() if s is None])
        }
    
    def get_system_stats(self):
        """Get system statistics for main simulation compatibility"""
        stats = self.get_statistics()
        return {
            'charging_count': stats['currently_charging'],
            'waiting_count': stats['waiting_in_queue'],
            'completed_count': stats['completed_sessions'],
            'total_energy': stats['total_energy_delivered']
        }
    
    def add_ev_session(self, session):
        """Alias for add_session for compatibility"""
        return self.add_session(session)
    
    def update_fcfs_charging(self, current_time):
        """Update FCFS charging system - alias for update_charging"""
        return self.update_charging(current_time)
    
    def remove_completed_ev(self, session_id):
        """Remove completed EV by session ID"""
        if session_id in self.all_sessions:
            session = self.all_sessions[session_id]
            if session['status'] in ['completed', 'departed']:
                return True
        return False
    
    def debug_power_allocation(self):
        """Debug method to print current power allocation"""
        charging_sessions = [s for s in self.all_sessions.values() if s['status'] == 'charging']
        
        if not charging_sessions:
            print("🔍 FCFS Debug: No sessions currently charging")
            return
            
        print("🔍 FCFS Power Allocation Debug:")
        total_allocated = 0
        
        for session in charging_sessions:
            station = session.get('assigned_station', 'Unknown')
            power = session['current_power']
            energy_progress = f"{session['energy_delivered']:.1f}/{session['energy_needed']:.1f}kWh"
            total_allocated += power
            
            print(f"   🔌 {station}: {session['sessionID'][:15]}... - {power:.1f}kW ({energy_progress})")
        
        print(f"   📊 Total Allocated: {total_allocated:.1f}kW / {self.max_total_power}kW")
        print(f"   📊 Utilization: {(total_allocated/self.max_total_power)*100:.1f}%")
        
    def _rebalance_power_on_change(self, current_time):
        """
        Rebalance power allocation when there are changes (new arrivals/departures)
        This ensures total power doesn't exceed max_total_power
        """
        charging_sessions = [s for s in self.all_sessions.values() if s['status'] == 'charging']
        
        if not charging_sessions:
            return
        
        # Calculate total power currently allocated
        total_current_power = sum(s['current_power'] for s in charging_sessions)
        
        # If total exceeds limit, scale down proportionally
        if total_current_power > self.max_total_power:
            scaling_factor = self.max_total_power / total_current_power
            
            print(f"🔄 FCFS Power Rebalance: Scaling down by {scaling_factor:.2f} (total: {total_current_power:.1f}kW > {self.max_total_power}kW)")
            
            for session in charging_sessions:
                old_power = session['current_power']
                session['current_power'] = old_power * scaling_factor
                print(f"   📉 {session['sessionID'][:15]}... power: {old_power:.1f}kW → {session['current_power']:.1f}kW")
        else:
            print(f"✅ FCFS Power OK: Total {total_current_power:.1f}kW / {self.max_total_power}kW")
            
    def get_fcfs_status_summary(self):
        """Get a quick summary of FCFS status for main loop"""
        stats = self.get_statistics()
        return {
            'total_sessions': len(self.all_sessions),
            'charging': stats['currently_charging'],
            'waiting': stats['waiting_in_queue'],
            'completed': stats['completed_sessions'],
            'total_power': stats['total_power'],
            'power_utilization': stats['power_utilization'],
            'stations_occupied': stats['stations_occupied']
        }

