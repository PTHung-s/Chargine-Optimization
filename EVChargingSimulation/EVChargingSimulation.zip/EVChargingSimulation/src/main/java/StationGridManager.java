import com.google.gson.JsonObject;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

/**
 * StationGridManager handles the creation and management of charging station grids
 * Manages both FCFS and Optimization station displays
 */
public class StationGridManager {
    
    private GridPane stationGrid;
    
    /**
     * Create the main station grid with both FCFS and Optimization sections
     */
    public GridPane createStationGrid() {        
        GridPane outerGrid = new GridPane();
        outerGrid.setHgap(25);
        outerGrid.setVgap(15);
        outerGrid.setPadding(new Insets(20));
        outerGrid.setStyle("-fx-background-color: #34495e; -fx-background-radius: 5; -fx-effect: dropshadow(gaussian, rgba(231, 76, 60, 0.6), 15, 0.3, 0, 0);");
        outerGrid.setPrefHeight(500);
        outerGrid.setPrefWidth(650);

        // Create title labels
        Label fcfsTitle = new Label("FCFS ALGORITHM (for comparison only)");
        fcfsTitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 14));
        fcfsTitle.setTextFill(Color.ORANGE);
        fcfsTitle.setAlignment(Pos.CENTER);
        fcfsTitle.setMaxWidth(Double.MAX_VALUE);
        
        Label optTitle = new Label("OPTIMIZATION ALGORITHM");
        optTitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 14));
        optTitle.setTextFill(Color.LIGHTBLUE);
        optTitle.setAlignment(Pos.CENTER);
        optTitle.setMaxWidth(Double.MAX_VALUE);

        // Add titles
        outerGrid.add(fcfsTitle, 0, 0);
        outerGrid.add(optTitle, 1, 0);

        // Create sub-grids
        GridPane fcfsGrid = createSubGrid(true);
        GridPane optGrid = createSubGrid(false);

        // Create station cards with layout 5x4 (5 columns, 4 rows)
        for (int i = 1; i <= 20; i++) {
            VBox fcfsCard = createStationCard("FCFS_Station_" + i, "S" + i);
            fcfsGrid.add(fcfsCard, (i-1) % 5, (i-1) / 5);
            
            VBox optCard = createStationCard("OPT_Station_" + i, "S" + i);
            optGrid.add(optCard, (i-1) % 5, (i-1) / 5);
        }

        // Set row constraints for station cards
        for (int i = 0; i < 4; i++) {
            RowConstraints rowConstraint = new RowConstraints();
            rowConstraint.setPrefHeight(105);
            rowConstraint.setMinHeight(100);
            fcfsGrid.getRowConstraints().add(rowConstraint);
            
            RowConstraints optRowConstraint = new RowConstraints();
            optRowConstraint.setPrefHeight(105);
            optRowConstraint.setMinHeight(100);
            optGrid.getRowConstraints().add(optRowConstraint);
        }
        
        // Set column constraints for equal column sizes
        for (int i = 0; i < 5; i++) {
            ColumnConstraints fcfsColConstraint = new ColumnConstraints();
            fcfsColConstraint.setPrefWidth(105);
            fcfsColConstraint.setMinWidth(100);
            fcfsGrid.getColumnConstraints().add(fcfsColConstraint);
            
            ColumnConstraints optColConstraint = new ColumnConstraints();
            optColConstraint.setPrefWidth(105);
            optColConstraint.setMinWidth(100);
            optGrid.getColumnConstraints().add(optColConstraint);
        }
        
        // Add grids to outer grid
        outerGrid.add(fcfsGrid, 0, 1);
        outerGrid.add(optGrid, 1, 1);

        // Set column constraints for outer grid - 2 equal columns 50-50
        ColumnConstraints column1 = new ColumnConstraints();
        column1.setPercentWidth(50);
        
        ColumnConstraints column2 = new ColumnConstraints();
        column2.setPercentWidth(50);
        
        outerGrid.getColumnConstraints().addAll(column1, column2);
        
        // Set row constraints for outer grid
        RowConstraints titleRow = new RowConstraints();
        titleRow.setPrefHeight(30);
        
        RowConstraints contentRow = new RowConstraints();
        contentRow.setPrefHeight(420);
        
        outerGrid.getRowConstraints().addAll(titleRow, contentRow);
        
        this.stationGrid = outerGrid;
        return outerGrid;
    }
    
    /**
     * Create a sub-grid for either FCFS or Optimization stations
     */
    private GridPane createSubGrid(boolean isFCFS) {
        GridPane grid = new GridPane();
        grid.setHgap(8);
        grid.setVgap(8);
        grid.setPadding(new Insets(10));
        
        if (isFCFS) {
            grid.setStyle("-fx-background-color: #2c3e50; -fx-background-radius: 5; -fx-effect: dropshadow(gaussian, rgba(230, 126, 34, 0.5), 12, 0.3, 0, 0);");
        } else {
            grid.setStyle("-fx-background-color: #2c3e50; -fx-background-radius: 5; -fx-effect: dropshadow(gaussian, rgba(52, 152, 219, 0.5), 12, 0.3, 0, 0);");
        }
        
        return grid;
    }
    
    /**
     * Create a station card
     */
    private VBox createStationCard(String stationId, String displayName) {
        VBox card = new VBox(4);
        card.setAlignment(Pos.CENTER);
        card.setPadding(new Insets(8));
        card.setPrefWidth(95);  
        card.setPrefHeight(95); 
        card.setMaxWidth(95);
        card.setMaxHeight(95);
        card.setMinWidth(95);
        card.setMinHeight(95);
        
        boolean isFCFS = stationId.startsWith("FCFS");
        
        // Station ID label
        Label stationLabel = new Label((isFCFS ? "F-" : "O-") + displayName);
        stationLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 10));
        stationLabel.setTextFill(isFCFS ? Color.web("#f39c12") : Color.web("#3498db"));
        stationLabel.setAlignment(Pos.CENTER);
        
        // Status indicator
        Label statusLabel = new Label("Available");
        statusLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 9));
        statusLabel.setTextFill(Color.web("#95a5a6"));
        statusLabel.setAlignment(Pos.CENTER);
        statusLabel.setMaxWidth(90);
        statusLabel.setWrapText(false);
        
        // Power consumption display
        Label powerLabel = new Label("0.0 kW");
        powerLabel.setFont(Font.font("Segoe UI", FontWeight.NORMAL, 8));
        powerLabel.setTextFill(Color.WHITE);
        powerLabel.setAlignment(Pos.CENTER);
        
        // Progress indicator
        Label progressLabel = new Label("");
        progressLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 8));
        progressLabel.setTextFill(Color.web("#95a5a6"));
        progressLabel.setAlignment(Pos.CENTER);
        
        // EV info
        Label evInfoLabel = new Label("");
        evInfoLabel.setFont(Font.font("Segoe UI", 7));
        evInfoLabel.setTextFill(Color.WHITE);
        evInfoLabel.setMaxWidth(85);
        evInfoLabel.setWrapText(true);
        evInfoLabel.setAlignment(Pos.CENTER);
        
        // Set max widths to prevent layout issues
        stationLabel.setMaxWidth(85);
        statusLabel.setMaxWidth(85);
        powerLabel.setMaxWidth(85);
        progressLabel.setMaxWidth(85);
        
        card.getChildren().addAll(stationLabel, statusLabel, powerLabel, progressLabel, evInfoLabel);
        card.setUserData(stationId);
        
        // Enhanced styling with better gradients and shadows
        if (isFCFS) {
            card.setStyle(
                "-fx-background-color: rgba(243, 156, 18, 0.5);" +
                "-fx-border-color: #f39c12;" +
                "-fx-border-width: 2px;" +
                "-fx-border-radius: 5px;" +
                "-fx-background-radius: 5px;"
            );
        } else {
            card.setStyle(
                "-fx-background-color: rgba(52, 152, 219, 0.5);" +
                "-fx-border-color: #3498db;" +
                "-fx-border-width: 2px;" +
                "-fx-border-radius: 5px;" +
                "-fx-background-radius: 5px;"
            );
        }
        
        // Add hover effects
        addHoverEffects(card, isFCFS);
        
        return card;
    }
    
    /**
     * Add hover effects to station cards
     */
    private void addHoverEffects(VBox card, boolean isFCFS) {
        card.setOnMouseEntered(e -> {
            if (isFCFS) {
                card.setStyle(
                    "-fx-background-color: rgba(243, 156, 18, 0.8);" +
                    "-fx-border-color: #f39c12;" +
                    "-fx-border-width: 3px;" +
                    "-fx-border-radius: 5px;" +
                    "-fx-background-radius: 5px;"
                );
            } else {
                card.setStyle(
                    "-fx-background-color: rgba(52, 152, 219, 0.8);" +
                    "-fx-border-color: #3498db;" +
                    "-fx-border-width: 3px;" +
                    "-fx-border-radius: 5px;" +
                    "-fx-background-radius: 5px;"
                );
            }
        });
        
        card.setOnMouseExited(e -> {
            if (isFCFS) {
                card.setStyle(
                    "-fx-background-color: rgba(243, 156, 18, 0.5);" +
                    "-fx-border-color: #f39c12;" +
                    "-fx-border-width: 2px;" +
                    "-fx-border-radius: 5px;" +
                    "-fx-background-radius: 5px;"
                );
            } else {
                card.setStyle(
                    "-fx-background-color: rgba(52, 152, 219, 0.5);" +
                    "-fx-border-color: #3498db;" +
                    "-fx-border-width: 2px;" +
                    "-fx-border-radius: 5px;" +
                    "-fx-background-radius: 5px;"
                );
            }
        });
    }
    
    /**
     * Create queue display container
     */
    public VBox createQueueContainer() {
        VBox queueContainer = new VBox(3);
        Label queueTitle = new Label("EV queue when station is full");
        queueTitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 12));
        queueTitle.setTextFill(Color.ORANGE);
        
        // Create queue display area
        HBox queueDisplay = new HBox(5);
        queueDisplay.setStyle("-fx-background-color: #34495e; -fx-border-color: #e67e22; -fx-border-width: 1; -fx-padding: 5;");
        queueDisplay.setPrefHeight(60);
        queueDisplay.setAlignment(Pos.CENTER_LEFT);
        
        Label queueStatus = new Label("Empty");
        queueStatus.setFont(Font.font("Segoe UI", 10));
        queueStatus.setTextFill(Color.LIGHTGRAY);
        queueDisplay.getChildren().add(queueStatus);
        queueContainer.getChildren().addAll(queueTitle, queueDisplay);
        queueContainer.setUserData("queueContainer");
        
        return queueContainer;
    }
    
    /**
     * Update station status based on received data
     */
    public void updateStationStatus(JsonObject stations) {
        if (stationGrid == null) return;

        try {
            // Debug: Log received station keys
            System.out.println("Received station keys: " + stations.keySet().toString());

            // Find all station cards in the grid and update them
            updateStationCards(stationGrid, stations);
        } catch (Exception e) {
            System.err.println("Error updating station status: " + e.getMessage());
        }
    }
    
    /**
     * Recursively find and update station cards
     */
    private void updateStationCards(javafx.scene.Parent parent, JsonObject stations) {
        for (javafx.scene.Node node : parent.getChildrenUnmodifiable()) {
            if (node instanceof VBox && node.getUserData() instanceof String) {
                String stationId = (String) node.getUserData();
                if (stationId.contains("Station_")) {
                    System.out.println("Found station card with ID: " + stationId);
                    updateStationCard((VBox) node, stationId, stations);
                }
            } else if (node instanceof javafx.scene.Parent) {
                updateStationCards((javafx.scene.Parent) node, stations);
            }
        }
    }
    
    /**
     * Update individual station card
     */
    private void updateStationCard(VBox card, String stationId, JsonObject stations) {
        try {
            if (stations.has(stationId)) {
                JsonObject stationData = stations.getAsJsonObject(stationId);
                System.out.println("Updating station " + stationId + " with data: " + stationData.toString());

                // Update labels in the card
                for (javafx.scene.Node child : card.getChildren()) {
                    if (child instanceof Label) {
                        Label label = (Label) child;
                        // Update based on label position and content
                        updateStationLabel(label, stationData, card.getChildren().indexOf(child));
                    }
                }

                // Update card background color based on status
                if (stationData.has("status")) {
                    String status = stationData.get("status").getAsString();
                    updateCardBackgroundColor(card, status, stationId.startsWith("FCFS"));
                }
            } else {
                System.out.println("No data found for station: " + stationId);
                // Reset to default appearance when no data
                resetCardToDefault(card, stationId.startsWith("FCFS"));
            }
        } catch (Exception e) {
            System.err.println("Error updating station card " + stationId + ": " + e.getMessage());
        }
    }

    /**
     * Update card background color based on status
     */
    private void updateCardBackgroundColor(VBox card, String status, boolean isFCFS) {
        String baseColor, borderColor;
        double opacity;

        // Determine colors based on status
        switch (status.toUpperCase()) {
            case "CHARGING":
                baseColor = isFCFS ? "rgba(52, 152, 219, 0.8)" : "rgba(52, 152, 219, 0.8)"; // Green/Blue
                borderColor = isFCFS ? "#3498db" : "#3498db";
                opacity = 0.9;
                break;
            case "OCCUPIED":
                baseColor = isFCFS ? "rgba(241, 196, 15, 0.8)" : "rgba(241, 196, 15, 0.8)"; // Yellow/Purple
                borderColor = isFCFS ? "#f1c40f" : "#f1c40f";
                opacity = 0.8;
                break;
            case "FULLY_CHARGED_WAITING":
                baseColor = isFCFS ? "rgba(46, 204, 113, 0.8)" : "rgba(46, 204, 113, 0.8)"; // Turquoise
                borderColor = isFCFS ? "#1abc9c" : "#1abc9c";
                opacity = 0.8;
                break;
            case "COMPLETED":
                baseColor = isFCFS ? "rgba(46, 204, 113, 0.8)" : "rgba(46, 204, 113, 0.8)"; // Turquoise
                borderColor = isFCFS ? "#1abc9c" : "#1abc9c";
                opacity = 0.8;
                break;
            case "AVAILABLE":
            default:
                baseColor = isFCFS ? "rgba(52, 152, 219, 0.5)" : "rgba(52, 152, 219, 0.5)"; // Default
                borderColor = isFCFS ? "#3498db" : "#3498db";
                opacity = 0.5;
                break;
        }

        card.setStyle(
            "-fx-background-color: " + baseColor + ";" +
            "-fx-border-color: " + borderColor + ";" +
            "-fx-border-width: 2px;" +
            "-fx-border-radius: 5px;" +
            "-fx-background-radius: 5px;" +
            "-fx-opacity: " + opacity + ";"
        );
    }

    /**
     * Reset card to default appearance
     */
    private void resetCardToDefault(VBox card, boolean isFCFS) {
        if (isFCFS) {
            card.setStyle(
                "-fx-background-color: rgba(243, 156, 18, 0.5);" +
                "-fx-border-color: #f39c12;" +
                "-fx-border-width: 2px;" +
                "-fx-border-radius: 5px;" +
                "-fx-background-radius: 5px;"
            );
        } else {
            card.setStyle(
                "-fx-background-color: rgba(52, 152, 219, 0.5);" +
                "-fx-border-color: #3498db;" +
                "-fx-border-width: 2px;" +
                "-fx-border-radius: 5px;" +
                "-fx-background-radius: 5px;"
            );
        }
    }
    
    /**
     * Update station label based on its position in the card
     */
    private void updateStationLabel(Label label, JsonObject stationData, int position) {
        try {
            switch (position) {
                case 1: // Status label
                    if (stationData.has("status")) {
                        String status = stationData.get("status").getAsString();
                        label.setText(status);

                        // Update label color based on status
                        updateStatusLabelColor(label, status);
                    }
                    break;
                case 2: // Power label
                    if (stationData.has("current_power")) {
                        double power = stationData.get("current_power").getAsDouble();
                        label.setText(String.format("%.1f kW", power));

                        // Update power label color based on power level
                        if (power > 0.1) {
                            label.setTextFill(Color.LIGHTGREEN); // Active charging
                        } else {
                            label.setTextFill(Color.WHITE); // No power
                        }
                    }
                    break;
                case 3: // Progress label
                    if (stationData.has("energy_progress")) {
                        double progress = stationData.get("energy_progress").getAsDouble();
                        label.setText(String.format("%.1f%%", progress));

                        // Update progress label color based on completion
                        if (progress >= 99.0) {
                            label.setTextFill(Color.LIGHTGREEN); // Completed
                        } else if (progress > 0) {
                            label.setTextFill(Color.YELLOW); // In progress
                        } else {
                            label.setTextFill(Color.web("#95a5a6")); // Not started
                        }
                    }
                    break;
                case 4: // EV info label
                    // Create EV info from available data
                    String evInfo = "";
                    if (stationData.has("assigned_session") && !stationData.get("assigned_session").isJsonNull()) {
                        String sessionId = stationData.get("assigned_session").getAsString();
                        evInfo = sessionId;

                        // Add energy info if available
                        if (stationData.has("energy_delivered") && stationData.has("energy_needed")) {
                            double delivered = stationData.get("energy_delivered").getAsDouble();
                            double needed = stationData.get("energy_needed").getAsDouble();
                            evInfo += String.format("\n%.1f/%.1f kWh", delivered, needed);
                        }

                        label.setTextFill(Color.WHITE);
                    } else {
                        label.setTextFill(Color.web("#95a5a6"));
                    }
                    label.setText(evInfo);
                    break;
            }
        } catch (Exception e) {
            System.err.println("Error updating station label: " + e.getMessage());
        }
    }

    /**
     * Update status label color based on station status
     */
    private void updateStatusLabelColor(Label statusLabel, String status) {
        switch (status.toUpperCase()) {
            case "CHARGING":
                statusLabel.setTextFill(Color.LIGHTGREEN);
                break;
            case "AVAILABLE":
                statusLabel.setTextFill(Color.web("#95a5a6"));
                break;
            case "OCCUPIED":
                statusLabel.setTextFill(Color.ORANGE);
                break;
            case "FULLY_CHARGED_WAITING":
            case "COMPLETED":
                statusLabel.setTextFill(Color.CYAN);
                break;
            case "WAITING":
                statusLabel.setTextFill(Color.YELLOW);
                break;
            default:
                statusLabel.setTextFill(Color.WHITE);
                break;
        }
    }
    
    /**
     * Get the station grid
     */
    public GridPane getStationGrid() {
        return stationGrid;
    }
}
