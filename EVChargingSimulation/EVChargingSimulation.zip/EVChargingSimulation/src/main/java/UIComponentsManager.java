import java.util.ArrayList;
import java.util.List;

import javafx.beans.property.SimpleStringProperty;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

/**
 * UIComponentsManager handles creation and management of UI components
 * Manages tables, statistics panels, control panels, and log areas
 */
public class UIComponentsManager {
    
    // UI Components
    private Label timeLabel;
    private Label speedLabel;
    private TableView<EVSession> evTable;
    private HBox activeEVsLabel;
    private HBox completedLabel;
    private HBox chargingLabel;
    private HBox totalEnergyLabel;
    private HBox avgPowerLabel;
    private HBox totalPowerLabel;
    private HBox currentPriceLabel;
    private TextArea logArea;
    
    // Data
    private List<EVSession> evSessions = new ArrayList<>();
    
    // Callback interface for handling UI events
    public interface UIEventCallback {
        void onAddEV();
        void onReloadEVs();
    }
    
    private UIEventCallback eventCallback;
    
    public UIComponentsManager(UIEventCallback callback) {
        this.eventCallback = callback;
    }
    
    /**
     * Create the header section
     */
    public VBox createHeader() {
        VBox header = new VBox(5);
        header.setStyle("-fx-background-color: #34495e;");
        header.setPadding(new Insets(10));
        header.setAlignment(Pos.CENTER);
        
        Label title = new Label("🔋 EV Charging Station Monitor");
        title.setFont(Font.font("Segoe UI", FontWeight.BOLD, 20));
        title.setTextFill(Color.WHITE);
        
        header.getChildren().add(title);
        return header;
    }
    
    /**
     * Create the control panel
     */
    public VBox createControlPanel() {
        VBox controlPanel = new VBox(10);
        controlPanel.setStyle("-fx-background-color: #34495e; -fx-background-radius: 5; -fx-effect: dropshadow(gaussian, rgba(52, 152, 219, 0.5), 12, 0.3, 0, 0);");
        controlPanel.setPadding(new Insets(15));
        controlPanel.setAlignment(Pos.TOP_CENTER);
        
        Label controlTitle = new Label("⚙️ Simulation Control");
        controlTitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 14));
        controlTitle.setTextFill(Color.WHITE);
        
        // Simulation status section
        VBox simStatusSection = new VBox(8);
        simStatusSection.setAlignment(Pos.CENTER);
        
        timeLabel = new Label("Simulation Time: --:--:--");
        timeLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 14));
        timeLabel.setTextFill(Color.LIGHTBLUE);
        timeLabel.setAlignment(Pos.CENTER);
        
        speedLabel = new Label("Speed: --x");
        speedLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 12));
        speedLabel.setTextFill(Color.ORANGE);
        speedLabel.setAlignment(Pos.CENTER);
        
        simStatusSection.getChildren().addAll(timeLabel, speedLabel);
        
        // Control buttons section
        VBox buttonSection = new VBox(10);
        buttonSection.setAlignment(Pos.CENTER);
        
        // Button addEVButton = new Button("🚗 Add EV");
        // addEVButton.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 10 20; -fx-background-radius: 5;");
        // addEVButton.setFont(Font.font("Segoe UI", FontWeight.BOLD, 12));
        // addEVButton.setPrefWidth(200);
        // addEVButton.setOnAction(e -> {
        //     if (eventCallback != null) {
        //         eventCallback.onAddEV();
        //     }
        // });
        
        // Button reloadEVButton = new Button("🔄 Reload EVs");
        // reloadEVButton.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; -fx-font-weight: bold; -fx-padding: 10 20; -fx-background-radius: 5;");
        // reloadEVButton.setFont(Font.font("Segoe UI", FontWeight.BOLD, 12));
        // reloadEVButton.setPrefWidth(200);
        // reloadEVButton.setOnAction(e -> {
        //     if (eventCallback != null) {
        //         eventCallback.onReloadEVs();
        //     }
        // });
        
        // buttonSection.getChildren().addAll(addEVButton, reloadEVButton);
        
        // controlPanel.getChildren().addAll(controlTitle, simStatusSection, buttonSection);
        controlPanel.getChildren().addAll(controlTitle, simStatusSection);
        return controlPanel;
    }
    
    /**
     * Create the EV table
     */
    public TableView<EVSession> createEVTable() {
        TableView<EVSession> table = new TableView<>();
        table.setPrefHeight(220);
        table.setPrefWidth(1200);
        table.setMaxWidth(Double.MAX_VALUE);
        
        // Enable auto-resize columns to fit content
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        
        // Enhanced styling for better appearance
        table.setStyle(
            "-fx-background-color: linear-gradient(to bottom, #2c3e50, #34495e);" +
            "-fx-text-fill: white;" +
            "-fx-control-inner-background: linear-gradient(to bottom, #34495e, #2c3e50);" +
            "-fx-control-inner-background-alt: linear-gradient(to bottom, #3c5a78, #34495e);" +
            "-fx-table-cell-border-color: #4a6741;" +
            "-fx-table-header-border-color: #5dade2;" +
            "-fx-selection-bar: linear-gradient(to bottom, #3498db, #2980b9);" +
            "-fx-selection-bar-non-focused: linear-gradient(to bottom, #85c1e9, #5dade2);" +
            "-fx-font-size: 11px;" +
            "-fx-font-weight: bold;" +
            "-fx-background-radius: 8px;" +
            "-fx-effect: dropshadow(gaussian, rgba(52, 152, 219, 0.4), 15, 0.3, 0, 0);"
        );
    
        table.setId("enhanced-dark-table");
        
        // Create columns with flexible widths that auto-resize
        TableColumn<EVSession, String> idCol = new TableColumn<>("ID");
        idCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        idCol.setMinWidth(80);
        idCol.setPrefWidth(120);
        
        TableColumn<EVSession, String> arrivalCol = new TableColumn<>("Arrival");
        arrivalCol.setCellValueFactory(new PropertyValueFactory<>("arrivalTime"));
        arrivalCol.setMinWidth(60);
        arrivalCol.setPrefWidth(80);
        
        TableColumn<EVSession, String> departureCol = new TableColumn<>("Departure");
        departureCol.setCellValueFactory(new PropertyValueFactory<>("departureTime"));
        departureCol.setMinWidth(60);
        departureCol.setPrefWidth(80);
        
        TableColumn<EVSession, Double> neededCol = new TableColumn<>("Needed");
        neededCol.setCellValueFactory(new PropertyValueFactory<>("energyNeeded"));
        neededCol.setMinWidth(60);
        neededCol.setPrefWidth(80);
        
        // FCFS Delivered + Progress column with auto-resize
        TableColumn<EVSession, String> fcfsDeliveredCol = new TableColumn<>("Energy Delivered (FCFS)");
        fcfsDeliveredCol.setCellValueFactory(cellData -> {
            EVSession session = cellData.getValue();
            double delivered = session.getFcfsEnergyDelivered();
            double progress = session.getFcfsProgressPercent();
            String text = String.format("%.1f kWh / %.1f%%", delivered, progress);
            return new SimpleStringProperty(text);
        });
        fcfsDeliveredCol.setMinWidth(150);
        fcfsDeliveredCol.setPrefWidth(180);
        
        // Optimization Delivered + Progress column with auto-resize
        TableColumn<EVSession, String> optDeliveredCol = new TableColumn<>("Energy Delivered (OPT)");
        optDeliveredCol.setCellValueFactory(cellData -> {
            EVSession session = cellData.getValue();
            double delivered = session.getEnergyDelivered();
            double progress = session.getProgressPercent();
            String text = String.format("%.1f kWh / %.1f%%", delivered, progress);
            return new SimpleStringProperty(text);
        });
        optDeliveredCol.setMinWidth(150);
        optDeliveredCol.setPrefWidth(180);
        
        TableColumn<EVSession, Double> powerCol = new TableColumn<>("Power");
        powerCol.setCellValueFactory(new PropertyValueFactory<>("currentPower"));
        powerCol.setMinWidth(50);
        powerCol.setPrefWidth(70);
        
        TableColumn<EVSession, String> stationCol = new TableColumn<>("Station");
        stationCol.setCellValueFactory(new PropertyValueFactory<>("stationId"));
        stationCol.setMinWidth(80);
        stationCol.setPrefWidth(120);
        
        TableColumn<EVSession, String> statusCol = new TableColumn<>("Status");
        statusCol.setCellValueFactory(new PropertyValueFactory<>("status"));
        statusCol.setMinWidth(80);
        statusCol.setPrefWidth(100);
        
        // Add all columns with auto-resize functionality
        table.getColumns().addAll(idCol, arrivalCol, departureCol, neededCol, 
                                 fcfsDeliveredCol, optDeliveredCol, powerCol, stationCol, statusCol);
        
        // Set all columns to be resizable
        for (TableColumn<EVSession, ?> column : table.getColumns()) {
            column.setResizable(true);
            column.setSortable(true);
        }
        
        // Apply enhanced CSS to column headers
        for (TableColumn<EVSession, ?> column : table.getColumns()) {
            column.setStyle(
                "-fx-text-fill: white;" +
                "-fx-font-weight: bold;" +
                "-fx-font-size: 12px;" +
                "-fx-background-color: linear-gradient(to bottom, #3498db, #2980b9);" +
                "-fx-border-color: #5dade2;" +
                "-fx-border-width: 1px;" +
                "-fx-alignment: center;" +
                "-fx-effect: dropshadow(three-pass-box, rgba(52, 152, 219, 0.3), 3, 0, 0, 1);"
            );
        }
        
        this.evTable = table;
        return table;
    }
    
    /**
     * Create the statistics panel
     */
    public VBox createStatisticsPanel() {
        VBox statsPanel = new VBox(5);
        statsPanel.setStyle("-fx-background-color: #34495e; -fx-background-radius: 5; -fx-effect: dropshadow(gaussian, rgba(52, 152, 219, 0.5), 12, 0.3, 0, 0);");
        statsPanel.setPadding(new Insets(10));
        
        Label statsTitle = new Label("📊 Real-time Statistics");
        statsTitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 12));
        statsTitle.setTextFill(Color.WHITE);
        
        // Create statistics labels
        activeEVsLabel = createStatLabel("Active EVs:", "0");
        completedLabel = createStatLabel("Completed:", "0");
        chargingLabel = createStatLabel("Currently Charging:", "0");
        totalEnergyLabel = createStatLabel("Total Energy:", "0.0 kWh");
        avgPowerLabel = createStatLabel("Avg Power:", "0.0 kW");
        totalPowerLabel = createStatLabel("Total Power:", "0.0 kW");
        currentPriceLabel = createStatLabel("Current Price:", "0.0 €/MWh");
        
        statsPanel.getChildren().addAll(statsTitle, activeEVsLabel, completedLabel, 
                                       chargingLabel, totalEnergyLabel, avgPowerLabel, 
                                       totalPowerLabel, currentPriceLabel);
        return statsPanel;
    }
    
    /**
     * Create a statistics label
     */
    private HBox createStatLabel(String labelText, String initialValue) {
        HBox statBox = new HBox();
        statBox.setAlignment(Pos.CENTER_LEFT);
        
        Label label = new Label(labelText);
        label.setTextFill(Color.LIGHTGRAY);
        label.setPrefWidth(120);
        
        Label value = new Label(initialValue);
        value.setTextFill(Color.LIGHTBLUE);
        value.setFont(Font.font("Segoe UI", FontWeight.BOLD, 11));
        
        statBox.getChildren().addAll(label, value);
        return statBox;
    }
    
    /**
     * Create the log area
     */
    public TextArea createLogArea() {
        logArea = new TextArea();
        logArea.setEditable(false);
        logArea.setPrefHeight(160);
        logArea.setPrefWidth(780);
        logArea.setWrapText(true);
        logArea.setStyle(
            "-fx-control-inner-background: linear-gradient(to bottom, #2c3e50, #34495e);" +
            "-fx-text-fill: black;" +
            "-fx-font-family: 'Consolas', 'Courier New', monospace;" +
            "-fx-font-size: 11px;" +
            "-fx-border-color: #3498db;" +
            "-fx-border-width: 1px;" +
            "-fx-border-radius: 5px;" +
            "-fx-background-radius: 5px;" +
            "-fx-effect: dropshadow(three-pass-box, rgba(52, 152, 219, 0.2), 5, 0, 0, 1);"
        );
        
        return logArea;
    }
    
    // Getters for UI components
    public Label getTimeLabel() { return timeLabel; }
    public Label getSpeedLabel() { return speedLabel; }
    public TableView<EVSession> getEvTable() { return evTable; }
    public HBox getActiveEVsLabel() { return activeEVsLabel; }
    public HBox getCompletedLabel() { return completedLabel; }
    public HBox getChargingLabel() { return chargingLabel; }
    public HBox getTotalEnergyLabel() { return totalEnergyLabel; }
    public HBox getAvgPowerLabel() { return avgPowerLabel; }
    public HBox getTotalPowerLabel() { return totalPowerLabel; }
    public HBox getCurrentPriceLabel() { return currentPriceLabel; }
    public TextArea getLogArea() { return logArea; }
    public List<EVSession> getEvSessions() { return evSessions; }
}
