import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

/**
 * Main JavaFX Application for EV Charging Station Monitor
 * This class coordinates all UI components and manages the overall application lifecycle
 */
public class EVChargingMonitorFX extends Application implements
    NetworkManager.DataCallback,
    UIComponentsManager.UIEventCallback,
    ChartManager.LogCallback {
    
    // Component managers
    private NetworkManager networkManager;
    private UIComponentsManager uiManager;
    private StationGridManager stationManager;
    private ChartManager chartManager;
    
    // Data
    private List<EVSession> evSessions = new ArrayList<>();
    private int timeCounter = 0;
    
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("EV Charging Station Monitor - JavaFX");
        
        // Initialize component managers
        networkManager = new NetworkManager(this);
        uiManager = new UIComponentsManager(this);
        stationManager = new StationGridManager();
        chartManager = new ChartManager();
        chartManager.setLogCallback(this);
        
        // Create main layout
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: #2c3e50;");
        
        // Header
        VBox header = uiManager.createHeader();
        root.setTop(header);
        
        // Main content with ScrollPane
        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setFitToWidth(true);
        scrollPane.setFitToHeight(false);
        scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        scrollPane.setStyle("-fx-background-color: transparent;");
        
        BorderPane scrollContent = new BorderPane();
        scrollContent.setPadding(new Insets(10));
        scrollContent.setPrefHeight(900);
        
        // Top section - Statistics, EV table and control panel 
        HBox topSection = new HBox(10);
        
        // Left side - Statistics panel 
        VBox statsPanel = uiManager.createStatisticsPanel();
        statsPanel.setPrefWidth(300);
        
        // Middle - EV Table 
        VBox evTableContainer = new VBox(5);
        Label tableTitle = new Label("🚗 Active Electric Vehicles");
        tableTitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 14));
        tableTitle.setTextFill(Color.WHITE);
        TableView<EVSession> evTable = uiManager.createEVTable();
        
        evTableContainer.getChildren().addAll(tableTitle, evTable);
        evTableContainer.setPrefWidth(700);
        evTableContainer.setMaxWidth(Double.MAX_VALUE); 
        
        // Right side - Control panel
        VBox controlPanel = uiManager.createControlPanel();
        controlPanel.setPrefWidth(400);
        
        topSection.getChildren().addAll(statsPanel, evTableContainer, controlPanel);
        scrollContent.setTop(topSection);
        
        // Bottom section
        BorderPane bottomSection = new BorderPane();
        bottomSection.setPadding(new Insets(10, 0, 0, 0));
        
        HBox mainBottomLayout = new HBox(5);
        
        // Left side - Station grids
        VBox stationContainer = new VBox(5);
        Label stationTitle = new Label("🔌 Charging Stations");
        stationTitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 14));
        stationTitle.setTextFill(Color.WHITE);
        
        stationContainer.getChildren().addAll(stationTitle, stationManager.createStationGrid(), stationManager.createQueueContainer());
        stationContainer.setPrefWidth(600);
        stationContainer.setMaxWidth(600);
        
        // Right side - Activity Log and Chart area
        VBox rightPanel = new VBox(6);
        rightPanel.setPrefWidth(800);
        
        // Activity Log area
        VBox logContainer = new VBox(5);
        Label logTitle = new Label("📝 Activity Log");
        logTitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 14));
        logTitle.setTextFill(Color.BLACK);
        TextArea logArea = uiManager.createLogArea();
        logContainer.getChildren().addAll(logTitle, logArea);
        
        // Chart area
        VBox chartContainer = new VBox(5);
        Label chartTitle = new Label("📊 Total Electricity Cost Comparison");
        chartTitle.setFont(Font.font("Segoe UI", FontWeight.BOLD, 14));
        chartTitle.setTextFill(Color.BLACK);
        
        HBox chartControls = chartManager.createChartNavigationControls();
        LineChart<Number, Number> costChart = chartManager.createCostComparisonChart();
        costChart.setPrefHeight(350);
        costChart.setPrefWidth(780);
        chartContainer.getChildren().addAll(chartTitle, chartControls, costChart);
        
        // Add log and chart to right panel
        rightPanel.getChildren().addAll(logContainer, chartContainer);
        VBox.setVgrow(logContainer, javafx.scene.layout.Priority.SOMETIMES);
        VBox.setVgrow(chartContainer, javafx.scene.layout.Priority.ALWAYS);
        
        // Add both panels to main bottom layout
        mainBottomLayout.getChildren().addAll(stationContainer, rightPanel);
        HBox.setHgrow(stationContainer, javafx.scene.layout.Priority.NEVER);
        HBox.setHgrow(rightPanel, javafx.scene.layout.Priority.ALWAYS);
        
        bottomSection.setCenter(mainBottomLayout);
        scrollContent.setCenter(bottomSection);
        
        // Set scroll content into ScrollPane and ScrollPane into root
        scrollPane.setContent(scrollContent);
        root.setCenter(scrollPane);
        
        // Set up scene
        Scene scene = new Scene(root, 1600, 800);
        
        // Load CSS stylesheet for enhanced appearance
        try {
            String cssPath = getClass().getResource("/styles.css").toExternalForm();
            scene.getStylesheets().add(cssPath);
        } catch (Exception e) {
            System.out.println("Warning: Could not load CSS stylesheet: " + e.getMessage());
        }
        
        primaryStage.setScene(scene);
        primaryStage.show();
        
        // Connect to both backend services
        networkManager.connectToBackend();  // Optimization data (port 8765)
        networkManager.connectToFCFS();     // FCFS data (port 8766)

        // Handle close
        primaryStage.setOnCloseRequest(e -> {
            networkManager.closeConnection();
            Platform.exit();
        });
    }
    
    // NetworkManager.DataCallback implementation
    @Override
    public void onDataReceived(JsonObject data) {
        updateUI(data);
    }

    @Override
    public void onFCFSDataReceived(JsonObject data) {
        updateFCFSUI(data);
    }

    @Override
    public void onConnectionStatusChanged(boolean connected) {
        String status = connected ? "Connected" : "Disconnected";
        logMessage("Connection status: " + status);
    }

    @Override
    public void onLogMessage(String message) {
        logMessage(message);
    }
    
    // UIComponentsManager.UIEventCallback implementation
    @Override
    public void onAddEV() {
        handleAddEV();
    }
    
    @Override
    public void onReloadEVs() {
        handleReloadEVs();
    }
    
    // ChartManager.LogCallback implementation
    @Override
    public void logMessage(String message) {
        Platform.runLater(() -> {
            TextArea logArea = uiManager.getLogArea();
            if (logArea != null) {
                logArea.appendText(message + "\n");
                logArea.setScrollTop(Double.MAX_VALUE);
            }
        });
        System.out.println(message);
    }
    
    /**
     * Update UI with received optimization data
     */
    private void updateUI(JsonObject data) {
        try {
            // Debug: Log the keys in the received data
            logMessage("Received OPT data keys: " + data.keySet().toString());
            // Update time and speed
            if (data.has("simulation_time")) {
                String simTime = data.get("simulation_time").getAsString();
                Platform.runLater(() -> uiManager.getTimeLabel().setText("Simulation Time: " + simTime));
            }
            
            if (data.has("speed_multiplier")) {
                double speed = data.get("speed_multiplier").getAsDouble();
                Platform.runLater(() -> uiManager.getSpeedLabel().setText(String.format("Speed: %.0fx", speed)));
            }
            
            // Update statistics
            if (data.has("statistics")) {
                JsonObject stats = data.getAsJsonObject("statistics");
                Platform.runLater(() -> updateStatistics(stats));
            }
            
            // Update EV table
            if (data.has("evs")) {
                JsonArray evs = data.getAsJsonArray("evs");
                logMessage("Received EV data: " + evs.size() + " EVs");
                Platform.runLater(() -> updateEVTable(evs));
            } else {
                logMessage("No 'evs' field in received data");
            }
            
            // Update station status
            if (data.has("stations")) {
                JsonObject stations = data.getAsJsonObject("stations");
                Platform.runLater(() -> stationManager.updateStationStatus(stations));
            }
            
            // Update current price and costs
            if (data.has("current_price")) {
                double currentPrice = data.get("current_price").getAsDouble();
                Platform.runLater(() -> updateStatValue(uiManager.getCurrentPriceLabel(), String.format("%.1f €/MWh", currentPrice)));
                
                // Get actual total costs from backend
                final double actualOptCost = data.has("opt_total_cost") ? data.get("opt_total_cost").getAsDouble() : 0.0;
                final double actualFcfsCost = data.has("fcfs_total_cost") ? data.get("fcfs_total_cost").getAsDouble() : 0.0;
                
                // Update the cost chart with actual cost data from backend
                Platform.runLater(() -> chartManager.updateCostChart(actualOptCost, actualFcfsCost));
            }
            
        } catch (Exception e) {
            logMessage("Error updating UI: " + e.getMessage());
        }
    }

    /**
     * Update UI with received FCFS data
     */
    private void updateFCFSUI(JsonObject data) {
        try {
            // Debug: Log the keys in the received FCFS data
            logMessage("Received FCFS data keys: " + data.keySet().toString());

            // Update FCFS station status only
            if (data.has("stations")) {
                JsonObject stations = data.getAsJsonObject("stations");
                Platform.runLater(() -> {
                    // Filter and update only FCFS stations
                    JsonObject fcfsStations = new JsonObject();
                    for (String key : stations.keySet()) {
                        if (key.startsWith("FCFS_")) {
                            fcfsStations.add(key, stations.get(key));
                        }
                    }
                    stationManager.updateStationStatus(fcfsStations);
                });
            }

            // Note: We don't update the EV table or statistics with FCFS data
            // as the main table shows optimization results

        } catch (Exception e) {
            logMessage("Error updating FCFS UI: " + e.getMessage());
        }
    }

    /**
     * Update statistics display
     */
    private void updateStatistics(JsonObject allStats) {
        try {
            if (allStats.has("optimization")) {
                JsonObject optStats = allStats.getAsJsonObject("optimization");
                
                if (optStats.has("active_evs")) 
                    updateStatValue(uiManager.getActiveEVsLabel(), String.valueOf(optStats.get("active_evs").getAsInt()));
                
                if (optStats.has("completed_sessions"))
                    updateStatValue(uiManager.getCompletedLabel(), String.valueOf(optStats.get("completed_sessions").getAsInt()));
                
                if (optStats.has("currently_charging"))
                    updateStatValue(uiManager.getChargingLabel(), String.valueOf(optStats.get("currently_charging").getAsInt()));
                
                if (optStats.has("total_energy_delivered"))
                    updateStatValue(uiManager.getTotalEnergyLabel(), String.format("%.1f kWh", optStats.get("total_energy_delivered").getAsDouble()));
                
                if (optStats.has("average_power"))
                    updateStatValue(uiManager.getAvgPowerLabel(), String.format("%.1f kW", optStats.get("average_power").getAsDouble()));
                
                if (optStats.has("total_power"))
                    updateStatValue(uiManager.getTotalPowerLabel(), String.format("%.1f kW", optStats.get("total_power").getAsDouble()));
            }
        } catch (Exception e) {
            logMessage("Error updating statistics: " + e.getMessage());
        }
    }
    
    /**
     * Update EV table
     */
    private void updateEVTable(JsonArray evs) {
        try {
            // Get the table from UI manager
            TableView<EVSession> evTable = uiManager.getEvTable();
            if (evTable == null) {
                logMessage("EV Table is null - cannot update");
                return;
            }

            // Clear existing data
            evTable.getItems().clear();

            // Parse JSON data and create EVSession objects
            for (int i = 0; i < evs.size(); i++) {
                JsonObject evData = evs.get(i).getAsJsonObject();

                // Debug: Log the first EV's data structure
                if (i == 0) {
                    logMessage("First EV data keys: " + evData.keySet().toString());
                }

                // Extract data from JSON with safe defaults
                String id = evData.has("id") ? evData.get("id").getAsString() : "Unknown";
                String arrivalTime = evData.has("arrival_time") ? evData.get("arrival_time").getAsString() : "--:--";
                String departureTime = evData.has("departure_time") ? evData.get("departure_time").getAsString() : "--:--";
                double energyNeeded = evData.has("energy_needed") ? evData.get("energy_needed").getAsDouble() : 0.0;
                double energyDelivered = evData.has("energy_delivered") ? evData.get("energy_delivered").getAsDouble() : 0.0;

                // Use progress from backend if available, otherwise calculate
                double progressPercent = evData.has("progress_percent") ?
                    evData.get("progress_percent").getAsDouble() :
                    (energyNeeded > 0 ? (energyDelivered / energyNeeded) * 100 : 0.0);

                // FCFS data - use backend values if available
                double fcfsEnergyDelivered = evData.has("fcfs_energy_delivered") ? evData.get("fcfs_energy_delivered").getAsDouble() : 0.0;
                double fcfsProgressPercent = evData.has("fcfs_progress_percent") ?
                    evData.get("fcfs_progress_percent").getAsDouble() :
                    (energyNeeded > 0 ? (fcfsEnergyDelivered / energyNeeded) * 100 : 0.0);

                double currentPower = evData.has("current_power") ? evData.get("current_power").getAsDouble() : 0.0;
                String stationId = evData.has("station_id") ? evData.get("station_id").getAsString() : "None";
                String status = evData.has("status") ? evData.get("status").getAsString() : "Unknown";

                // Create EVSession object
                EVSession session = new EVSession(
                    id, arrivalTime, departureTime, energyNeeded,
                    energyDelivered, progressPercent,
                    fcfsEnergyDelivered, fcfsProgressPercent,
                    currentPower, stationId, status
                );

                // Add to table
                evTable.getItems().add(session);
            }

            logMessage("Updated EV table with " + evs.size() + " entries");

        } catch (Exception e) {
            logMessage("Error updating EV table: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Update a statistic value
     */
    private void updateStatValue(HBox statBox, String newValue) {
        if (statBox != null && statBox.getChildren().size() > 1) {
            Label valueLabel = (Label) statBox.getChildren().get(1);
            valueLabel.setText(newValue);
        }
    }
    
    /**
     * Handle Add EV button click
     */
    private void handleAddEV() {
        logMessage("Add EV button clicked");
        // Implementation for adding EV
    }
    
    /**
     * Handle Reload EVs button click
     */
    private void handleReloadEVs() {
        logMessage("Reload EVs button clicked");
        // Implementation for reloading EVs
    }
    
    public static void main(String[] args) {
        launch(args);
    }
}
