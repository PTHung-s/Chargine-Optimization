import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class AddEVDialog {
    
    private Stage dialogStage;
    private boolean confirmed = false;
    private EVData result = null;
      // Input fields
    private DatePicker arrivalDatePicker;
    private TextField arrivalTimeField;
    private DatePicker departureDatePicker;
    private TextField departureTimeField;
    private TextField energyField;
    private TextArea statusArea;
      public static class EVData {
        public String arrivalDate;
        public String arrivalTime;
        public String departureDate;
        public String departureTime;
        public double energy;
        
        public EVData(String arrivalDate, String arrivalTime, String departureDate, String departureTime, double energy) {
            this.arrivalDate = arrivalDate;
            this.arrivalTime = arrivalTime;
            this.departureDate = departureDate;
            this.departureTime = departureTime;
            this.energy = energy;
        }
    }
    
    public AddEVDialog(Stage parentStage) {
        createDialog(parentStage);
    }
    
    private void createDialog(Stage parentStage) {
        dialogStage = new Stage();
        dialogStage.initModality(Modality.APPLICATION_MODAL);
        dialogStage.initOwner(parentStage);
        dialogStage.setTitle("🚗 Add New EV to Simulation");
        dialogStage.setResizable(false);
        
        // Main container
        VBox mainContainer = new VBox(15);
        mainContainer.setPadding(new Insets(20));
        mainContainer.setStyle("-fx-background-color: #2c3e50;");
        
        // Title
        Label titleLabel = new Label("🚗 Add New Electric Vehicle");
        titleLabel.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        titleLabel.setTextFill(Color.WHITE);
        titleLabel.setAlignment(Pos.CENTER);
        
        // Input form
        GridPane formGrid = createInputForm();
        
        // Status area
        statusArea = new TextArea();
        statusArea.setEditable(false);
        statusArea.setPrefHeight(80);
        statusArea.setStyle("-fx-control-inner-background: #34495e; -fx-text-fill: white;");
        statusArea.setText("ℹ️ Fill in the EV details above and click 'Add EV' to add to simulation");
        
        // Button bar
        HBox buttonBar = createButtonBar();
        
        mainContainer.getChildren().addAll(titleLabel, formGrid, statusArea, buttonBar);
        
        Scene scene = new Scene(mainContainer, 450, 400);
        dialogStage.setScene(scene);
    }
    
    private GridPane createInputForm() {
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(15);
        grid.setPadding(new Insets(10));
        
        // Arrival Date
        Label dateLabel = new Label("📅 Arrival Date:");
        dateLabel.setTextFill(Color.WHITE);
        dateLabel.setFont(Font.font("Arial", FontWeight.BOLD, 12));
        
        arrivalDatePicker = new DatePicker();
        arrivalDatePicker.setValue(LocalDate.of(2018, 7, 1)); // Default to simulation start
        arrivalDatePicker.setStyle("-fx-base: #34495e;");
        
        // Arrival Time
        Label timeLabel = new Label("🕐 Arrival Time:");
        timeLabel.setTextFill(Color.WHITE);
        timeLabel.setFont(Font.font("Arial", FontWeight.BOLD, 12));
        
        arrivalTimeField = new TextField("09:00");
        arrivalTimeField.setPromptText("HH:MM (e.g., 14:30)");
        arrivalTimeField.setStyle("-fx-base: #34495e; -fx-text-fill: white;");
          // Departure Date
        Label departureDateLabel = new Label("📅 Departure Date:");
        departureDateLabel.setTextFill(Color.WHITE);
        departureDateLabel.setFont(Font.font("Arial", FontWeight.BOLD, 12));
        
        departureDatePicker = new DatePicker();
        departureDatePicker.setValue(LocalDate.of(2018, 7, 1)); // Default to simulation start
        departureDatePicker.setStyle("-fx-base: #34495e;");
        
        // Departure Time
        Label departureTimeLabel = new Label("🕐 Departure Time:");
        departureTimeLabel.setTextFill(Color.WHITE);
        departureTimeLabel.setFont(Font.font("Arial", FontWeight.BOLD, 12));
        
        departureTimeField = new TextField("13:00");
        departureTimeField.setPromptText("HH:MM (e.g., 16:30)");
        departureTimeField.setStyle("-fx-base: #34495e; -fx-text-fill: white;");
        
        // Energy Needed
        Label energyLabel = new Label("🔋 Energy Needed (kWh):");
        energyLabel.setTextFill(Color.WHITE);
        energyLabel.setFont(Font.font("Arial", FontWeight.BOLD, 12));
        
        energyField = new TextField("20.0");
        energyField.setPromptText("kWh (e.g., 25.5)");
        energyField.setStyle("-fx-base: #34495e; -fx-text-fill: white;");
          // Add to grid
        grid.add(dateLabel, 0, 0);
        grid.add(arrivalDatePicker, 1, 0);
        grid.add(timeLabel, 0, 1);
        grid.add(arrivalTimeField, 1, 1);
        grid.add(departureDateLabel, 0, 2);
        grid.add(departureDatePicker, 1, 2);
        grid.add(departureTimeLabel, 0, 3);
        grid.add(departureTimeField, 1, 3);
        grid.add(energyLabel, 0, 4);
        grid.add(energyField, 1, 4);
        
        return grid;
    }
    
    private HBox createButtonBar() {
        HBox buttonBar = new HBox(10);
        buttonBar.setAlignment(Pos.CENTER);
        
        Button addButton = new Button("✅ Add EV");
        addButton.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-weight: bold;");
        addButton.setPrefWidth(100);
        // addButton.setOnAction(e -> handleAddEV());
        
        Button cancelButton = new Button("❌ Cancel");
        cancelButton.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-weight: bold;");
        cancelButton.setPrefWidth(100);
        cancelButton.setOnAction(e -> handleCancel());
        
        buttonBar.getChildren().addAll(addButton, cancelButton);
        return buttonBar;
    }
      private void handleAddEV() {
        try {
            // Validate inputs
            String arrivalDate = arrivalDatePicker.getValue().toString();
            String arrivalTime = arrivalTimeField.getText().trim();
            String departureDate = departureDatePicker.getValue().toString();
            String departureTime = departureTimeField.getText().trim();
            
            // Validate time format
            try {
                LocalTime.parse(arrivalTime, DateTimeFormatter.ofPattern("HH:mm"));
                LocalTime.parse(departureTime, DateTimeFormatter.ofPattern("HH:mm"));
            } catch (DateTimeParseException e) {
                showError("❌ Invalid time format. Please use HH:MM (e.g., 14:30)");
                return;
            }
            
            // Validate that departure is after arrival
            try {
                LocalDate arrDate = LocalDate.parse(arrivalDate);
                LocalDate depDate = LocalDate.parse(departureDate);
                LocalTime arrTime = LocalTime.parse(arrivalTime);
                LocalTime depTime = LocalTime.parse(departureTime);
                
                // Convert to datetime for comparison
                if (depDate.isBefore(arrDate) || 
                    (depDate.isEqual(arrDate) && !depTime.isAfter(arrTime))) {
                    showError("❌ Departure time must be after arrival time");
                    return;
                }
            } catch (Exception e) {
                showError("❌ Error validating dates: " + e.getMessage());
                return;
            }
            
            // Validate energy
            double energy;
            try {
                energy = Double.parseDouble(energyField.getText().trim());
                if (energy <= 0 || energy > 100) {
                    showError("❌ Energy must be between 0.1 and 100 kWh");
                    return;
                }
            } catch (NumberFormatException e) {
                showError("❌ Invalid energy. Please enter a number (e.g., 25.0)");
                return;
            }
            
            // Create result
            result = new EVData(arrivalDate, arrivalTime, departureDate, departureTime, energy);
            confirmed = true;
            
            statusArea.setText("✅ EV data validated successfully! Adding to simulation...");
            
            // Close dialog after short delay
            Thread.sleep(500);
            dialogStage.close();
            
        } catch (Exception e) {
            showError("❌ Error: " + e.getMessage());
        }
    }
    
    private void handleCancel() {
        confirmed = false;
        dialogStage.close();
    }
    
    private void showError(String message) {
        statusArea.setText(message);
        statusArea.setStyle("-fx-control-inner-background: #e74c3c; -fx-text-fill: white;");
        
        // Reset style after 3 seconds
        new Thread(() -> {
            try {
                Thread.sleep(3000);
                javafx.application.Platform.runLater(() -> {
                    statusArea.setStyle("-fx-control-inner-background: #34495e; -fx-text-fill: white;");
                });
            } catch (InterruptedException ignored) {}
        }).start();
    }
    
    public boolean showAndWait() {
        dialogStage.showAndWait();
        return confirmed;
    }
    
    public EVData getResult() {
        return result;
    }
}
