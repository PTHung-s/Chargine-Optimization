import java.util.ArrayList;
import java.util.List;

import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

/**
 * ChartManager handles the creation and management of cost comparison charts
 * Manages chart data, display windows, and navigation controls
 */
public class ChartManager {
    
    // Chart components
    private LineChart<Number, Number> costChart;
    private XYChart.Series<Number, Number> optCostSeries;
    private XYChart.Series<Number, Number> fcfsCostSeries;
    
    // Chart data storage for full timeline
    private final List<XYChart.Data<Number, Number>> fullOptimalData = new ArrayList<>();
    private final List<XYChart.Data<Number, Number>> fullFcfsData = new ArrayList<>();
    
    // Chart display window settings
    private final int DEFAULT_WINDOW_SIZE = 50;
    private int currentWindowSize = DEFAULT_WINDOW_SIZE;
    private double currentTimeMinutes = 0;
    private boolean followLiveMode = true;
    private int timeCounter = 0;
    
    // Callback interface for logging
    public interface LogCallback {
        void logMessage(String message);
    }
    
    private LogCallback logCallback;
    
    public ChartManager() {
        // Default constructor
    }
    
    public void setLogCallback(LogCallback callback) {
        this.logCallback = callback;
    }
    
    /**
     * Create the cost comparison chart
     */
    public LineChart<Number, Number> createCostComparisonChart() {
        // Creating axes with improved labels
        final NumberAxis xAxis = new NumberAxis();
        final NumberAxis yAxis = new NumberAxis();
        
        xAxis.setLabel("Time (minutes)");
        yAxis.setLabel("Total Cost (€)");
        
        // Enhanced axis styling
        xAxis.setStyle("-fx-text-fill: white; -fx-font-weight: bold;");
        yAxis.setStyle("-fx-text-fill: white; -fx-font-weight: bold;");
        
        // Create chart
        LineChart<Number, Number> lineChart = new LineChart<>(xAxis, yAxis);
        lineChart.setTitle("Total Electricity Cost Comparison Over Time");
        lineChart.setStyle(
            "-fx-background-color: linear-gradient(to bottom, #2c3e50, #34495e);" +
            "-fx-text-fill: white;" +
            "-fx-title-side: top;" +
            "-fx-legend-side: bottom;" +
            "-fx-legend-visible: true;" +
            "-fx-border-color: #3498db;" +
            "-fx-border-width: 2px;" +
            "-fx-border-radius: 8px;" +
            "-fx-background-radius: 8px;" +
            "-fx-effect: dropshadow(gaussian, rgba(52, 152, 219, 0.4), 15, 0.3, 0, 0);"
        );
        
        // Create data series
        optCostSeries = new XYChart.Series<>();
        optCostSeries.setName("Optimization Algorithm");
        
        fcfsCostSeries = new XYChart.Series<>();
        fcfsCostSeries.setName("FCFS Algorithm");
        
        // Add series to chart
        lineChart.getData().addAll(optCostSeries, fcfsCostSeries);
        
        // Enhanced legend styling
        lineChart.setLegendVisible(true);
        
        // Disable chart animations for better performance with real-time data
        lineChart.setAnimated(false);
        lineChart.setCreateSymbols(false); // Disable symbols for better performance
        
        this.costChart = lineChart;
        return lineChart;
    }
    
    /**
     * Create chart navigation controls
     */
    public HBox createChartNavigationControls() {
        HBox controls = new HBox(10);
        controls.setAlignment(Pos.CENTER_LEFT);
        controls.setPadding(new Insets(5));
        controls.setStyle("-fx-background-color: rgba(52, 73, 94, 0.8); -fx-background-radius: 5;");
        
        // Window size control
        Label windowLabel = new Label("Window:");
        windowLabel.setTextFill(Color.WHITE);
        windowLabel.setFont(Font.font("Segoe UI", FontWeight.BOLD, 10));
        
        Slider windowSlider = new Slider(10, 200, DEFAULT_WINDOW_SIZE);
        windowSlider.setShowTickLabels(true);
        windowSlider.setShowTickMarks(true);
        windowSlider.setMajorTickUnit(50);
        windowSlider.setMinorTickCount(4);
        windowSlider.setPrefWidth(120);
        windowSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
            currentWindowSize = newVal.intValue();
            updateChartDisplayWindow();
        });
        
        Label windowValue = new Label(String.valueOf(DEFAULT_WINDOW_SIZE));
        windowValue.setTextFill(Color.LIGHTBLUE);
        windowValue.setFont(Font.font("Segoe UI", FontWeight.BOLD, 10));
        windowSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
            windowValue.setText(String.valueOf(newVal.intValue()));
        });
        
        // Live mode toggle
        Button liveButton = new Button("📍 Live");
        liveButton.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 9px; -fx-padding: 3 8;");
        liveButton.setOnAction(e -> {
            followLiveMode = !followLiveMode;
            if (followLiveMode) {
                liveButton.setText("📍 Live");
                liveButton.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 9px; -fx-padding: 3 8;");
            } else {
                liveButton.setText("⏸ Paused");
                liveButton.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-font-size: 9px; -fx-padding: 3 8;");
            }
            updateChartDisplayWindow();
        });
        
        // Data info label
        Label dataInfo = new Label("Data: 0/0");
        dataInfo.setTextFill(Color.LIGHTGRAY);
        dataInfo.setFont(Font.font("Segoe UI", 9));
        dataInfo.setUserData("dataInfo"); // For easy reference
        
        controls.getChildren().addAll(windowLabel, windowSlider, windowValue, liveButton, dataInfo);
        return controls;
    }
    
    /**
     * Update cost chart with new data
     */
    public void updateCostChart(double optCost, double fcfsCost) {
        try {
            Platform.runLater(() -> {
                if (optCostSeries != null && fcfsCostSeries != null) {
                    // Store data points in full datasets (never remove)
                    XYChart.Data<Number, Number> optDataPoint = new XYChart.Data<>(timeCounter, optCost);
                    XYChart.Data<Number, Number> fcfsDataPoint = new XYChart.Data<>(timeCounter, fcfsCost);
                    
                    fullOptimalData.add(optDataPoint);
                    fullFcfsData.add(fcfsDataPoint);
                    
                    // Update current time for display window calculations
                    currentTimeMinutes = timeCounter;
                    
                    // Update the visible chart window
                    updateChartDisplayWindow();
                    
                    timeCounter++;
                    
                    // Log data point addition for debugging
                    if (timeCounter % 10 == 0 && logCallback != null) { // Log every 10th point to avoid spam
                        logCallback.logMessage(String.format("Chart data: %d points stored, displaying window of %d points", 
                                              fullOptimalData.size(), currentWindowSize));
                    }
                }
            });
        } catch (Exception e) {
            if (logCallback != null) {
                logCallback.logMessage("Error updating cost chart: " + e.getMessage());
            }
        }
    }
    
    /**
     * Update chart display window
     */
    private void updateChartDisplayWindow() {
        try {
            if (fullOptimalData.isEmpty() || fullFcfsData.isEmpty()) {
                return;
            }
            
            // Clear current display data
            optCostSeries.getData().clear();
            fcfsCostSeries.getData().clear();
            
            // Calculate window boundaries
            int totalPoints = fullOptimalData.size();
            int startIndex, endIndex;
            
            if (followLiveMode) {
                // Show most recent data
                endIndex = totalPoints;
                startIndex = Math.max(0, endIndex - currentWindowSize);
            } else {
                // Manual navigation mode - would need additional variables for position
                // For now, default to live mode behavior
                endIndex = totalPoints;
                startIndex = Math.max(0, endIndex - currentWindowSize);
            }
            
            // Add data points to visible series within window
            for (int i = startIndex; i < endIndex && i < fullOptimalData.size(); i++) {
                XYChart.Data<Number, Number> optPoint = new XYChart.Data<>(
                    fullOptimalData.get(i).getXValue(), 
                    fullOptimalData.get(i).getYValue()
                );
                XYChart.Data<Number, Number> fcfsPoint = new XYChart.Data<>(
                    fullFcfsData.get(i).getXValue(), 
                    fullFcfsData.get(i).getYValue()
                );
                
                optCostSeries.getData().add(optPoint);
                fcfsCostSeries.getData().add(fcfsPoint);
            }
            
            // Update data info label
            updateDataInfoLabel(optCostSeries.getData().size(), totalPoints);
            
            // Auto-adjust axes for better viewing if we have enough data
            if (optCostSeries.getData().size() > 5) {
                NumberAxis xAxis = (NumberAxis) costChart.getXAxis();
                NumberAxis yAxis = (NumberAxis) costChart.getYAxis();
                
                // Only auto-range if user hasn't manually zoomed
                if (xAxis.isAutoRanging() && yAxis.isAutoRanging()) {
                    // Let JavaFX handle auto-ranging
                }
            }
            
        } catch (Exception e) {
            if (logCallback != null) {
                logCallback.logMessage("Error updating chart display window: " + e.getMessage());
            }
            e.printStackTrace();
        }
    }
    
    /**
     * Update data info label
     */
    public void updateDataInfoLabel(int visiblePoints, int totalPoints) {
        try {
            // Find the data info label in chart controls
            if (costChart != null && costChart.getParent() instanceof VBox) {
                VBox chartContainer = (VBox) costChart.getParent();
                for (javafx.scene.Node node : chartContainer.getChildren()) {
                    if (node instanceof HBox) {
                        HBox controls = (HBox) node;
                        for (javafx.scene.Node control : controls.getChildren()) {
                            if (control instanceof Label && control.getUserData() != null && 
                                "dataInfo".equals(control.getUserData())) {
                                Label dataInfo = (Label) control;
                                dataInfo.setText(String.format("Data: %d/%d", visiblePoints, totalPoints));
                                break;
                            }
                        }
                        break;
                    }
                }
            }
        } catch (Exception e) {
            // Ignore label update errors
        }
    }
    
    /**
     * Get the cost chart
     */
    public LineChart<Number, Number> getCostChart() {
        return costChart;
    }
    
    /**
     * Reset chart data
     */
    public void resetChart() {
        fullOptimalData.clear();
        fullFcfsData.clear();
        timeCounter = 0;
        if (optCostSeries != null) {
            optCostSeries.getData().clear();
        }
        if (fcfsCostSeries != null) {
            fcfsCostSeries.getData().clear();
        }
    }
}
