import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import javafx.application.Platform;

/**
 * NetworkManager handles TCP socket communication with the Python backend
 * Manages connection, data receiving, and message parsing
 */
public class NetworkManager {
    
    // Network components
    private Socket socket;
    private BufferedReader reader;
    private PrintWriter writer;
    private boolean socketConnected = false;
    private Thread socketThread;
    private Gson gson = new Gson();
    
    // FCFS/EV Management connection (port 8766)
    private Socket fcfsSocket;
    private PrintWriter fcfsWriter;
    private BufferedReader fcfsReader;
    private boolean fcfsConnected = false;
    private Thread fcfsSocketThread;
    
    // Callback interface for handling received data
    public interface DataCallback {
        void onDataReceived(JsonObject data);
        void onFCFSDataReceived(JsonObject data);
        void onConnectionStatusChanged(boolean connected);
        void onLogMessage(String message);
    }
    
    private DataCallback dataCallback;
    
    public NetworkManager(DataCallback callback) {
        this.dataCallback = callback;
    }
    
    /**
     * Connect to the Python backend TCP server
     */
    public void connectToBackend() {
        try {
            logMessage("Connecting to TCP server at localhost:8765...");            
            // Create socket connection
            socket = new Socket("localhost", 8765);
            socket.setKeepAlive(true);
            socket.setSoTimeout(1000);
            
            reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            writer = new PrintWriter(socket.getOutputStream(), true);
            socketConnected = true;
            
            System.out.println("Successfully connected to TCP server");
            logMessage("Connected to TCP server (localhost:8765)");
            logMessage("UI logging system initialized successfully");
            logMessage("⏱Waiting for simulation data...");
            
            // Notify callback about connection status
            if (dataCallback != null) {
                dataCallback.onConnectionStatusChanged(true);
            }
            
            // Start thread to read data
            socketThread = new Thread(this::handleSocketCommunication);
            socketThread.setDaemon(true);
            socketThread.start();
              
        } catch (IOException e) {
            logMessage("Failed to connect (IO error): " + e.getMessage());
            socketConnected = false;
            if (dataCallback != null) {
                dataCallback.onConnectionStatusChanged(false);
            }
        } catch (SecurityException e) {
            logMessage("Failed to connect (security error): " + e.getMessage());
            socketConnected = false;
        } catch (IllegalArgumentException e) {
            logMessage("Failed to connect (invalid connection parameters): " + e.getMessage());
            socketConnected = false;
        }
    }
    
    /**
     * Handle socket communication in a separate thread
     */
    private void handleSocketCommunication() {
        try {
            StringBuilder messageBuffer = new StringBuilder();
            char[] buffer = new char[4096];
            int charsRead;
            long lastDataTime = System.currentTimeMillis();
            
            while (socketConnected) {
                try {
                    // Read from socket with timeout
                    if ((charsRead = reader.read(buffer)) > 0) {
                        lastDataTime = System.currentTimeMillis();
                        messageBuffer.append(buffer, 0, charsRead);
                        
                        // Process complete messages (ending with newline)
                        int newlinePos;
                        while ((newlinePos = messageBuffer.indexOf("\n")) >= 0) {
                            final String message = messageBuffer.substring(0, newlinePos);
                            messageBuffer.delete(0, newlinePos + 1);
                            
                            // Process message on JavaFX thread
                            Platform.runLater(() -> {
                                handleReceivedMessage(message.trim());
                            });
                        }
                    }
                } catch (java.net.SocketTimeoutException e) {
                    // Check if we haven't received data for too long
                    long currentTime = System.currentTimeMillis();
                    if (currentTime - lastDataTime > 30000) { // 30 seconds without data
                        Platform.runLater(() -> {
                            logMessage("No data received for 30 seconds - backend may be inactive");
                        });
                        lastDataTime = currentTime; // Reset timer to avoid spam
                    }
                    // Continue to next iteration for timeout - this is normal
                } catch (java.io.IOException e) {
                    // Handle connection loss gracefully
                    if (socketConnected) {
                        final String errorMsg = e.getMessage();
                        Platform.runLater(() -> {
                            logMessage("Connection lost: " + errorMsg);
                        });
                        break; // Exit loop to trigger reconnection
                    }
                }
            }
        } catch (Exception e) {
            if (socketConnected) {
                final String errorMsg = e.getMessage();
                Platform.runLater(() -> {
                    logMessage("Socket thread error: " + errorMsg);
                });
            }
        } finally {
            socketConnected = false;
            closeConnection();
            
            // Try to reconnect after a delay
            if (!Thread.currentThread().isInterrupted()) {
                try {
                    Thread.sleep(5000);
                    Platform.runLater(() -> {
                        logMessage("Attempting to reconnect...");
                        connectToBackend();
                    });
                } catch (InterruptedException ignored) {
                    // Ignore thread interruption during reconnect
                }
            }
        }
    }
    
    /**
     * Handle received message from backend
     */
    private void handleReceivedMessage(String message) {
        try {
            // Log the first 100 characters of the message for debugging
            logMessage("Received message: " + message.length() + " chars");
            
            if (message.startsWith("{")) {
                // Try to parse JSON
                JsonObject jsonMessage = gson.fromJson(message, JsonObject.class);
                
                if (jsonMessage != null && jsonMessage.has("type")) {
                    String type = jsonMessage.get("type").getAsString();
                    
                    if ("realtime_update".equals(type) && jsonMessage.has("data")) {
                        JsonObject data = jsonMessage.getAsJsonObject("data");
                        
                        // Debug info - log receiving data
                        if (data.has("stations")) {
                            int optCount = 0;
                            int fcfsCount = 0;
                            JsonObject stations = data.getAsJsonObject("stations");

                            for (String key : stations.keySet()) {
                                if (key.startsWith("O")) optCount++;
                                if (key.startsWith("F")) fcfsCount++;
                            }

                            logMessage("Received: " + optCount + " OPT stations, " + fcfsCount + " FCFS stations");
                        } else {
                            logMessage("No stations data in the message");
                        }

                        // Debug info - log EV data
                        if (data.has("evs")) {
                            JsonArray evs = data.getAsJsonArray("evs");
                            logMessage("Received EV data: " + evs.size() + " EVs in NetworkManager");
                        } else {
                            logMessage("No EVs data in the message");
                        }
                        
                        // Send data to callback
                        if (dataCallback != null) {
                            dataCallback.onDataReceived(data);
                        }
                    } else if ("config".equals(type)) {
                        logMessage("Received configuration from server");
                    } else {
                        logMessage("Unknown message type: " + type);
                    }
                } else {
                    logMessage("Invalid JSON message format - missing type");
                }
            } else {
                logMessage("Received non-JSON message: " + message);
            }
        } catch (com.google.gson.JsonParseException e) {
            logMessage("Error parsing JSON message: " + e.getMessage() + "\n" + message.substring(0, Math.min(100, message.length())));
        } catch (IllegalStateException | NullPointerException | ClassCastException e) {
            logMessage("Error handling message data: " + e.getMessage() + "\n" + message.substring(0, Math.min(100, message.length())));
        } catch (StringIndexOutOfBoundsException e) {
            logMessage("Error with message substring: " + e.getMessage());
        }
    }
    
    /**
     * Connect to FCFS data service
     */
    public void connectToFCFS() {
        try {
            logMessage("Connecting to FCFS TCP server at localhost:8766...");
            fcfsSocket = new Socket("localhost", 8766);
            fcfsSocket.setKeepAlive(true);
            fcfsSocket.setSoTimeout(1000);

            fcfsWriter = new PrintWriter(fcfsSocket.getOutputStream(), true);
            fcfsReader = new BufferedReader(new InputStreamReader(fcfsSocket.getInputStream()));
            fcfsConnected = true;

            logMessage("Connected to FCFS data service (localhost:8766)");

            // Start thread to read FCFS data
            fcfsSocketThread = new Thread(this::handleFCFSCommunication);
            fcfsSocketThread.setDaemon(true);
            fcfsSocketThread.start();

        } catch (IOException e) {
            logMessage("Failed to connect to FCFS service: " + e.getMessage());
            fcfsConnected = false;
        }
    }

    /**
     * Handle FCFS socket communication in a separate thread
     */
    private void handleFCFSCommunication() {
        try {
            StringBuilder messageBuffer = new StringBuilder();
            char[] buffer = new char[4096];
            int charsRead;
            long lastDataTime = System.currentTimeMillis();

            while (fcfsConnected) {
                try {
                    // Read from FCFS socket with timeout
                    if ((charsRead = fcfsReader.read(buffer)) > 0) {
                        lastDataTime = System.currentTimeMillis();
                        messageBuffer.append(buffer, 0, charsRead);

                        // Process complete messages (ending with newline)
                        int newlinePos;
                        while ((newlinePos = messageBuffer.indexOf("\n")) >= 0) {
                            final String message = messageBuffer.substring(0, newlinePos);
                            messageBuffer.delete(0, newlinePos + 1);

                            // Process FCFS message on JavaFX thread
                            Platform.runLater(() -> {
                                handleFCFSMessage(message.trim());
                            });
                        }
                    }
                } catch (java.net.SocketTimeoutException e) {
                    // Check if we haven't received FCFS data for too long
                    long currentTime = System.currentTimeMillis();
                    if (currentTime - lastDataTime > 30000) { // 30 seconds without data
                        Platform.runLater(() -> {
                            logMessage("No FCFS data received for 30 seconds");
                        });
                        lastDataTime = currentTime; // Reset timer to avoid spam
                    }
                } catch (java.io.IOException e) {
                    // Handle FCFS connection loss gracefully
                    if (fcfsConnected) {
                        final String errorMsg = e.getMessage();
                        Platform.runLater(() -> {
                            logMessage("FCFS connection lost: " + errorMsg);
                        });
                        break; // Exit loop
                    }
                }
            }
        } catch (Exception e) {
            if (fcfsConnected) {
                final String errorMsg = e.getMessage();
                Platform.runLater(() -> {
                    logMessage("FCFS socket thread error: " + errorMsg);
                });
            }
        } finally {
            fcfsConnected = false;
            // Try to reconnect FCFS after a delay
            if (!Thread.currentThread().isInterrupted()) {
                try {
                    Thread.sleep(5000);
                    Platform.runLater(() -> {
                        logMessage("Attempting to reconnect to FCFS...");
                        connectToFCFS();
                    });
                } catch (InterruptedException ignored) {
                    // Ignore thread interruption during reconnect
                }
            }
        }
    }

    /**
     * Handle received FCFS message
     */
    private void handleFCFSMessage(String message) {
        try {
            logMessage("Received FCFS message: " + message.length() + " chars");

            if (message.startsWith("{")) {
                JsonObject jsonMessage = gson.fromJson(message, JsonObject.class);

                if (jsonMessage != null && jsonMessage.has("type")) {
                    String type = jsonMessage.get("type").getAsString();

                    if ("fcfs_update".equals(type) && jsonMessage.has("data")) {
                        JsonObject data = jsonMessage.getAsJsonObject("data");

                        // Send FCFS data to callback
                        if (dataCallback != null) {
                            dataCallback.onFCFSDataReceived(data);
                        }
                    } else if ("fcfs_config".equals(type)) {
                        logMessage("Received FCFS configuration from server");
                    } else {
                        logMessage("Unknown FCFS message type: " + type);
                    }
                } else {
                    logMessage("Invalid FCFS JSON message format - missing type");
                }
            } else {
                logMessage("Received non-JSON FCFS message: " + message);
            }
        } catch (Exception e) {
            logMessage("Error parsing FCFS message: " + e.getMessage());
        }
    }

    /**
     * Send EV data to backend
     */
    public void sendEVData(String evData) {
        if (fcfsConnected && fcfsWriter != null) {
            fcfsWriter.println(evData);
            logMessage("Sent EV data to backend");
        } else {
            logMessage("FCFS not connected - cannot send data");
        }
    }
    
    /**
     * Close all connections
     */
    public void closeConnection() {
        socketConnected = false;
        fcfsConnected = false;

        try {
            // Close optimization connection
            if (reader != null) reader.close();
            if (writer != null) writer.close();
            if (socket != null) socket.close();

            // Close FCFS connection
            if (fcfsReader != null) fcfsReader.close();
            if (fcfsWriter != null) fcfsWriter.close();
            if (fcfsSocket != null) fcfsSocket.close();
        } catch (IOException e) {
            System.err.println("Error closing connections: " + e.getMessage());
        }

        // Interrupt threads
        if (socketThread != null && socketThread.isAlive()) {
            socketThread.interrupt();
        }
        if (fcfsSocketThread != null && fcfsSocketThread.isAlive()) {
            fcfsSocketThread.interrupt();
        }
    }
    
    /**
     * Check if connected to backend
     */
    public boolean isConnected() {
        return socketConnected;
    }
    
    /**
     * Check if connected to FCFS
     */
    public boolean isFCFSConnected() {
        return fcfsConnected;
    }
    
    /**
     * Send log message to callback
     */
    private void logMessage(String message) {
        if (dataCallback != null) {
            dataCallback.onLogMessage(message);
        }
        System.out.println(message);
    }
}
