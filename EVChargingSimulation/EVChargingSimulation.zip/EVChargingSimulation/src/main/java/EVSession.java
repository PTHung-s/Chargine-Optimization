/**
 * EVSession class for TableView data in the EV Charging Simulation.
 * This class represents an Electric Vehicle charging session.
 */
public class EVSession {
    private final String id;
    private final String arrivalTime;
    private final String departureTime;
    private final double energyNeeded;
    private double energyDelivered; // OPT delivered
    private double progressPercent; // OPT progress
    private double fcfsEnergyDelivered; // NEW: FCFS delivered
    private double fcfsProgressPercent; // NEW: FCFS progress
    private double currentPower;
    private String stationId;
    private String status;
    
    /**
     * Constructor for creating a new EVSession
     */
    public EVSession(String id, String arrivalTime, String departureTime, 
                    double energyNeeded, double energyDelivered, double progressPercent,
                    double fcfsEnergyDelivered, double fcfsProgressPercent,
                    double currentPower, String stationId, String status) {
        this.id = id;
        this.arrivalTime = arrivalTime;
        this.departureTime = departureTime;
        this.energyNeeded = energyNeeded;
        this.energyDelivered = energyDelivered;
        this.progressPercent = progressPercent;
        this.fcfsEnergyDelivered = fcfsEnergyDelivered;
        this.fcfsProgressPercent = fcfsProgressPercent;
        this.currentPower = currentPower;
        this.stationId = stationId;
        this.status = status;
    }
    
    // Getters - needed for TableView's PropertyValueFactory
    public String getId() { return id; }
    public String getArrivalTime() { return arrivalTime; }
    public String getDepartureTime() { return departureTime; }
    public double getEnergyNeeded() { return energyNeeded; }
    public double getEnergyDelivered() { return energyDelivered; }
    public double getProgressPercent() { return progressPercent; }
    public double getCurrentPower() { return currentPower; }
    public String getStationId() { return stationId; }
    public String getStatus() { return status; }

    // NEW getters for FCFS data
    public double getFcfsEnergyDelivered() { return fcfsEnergyDelivered; }
    public double getFcfsProgressPercent() { return fcfsProgressPercent; }
    
    // NEW setters for updating data
    public void setEnergyDelivered(double energyDelivered) { this.energyDelivered = energyDelivered; }
    public void setProgressPercent(double progressPercent) { this.progressPercent = progressPercent; }
    public void setFcfsEnergyDelivered(double fcfsEnergyDelivered) { this.fcfsEnergyDelivered = fcfsEnergyDelivered; }
    public void setFcfsProgressPercent(double fcfsProgressPercent) { this.fcfsProgressPercent = fcfsProgressPercent; }
    public void setCurrentPower(double currentPower) { this.currentPower = currentPower; }
    public void setStationId(String stationId) { this.stationId = stationId; }
    public void setStatus(String status) { this.status = status; }
    
}
