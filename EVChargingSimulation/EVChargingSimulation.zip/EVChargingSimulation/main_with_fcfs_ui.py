"""
Main Simulation with Integrated UI - Including FCFS
Runs both optimization and FCFS EV charging simulation with real-time UI monitoring
"""

import threading
import time
from datetime import datetime, timedelta
from data_loader import DataLoader
from session_manager import SessionManager
from simulation_clock import SimulationClock
from optimization import OptimizationSolver
from visualizer import Visualizer
from integrated_charging_ui import IntegratedChargingUI
from simple_tcp_sender import SimpleTCPDataSender
from fcfs_manager import FCFSChargingManager
from fcfs_data_sender import FCFSDataSender
import queue

def main_with_fcfs_ui():
    """Main simulation function with integrated UI - including FCFS"""
    print("🔋 EV Charging Simulation - Optimization vs FCFS")
    print("=" * 60)
    
    # Initialize components
    data_loader = DataLoader()
    session_manager = SessionManager()
    optimizer = OptimizationSolver()
    visualizer = Visualizer()
    
    # Initialize FCFS manager
    fcfs_manager = FCFSChargingManager(max_stations=20, max_total_power=300.0)
    
    # Load data
    print("📊 Loading simulation data...")
    try:
        price_data, solar_data, final_gop_data, max_data = data_loader.load_all_data()
        
        # Set price data for session manager (for UI access)
        session_manager.set_price_data(price_data, data_loader)
        
        # Set simulation time range
        start_date = datetime(2018, 7, 1)
        end_date = datetime(2018, 8, 3)
        all_sessions = data_loader.prepare_sessions(final_gop_data, start_date, end_date)
        print(f"✅ Loaded {len(all_sessions)} EV sessions")
        
        # Set simulation time range based on data
        start_time = datetime(2018, 7, 1, 8, 0, 0)  # Start at 8 AM consistently
        end_time = datetime(2018, 8, 3, 23, 59)  # End of simulation (2 days)
        simulation_clock = SimulationClock(start_time, end_time, speed_multiplier=10.0)
        
        # Initialize realtime data senders
        optimization_sender = SimpleTCPDataSender(session_manager, simulation_clock, port=8765)
        fcfs_sender = FCFSDataSender(fcfs_manager, simulation_clock, port=8766)
        
        # Start realtime data senders
        print("🌐 Starting realtime data senders...")
        optimization_sender.start()
        fcfs_sender.start()
        print("✅ Data senders started - UI can connect to localhost:8765 (Opt) and localhost:8766 (FCFS)")
        
    except Exception as e:
        print(f"❌ Failed to load data: {e}")
        return
    
    # Create synchronization objects for UI thread
    ui_ready_event = threading.Event()
    ui_error_queue = queue.Queue()
    
    def ui_thread_wrapper():
        """Wrapper function to handle UI initialization with proper error handling"""
        try:
            print("🖥️ Initializing UI Monitor...")
            # Create UI object with FCFS support
            ui = IntegratedChargingUI(session_manager, simulation_clock, fcfs_manager)
            ui_ready_event.set()  # Signal that UI is ready
            print("✅ UI Monitor created successfully")
            # Start the UI main loop
            ui.run()
        except Exception as e:
            ui_error_queue.put(e)
            ui_ready_event.set()  # Signal completion even if failed
            print(f"❌ UI initialization failed: {e}")
    
    # Start UI in separate thread
    ui_thread = threading.Thread(
        target=ui_thread_wrapper,
        name="UI-Thread",
        daemon=False
    )
    ui_thread.start()
    
    # Wait for UI initialization with timeout
    print("⏳ Waiting for UI initialization...")
    if ui_ready_event.wait(timeout=10.0):
        if not ui_error_queue.empty():
            ui_error = ui_error_queue.get()
            print(f"⚠️ UI failed to initialize: {ui_error}")
            print("🔄 Continuing simulation without UI...")
        else:
            print("✅ UI Monitor ready")
    else:
        print("⚠️ UI initialization timeout - continuing without UI")
    
    # Start simulation
    print("🚀 Starting dual simulation...")
    print(f"📅 Simulation starting at: {simulation_clock.get_current_time().strftime('%Y-%m-%d %H:%M:%S')}")
    
    # Control flags
    running = True
    
    # FCFS tracking
    fcfs_processed_sessions = set()
    
    step_counter = 0
    last_optimization_time = None
    
    def optimization_simulation():
        """Run optimization simulation in separate thread"""
        opt_processed_sessions = set()
        
        while running:
            try:
                current_time = simulation_clock.get_current_time()
                
                # Check for new arrivals (optimization)
                new_arrivals = session_manager.check_arrivals(all_sessions, current_time)
                for session in new_arrivals:
                    session_id = session['sessionID']
                    if session_id not in opt_processed_sessions:
                        session_manager.add_active_session(session)
                        opt_processed_sessions.add(session_id)
                        print(f"🎯 OPT: New EV arrived: {session_id[:15]}... at {current_time.strftime('%H:%M')}")
                
                # Maintain stable charging power between optimization runs
                session_manager.maintain_stable_charging_power(current_time)
                
                # Update energy delivered for all active sessions
                session_manager.update_energy_delivered(current_time)
                
                # Remove completed sessions
                completed = session_manager.remove_completed_sessions(current_time)
                for session in completed:
                    print(f"✅ OPT: EV completed: {session['sessionID'][:15]}... at {current_time.strftime('%H:%M')}")
                
                # Get active sessions
                active_sessions = session_manager.get_active_sessions(current_time)
                
                # Run optimization when new EVs arrive
                should_optimize = (
                    len(active_sessions) > 0 and
                    len(new_arrivals) > 0
                )
                
                if should_optimize:
                    print(f"🔄 OPT: RE-OPTIMIZING at {current_time.strftime('%H:%M')} - {len(new_arrivals)} new arrivals")
                    
                    # Prepare sessions for reoptimization
                    sessions_for_lp = session_manager.prepare_sessions_for_reoptimization(current_time)
                    
                    if sessions_for_lp:
                        latest_departure = max([s['disconnectTime_dt'] for s in sessions_for_lp])
                        optimization_horizon_hours = max(1, int((latest_departure - current_time).total_seconds() / 3600))
                        
                        # Prepare optimization data
                        opt_data = optimizer.prepare_data(
                            sessions_for_lp, price_data, solar_data, max_data, 
                            current_time, optimization_horizon_hours
                        )
                        
                        if opt_data:
                            # Solve optimization
                            result = optimizer.solve_with_timeout(opt_data, timeout=30)
                            
                            if result and result.get('success'):
                                # Apply optimization results
                                session_manager.apply_optimization_results(result, current_time)
                                print(f"✅ OPT: Optimization completed successfully")
                            else:
                                print(f"⚠️ OPT: Optimization failed or timeout")
                
                time.sleep(0.1)  # Small delay
                
            except Exception as e:
                print(f"❌ OPT simulation error: {e}")
                time.sleep(1)
    
    def fcfs_simulation():
        """Run FCFS simulation in separate thread"""
        while running:
            try:
                current_time = simulation_clock.get_current_time()
                
                # Check for new arrivals (FCFS)
                for session in all_sessions:
                    session_id = session['sessionID']
                    arrival_time = session['connectionTime_dt']
                    
                    # Check if this session should arrive now
                    time_diff = (current_time - arrival_time).total_seconds()
                    
                    if (0 <= time_diff <= 60 and  # Arrived within last minute
                        session_id not in fcfs_processed_sessions):
                        
                        fcfs_manager.add_session(session)
                        fcfs_processed_sessions.add(session_id)
                        print(f"🚗 FCFS: New EV arrived: {session_id[:15]}... at {current_time.strftime('%H:%M')}")
                
                # Update FCFS charging process
                fcfs_manager.update_charging(current_time)
                
                time.sleep(0.1)  # Small delay
                
            except Exception as e:
                print(f"❌ FCFS simulation error: {e}")
                time.sleep(1)
    
    # Start simulation threads
    opt_thread = threading.Thread(target=optimization_simulation, daemon=True)
    fcfs_thread = threading.Thread(target=fcfs_simulation, daemon=True)
    
    opt_thread.start()
    fcfs_thread.start()
    
    print("✅ Both simulation systems started!")
    
    try:
        # Main simulation loop for clock ticking
        while running:
            # Tick the simulation clock
            simulation_clock.tick()
            
            current_time = simulation_clock.get_current_time()
            step_counter += 1
            
            # Print progress every 100 steps
            if step_counter % 100 == 0:
                opt_active = len(session_manager.active_sessions)
                fcfs_active = len(fcfs_manager.all_sessions)
                print(f"⏰ {current_time.strftime('%Y-%m-%d %H:%M:%S')} | "
                      f"OPT: {opt_active} active | FCFS: {fcfs_active} total")
            
            # Check user input for early termination
            user_input = simulation_clock.check_user_input()
            if user_input and user_input.lower() in ['q', 'quit', 'exit']:
                print("🛑 User requested termination")
                break
            
            # End simulation if past end time
            if current_time >= end_time:
                print("🏁 Simulation completed - reached end time")
                break
                
    except KeyboardInterrupt:
        print("\n🛑 Simulation interrupted by user")
    except Exception as e:
        print(f"❌ Simulation error: {e}")
    finally:
        running = False
        
        # Stop data senders
        optimization_sender.stop()
        fcfs_sender.stop()
        
        # Stop simulation clock
        simulation_clock.stop()
        
        # Wait for threads to complete
        opt_thread.join(timeout=2)
        fcfs_thread.join(timeout=2)
        
        print("✅ All threads stopped")
        print("🏁 Simulation ended")
        
        # Generate final summary
        print("\n📊 FINAL SUMMARY:")
        print("=" * 40)
        
        # Optimization summary
        opt_completed = len(session_manager.completed_sessions)
        opt_total_energy = sum(s.get('energy_delivered', 0) for s in session_manager.completed_sessions)
        print(f"🎯 OPTIMIZATION SYSTEM:")
        print(f"   Completed sessions: {opt_completed}")
        print(f"   Total energy delivered: {opt_total_energy:.2f} kWh")
        
        # FCFS summary
        fcfs_completed = len(fcfs_manager.completed_sessions)
        fcfs_total_energy = sum(s['energy_delivered'] for s in fcfs_manager.completed_sessions)
        fcfs_stats = fcfs_manager.get_statistics()
        print(f"🚗 FCFS SYSTEM:")
        print(f"   Completed sessions: {fcfs_completed}")
        print(f"   Total energy delivered: {fcfs_total_energy:.2f} kWh")
        print(f"   Power utilization: {fcfs_stats.get('power_utilization', 0):.1f}%")
        
        # Wait for UI thread
        ui_thread.join(timeout=5)

if __name__ == "__main__":
    main_with_fcfs_ui()
