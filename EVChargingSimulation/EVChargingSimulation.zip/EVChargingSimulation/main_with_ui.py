"""
Main Simulation with Integrated UI - Including FCFS
Runs both optimization and FCFS EV charging simulation with real-time UI monitoring
"""

import threading
import time
from datetime import datetime, timedelta
from data_loader import DataLoader
from session_manager import SessionManager
from simulation_clock import SimulationClock
from optimization import OptimizationSolver
from visualizer import Visualizer
from integrated_charging_ui import IntegratedChargingUI
from simple_tcp_sender import SimpleTCPDataSender
from fcfs_manager import FCFSChargingManager
from ev_management_service import start_ev_management_service
import queue

def main_with_ui():
    """Main simulation function with integrated UI - including FCFS"""
    print("🔋 EV Charging Simulation - Optimization vs FCFS")
    print("=" * 60)
      # Initialize components
    data_loader = DataLoader()
    session_manager = SessionManager()
    optimizer = OptimizationSolver()
    visualizer = Visualizer()
      # Initialize realtime data sender (simulation_clock will be set later)
    realtime_sender = SimpleTCPDataSender(session_manager, None, port=8765)
      # Load data
    print("📊 Loading simulation data...")
    try:
        price_data, solar_data, final_gop_data, max_data = data_loader.load_all_data()
        
        # Set price data for session manager (for UI access)
        session_manager.set_price_data(price_data, data_loader)
          # Set simulation time range
        start_date = datetime(2018, 7, 1)
        end_date = datetime(2018, 8, 3)
          # Load custom EVs and merge with original data
        print("📝 Checking for custom EV data...")
        try:
            custom_evs = data_loader.load_custom_evs()
            if custom_evs:
                print(f"✅ Found {len(custom_evs)} custom EVs to add")
                # Merge custom EVs with original data (custom_evs is already a list of processed EVs)
                final_gop_data.extend(custom_evs)
                print(f"📊 Total EVs after merging: {len(final_gop_data)}")
            else:
                print("ℹ️ No custom EVs found")
        except Exception as e:
            print(f"⚠️ Could not load custom EVs: {e}")
        
        all_sessions = data_loader.prepare_sessions(final_gop_data, start_date, end_date)
        print(f"✅ Loaded {len(all_sessions)} EV sessions (including custom EVs)")
          # Set simulation time range based on data
        start_time = datetime(2018, 7, 1, 8, 0, 0)  # Start at 8 AM consistently
        end_time = datetime(2018, 8, 3, 23, 59)  # End of simulation (2 days)
        simulation_clock = SimulationClock(start_time, end_time, speed_multiplier=10.0)
        
        print(f"📅 Simulation starting at: {start_time.strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"⚡ Speed multiplier: {simulation_clock.speed_multiplier}x")
        print(f"⚠️  Frontend should connect soon to see from beginning!")
        print(f"🔗 Connect JavaFX to: localhost:8765")
        
        # Initialize FCFS manager after simulation_clock is created
        fcfs_manager = FCFSChargingManager(max_stations=20, max_total_power=300, step_time_seconds=1.0, simulation_clock=simulation_clock)
        print(f"✅ FCFS Manager initialized with {fcfs_manager.max_stations} stations")
          # Set simulation clock and FCFS manager for realtime sender
        realtime_sender.simulation_clock = simulation_clock
        realtime_sender.fcfs_manager = fcfs_manager        # Start realtime data sender
        print("🌐 Starting realtime data sender...")
        sender_thread = realtime_sender.start()
        print("✅ Realtime data sender started - JavaFX can connect to localhost:8765")
        
        # Start EV management service for frontend integration
        print("🔧 Starting EV management service...")
        ev_service = start_ev_management_service()
        print("✅ EV management service started - JavaFX can add EVs via localhost:8766")
    except Exception as e:
        print(f"❌ Failed to load data: {e}")
        return
    
    # Create synchronization objects for UI thread
    ui_ready_event = threading.Event()
    ui_error_queue = queue.Queue()
    def ui_thread_wrapper():
        """Wrapper function to handle UI initialization with proper error handling"""
        try:
            print("🖥️ Initializing UI Monitor...")
            # Create UI object with FCFS support
            ui = IntegratedChargingUI(session_manager, simulation_clock, fcfs_manager)
            ui_ready_event.set()  # Signal that UI is ready immediately after creation
            print("✅ UI Monitor created successfully")
            # Then start the UI main loop
            ui.run()
        except Exception as e:
            ui_error_queue.put(e)
            ui_ready_event.set()  # Signal completion even if failed
            print(f"❌ UI initialization failed: {e}")
    
    # Start UI in separate thread (non-daemon for proper cleanup)
    ui_thread = threading.Thread(
        target=ui_thread_wrapper,
        name="UI-Thread",
        daemon=False  # ✅ Non-daemon thread for proper cleanup
    )
    ui_thread.start()
    
    # Wait for UI initialization with timeout
    print("⏳ Waiting for UI initialization...")
    if ui_ready_event.wait(timeout=10.0):  # ✅ Proper synchronization with timeout
        if not ui_error_queue.empty():
            ui_error = ui_error_queue.get()
            print(f"⚠️ UI failed to initialize: {ui_error}")
            print("🔄 Continuing simulation without UI...")
        else:
            print("✅ UI Monitor ready")
    else:
        print("⚠️ UI initialization timeout - continuing without UI")
      # Start simulation
    print("🚀 Starting simulation...")
    
    # ✅ FIXED: No need to set time again - already set correctly in SimulationClock
    print(f"📅 Simulation starting at: {simulation_clock.get_current_time().strftime('%Y-%m-%d %H:%M:%S')}")
    
    step_counter = 0
    last_optimization_time = None
    
    try:
        while True:
            current_time = simulation_clock.get_current_time()            # Check for new arrivals
            new_arrivals = session_manager.check_arrivals(all_sessions, current_time)
            for session in new_arrivals:
                session_manager.add_active_session(session)
                print(f"🚗 New EV arrived: {session['sessionID'][:15]}... at {current_time.strftime('%H:%M')}")
                  # Add same session to FCFS system
                print(f"🔄 Adding to FCFS: {session['sessionID'][:15]}...")
                # Debug print session details
                print(f"   Session details: connectionTime={session['connectionTime_dt'].strftime('%H:%M')}, energy={session['kWhDelivered']}")
                fcfs_manager.add_ev_session(session)
                print(f"✅ FCFS sessions count: {len(fcfs_manager.all_sessions)}")            # Process FCFS system updates
            if len(fcfs_manager.all_sessions) > 0:
                stats_before = fcfs_manager.get_system_stats()                
                changes_made = fcfs_manager.update_fcfs_charging(current_time)
                
                if changes_made:
                    stats_after = fcfs_manager.get_system_stats()
                    print(f"🔄 FCFS Update: Changes detected - Charging: {stats_after['charging_count']}, Waiting: {stats_after['waiting_count']}")
                    
                    # Print detailed power info for charging sessions  
                    for session_id, session in fcfs_manager.all_sessions.items():
                        if session['status'] == 'charging':
                            remaining_time = (session['departure_time'] - current_time).total_seconds() / 3600
                            print(f"   🔌 {session_id[:15]}... Power: {session['current_power']:.1f}kW, Energy: {session['energy_delivered']:.1f}/{session['energy_needed']:.1f}kWh, Time left: {remaining_time:.1f}h")
            else:
                fcfs_manager.update_fcfs_charging(current_time)
            
            # Maintain stable charging power between optimization runs
            session_manager.maintain_stable_charging_power(current_time)
            
            # Update energy delivered for all active sessions
            session_manager.update_energy_delivered(current_time)
            
            # Remove completed sessions
            completed = session_manager.remove_completed_sessions(current_time)
            for session in completed:
                print(f"✅ EV completed: {session['sessionID'][:15]}... at {current_time.strftime('%H:%M')}")
                
                # Remove from FCFS as well
                fcfs_manager.remove_completed_ev(session['sessionID'])
                
            # Get active sessions
            active_sessions = session_manager.get_active_sessions(current_time)
            
            # 🔧 FIX: Only run optimization when new EVs arrive, not on timer
            should_optimize = (
                len(active_sessions) > 0 and
                len(new_arrivals) > 0  # Only when new EVs arrive
            )
            
            if should_optimize:
                print(f"\n🔄 RE-OPTIMIZING at {current_time.strftime('%H:%M')} - {len(new_arrivals)} new arrivals")
                print(f"   Active EVs: {len(active_sessions)} (including {len(new_arrivals)} new)")
                
                # Prepare sessions for reoptimization
                sessions_for_lp = session_manager.prepare_sessions_for_reoptimization(current_time)
                
                # Calculate optimization horizon
                if sessions_for_lp:
                    lastest_departure = max([s['disconnectTime_dt'] for s in sessions_for_lp])
                    optimization_horizon_hours = max(1, int((lastest_departure - current_time).total_seconds() / 3600))
                    
                    print(f"   Horizon: {current_time.strftime('%H:%M')} to {lastest_departure.strftime('%H:%M')}")
                    print(f"   Duration: {optimization_horizon_hours} hours")
                    
                    # Prepare optimization data
                    opt_data = optimizer.prepare_data(
                        sessions_for_lp, price_data, solar_data, max_data, 
                        current_time, optimization_horizon_hours
                    )
                    
                    if opt_data:
                        print(f"\n⚡ SOLVING OPTIMIZATION...")
                          # Run optimization
                        opt_result = optimizer.solve_optimization(opt_data)
                        fcfs_result = optimizer.solve_fcfs(opt_data)
                        
                        # Apply results to real sessions
                        session_manager.apply_optimization_results(opt_result, current_time)
                        session_manager.update_sessions_after_reoptimization(sessions_for_lp)

                        last_optimization_time = current_time
                        
                        print(f"✅ Optimization completed - Status: {opt_result.get('status', 'Unknown')}")
              # Console display every 30 steps (reduce console spam)
            step_counter += 1
            if step_counter % 30 == 0:
                print(f"\n📊 SIMULATION STATUS - {current_time.strftime('%H:%M:%S')}")
                print(f"   Active EVs: {len(active_sessions)}")
                print(f"   Completed: {len(session_manager.completed_sessions)}")
                  # FCFS status
                fcfs_stats = fcfs_manager.get_system_stats()
                fcfs_detailed = fcfs_manager.get_statistics()
                print(f"   FCFS: {fcfs_stats['charging_count']} charging, {fcfs_stats['waiting_count']} waiting")
                print(f"   FCFS Power: {fcfs_detailed['total_power']:.1f}kW / {fcfs_manager.max_total_power}kW ({fcfs_detailed['power_utilization']:.1f}%)")
                
                if active_sessions:
                    total_energy = sum(s.get('energy_delivered', 0) for s in active_sessions)
                    total_power = sum(s.get('current_charging_power', 0) for s in active_sessions)
                    print(f"   Total Energy Delivered: {total_energy:.1f} kWh")
                    print(f"   Total Charging Power: {total_power:.1f} kW")
            
            # Advance simulation time
            simulation_clock.tick()
            
            # Handle user commands
            user_input = simulation_clock.check_user_input()
            if user_input:
                if user_input.startswith('s'):
                    try:
                        new_speed = int(user_input[1:])
                        simulation_clock.set_speed(new_speed)
                        print(f"⚡ Speed changed to {new_speed}x")
                    except ValueError:
                        print("❌ Invalid speed. Use 's<number>' (e.g., 's20')")
                elif user_input == 'q':
                    print("🛑 Simulation terminated by user")
                    break
                elif user_input == 'status':
                    visualizer.display_ev_status_detail(current_time, session_manager)
                else:
                    print("Commands: s<number> (speed), status (show details), q (quit)")
              # Stop condition - end of day or no more sessions
            if current_time.hour >= 20 and len(active_sessions) == 0:
                print(f"\n🏁 Simulation completed at {current_time.strftime('%H:%M')}")
                break
                
    except KeyboardInterrupt:
        print("\n🛑 Simulation interrupted by user")
    except Exception as e:
        print(f"\n❌ Simulation error: {e}")
        import traceback
        traceback.print_exc()
    
    print("\n📈 FINAL SUMMARY:")
    print(f"   Total sessions processed: {len(session_manager.processed_sessions)}")
    print(f"   Completed sessions: {len(session_manager.completed_sessions)}")
    print(f"   Active sessions: {len(session_manager.active_sessions)}")
    
    # FCFS summary
    fcfs_final_stats = fcfs_manager.get_system_stats()
    print(f"   FCFS completed: {fcfs_final_stats['completed_count']}")
    print(f"   FCFS total energy: {fcfs_final_stats['total_energy']:.1f} kWh")
    
    if session_manager.completed_sessions:
        total_energy = sum(s.get('energy_delivered', 0) for s in session_manager.completed_sessions)
        print(f"   Total energy delivered: {total_energy:.1f} kWh")
    
    print("\n🖥️ UI window remains open for monitoring...")
    print("Press Ctrl+C to exit completely")
    
    # Keep the main thread alive so UI stays open with proper cleanup
    try:
        while ui_thread.is_alive():  # ✅ Check if UI thread is still running
            time.sleep(1)
        print("\n🖥️ UI window closed")
    except KeyboardInterrupt:
        print("\n🛑 Shutting down...")
        # Stop realtime data sender
        realtime_sender.stop()
        print("🌐 Realtime data sender stopped")
        # Give UI thread time to cleanup gracefully
        if ui_thread.is_alive():
            print("⏳ Waiting for UI to close...")
            ui_thread.join(timeout=5.0)  # ✅ Graceful shutdown with timeout
            if ui_thread.is_alive():
                print("⚠️ UI thread did not close gracefully")
        print("👋 Goodbye!")

if __name__ == "__main__":
    main_with_ui()
