"""
Simple Simulation Clock Module - Windows Compatible
Manages real-time simulation with adjustable speed
"""

import time
import threading
from datetime import datetime, timedelta
import queue

class SimulationClock:
    def __init__(self, start_time, end_time, speed_multiplier=1.0, tick_interval=0.1):
        self.start_time = start_time
        self.end_time = end_time
        self.speed_multiplier = speed_multiplier
        self.tick_interval = tick_interval  # Real seconds between ticks
        
        self.current_simulation_time = start_time
        self.last_real_time = time.time()
        self.running = True
        
        # Simple command queue for user input
        self.command_queue = queue.Queue()
        self.input_thread = None
        self.start_input_thread()
    
    def start_input_thread(self):
        """Start thread for user input"""
        def input_worker():
            while self.running:
                try:
                    # This will block until user enters something
                    line = input()
                    self.command_queue.put(line.strip())
                except (EOFError, KeyboardInterrupt):
                    break
        
        self.input_thread = threading.Thread(target=input_worker, daemon=True)
        self.input_thread.start()
    
    def get_current_time(self):
        """Get current simulation time"""
        return self.current_simulation_time
    
    def set_current_time(self, new_time):
        """Set current simulation time"""
        self.current_simulation_time = new_time
        self.last_real_time = time.time()  # Reset real time reference
    
    def is_running(self):
        """Check if simulation should continue"""
        return self.running and self.current_simulation_time < self.end_time
    
    def set_speed(self, new_speed):
        """Change simulation speed multiplier"""
        self.speed_multiplier = max(0.1, new_speed)  # Minimum 0.1x speed
    
    def tick(self):
        """Advance simulation time by one tick"""
        current_real_time = time.time()
        real_elapsed = current_real_time - self.last_real_time
        
        # Calculate simulation time advancement
        sim_time_advance = real_elapsed * self.speed_multiplier
        
        # Advance simulation time (in seconds, then convert to timedelta)
        self.current_simulation_time += timedelta(seconds=sim_time_advance)
        self.last_real_time = current_real_time
        
        # Sleep to maintain tick rate
        time.sleep(self.tick_interval)
    
    def check_user_input(self):
        """Check for user input without blocking"""
        try:
            return self.command_queue.get_nowait()
        except queue.Empty:
            return None
    
    def stop(self):
        """Stop the simulation"""
        self.running = False