"""
Data Loader Module
Handles loading and processing of all input data including custom EVs
"""

import json
from datetime import datetime, timedelta
from ev_input_manager import EVInputManager

class DataLoader:
    def __init__(self):
        self.base_path = ""
        # Initialize EV input manager for custom EVs
        self.ev_input_manager = EVInputManager()
        self.ev_input_manager.load_custom_evs()  # Load any existing custom EVs
        total_custom_evs = sum(len(evs) for evs in self.ev_input_manager.custom_evs.values())
        print(f"📝 Loaded {total_custom_evs} custom EVs")
    
    def load_all_data(self):
        """Load all required data files"""
        try:
            with open(f"{self.base_path}Loc_data_price/price.json", "r") as f:
                price_data = json.load(f)
            
            with open(f"{self.base_path}Loc_solar/gop_solar.json", "r") as f:
                solar_data = json.load(f)
            
            with open(f"{self.base_path}caltech/final_gop.json", "r") as f:
                final_gop_data = json.load(f)
            
            with open(f"{self.base_path}caltech/max.json", "r") as f:
                max_data = json.load(f)
            
            return price_data, solar_data, final_gop_data, max_data
        
        except FileNotFoundError as e:
            print(f"Error loading data files: {e}")
            raise
    
    def parse_time(self, time_str):
        """Convert time string to datetime object"""
        return datetime.strptime(time_str.replace("GMT", "").strip(), "%a, %d %b %Y %H:%M:%S")
    
    def filter_price_data(self, price_data, start_date, end_date):
        """Filter price data for simulation period"""
        filtered = {}
        for k, v in price_data.items():
            try:
                dt = datetime.strptime(k, "%Y-%m-%d")
                if start_date <= dt <= end_date:
                    filtered[k] = v
            except Exception:
                continue
        return filtered
    
    def filter_solar_data(self, solar_data, start_date, end_date):
        """Filter solar data for simulation period"""
        filtered = {}
        for k, v in solar_data.items():
            try:
                dt = datetime.strptime(k, "%Y%m%d")
                if start_date <= dt <= end_date:
                    filtered[k] = v
            except Exception:
                continue
        return filtered
    
    def prepare_sessions(self, final_gop_data, start_date, end_date):
        """Prepare and sort EV sessions by arrival time, including custom EVs"""
        all_sessions = []
        
        # Collect sessions from original data for date range
        for date_key, sessions in final_gop_data.items():
            try:
                date_obj = datetime.strptime(date_key, "%d-%b-%Y")
                if start_date <= date_obj <= end_date:
                    for session in sessions:
                        # Add parsed times for easier processing
                        session['connectionTime_dt'] = self.parse_time(session['connectionTime'])
                        session['disconnectTime_dt'] = self.parse_time(session['disconnectTime'])
                        session['remaining_energy'] = session['kWhDelivered']  # Track remaining energy needed
                        session['is_custom'] = False  # Mark as original data
                        all_sessions.append(session)
            except Exception:
                continue
        
        # Add custom EVs for the date range
        custom_count = 0
        current_date = start_date
        while current_date <= end_date:
            custom_evs = self.ev_input_manager.get_custom_evs_for_date(current_date)
            for custom_ev in custom_evs:
                # Convert custom EV to same format as original sessions
                custom_session = custom_ev.copy()
                custom_session['connectionTime_dt'] = datetime.strptime(custom_ev['connectionTime'], '%a, %d %b %Y %H:%M:%S GMT')
                custom_session['disconnectTime_dt'] = datetime.strptime(custom_ev['disconnectTime'], '%a, %d %b %Y %H:%M:%S GMT')
                custom_session['remaining_energy'] = custom_ev['kWhDelivered']
                custom_session['is_custom'] = True  # Mark as custom data
                all_sessions.append(custom_session)
                custom_count += 1
            current_date += timedelta(days=1)
        
        # Sort by connection time
        all_sessions.sort(key=lambda x: x['connectionTime_dt'])
        
        if custom_count > 0:
            print(f"✅ Integrated {custom_count} custom EVs into simulation")
            
        print(f"📊 Total sessions prepared: {len(all_sessions)} ({len(all_sessions) - custom_count} original + {custom_count} custom)")
        
        return all_sessions
    
    def build_optimization_data(self, active_sessions, current_time, end_time, price_data, solar_data, max_data):
        """Build optimization problem data for current active sessions"""
        
        # Calculate time horizon
        T_hours = int((end_time - current_time).total_seconds() / 3600) + 1
        
        # Build price vector
        p_grid = []
        time_cursor = current_time
        for t in range(T_hours):
            day_str = time_cursor.strftime("%Y-%m-%d")
            hour_index = time_cursor.hour
            price = price_data.get(day_str, [0]*24)[hour_index] if day_str in price_data else 0
            price = price / 1000  # Convert to appropriate units
            p_grid.append(price)
            time_cursor += timedelta(hours=1)
        
        # Build renewable energy vector
        R = []
        time_cursor = current_time
        for t in range(T_hours):
            solar_key = time_cursor.strftime("%Y%m%d")
            hour_index = time_cursor.hour
            if solar_key in solar_data:
                R_val = solar_data[solar_key][hour_index]["R(i)"]
            else:
                R_val = 0
            R.append(R_val)
            time_cursor += timedelta(hours=1)
        
        # Build availability matrix A
        A_matrix = []
        L_req = []
        session_ids = []
        
        for session in active_sessions:
            session_start = max(session['connectionTime_dt'], current_time)
            session_end = session['disconnectTime_dt']
            
            # Calculate availability for each time slot
            availability = []
            time_cursor = current_time
            for t in range(T_hours):
                slot_start = time_cursor
                slot_end = time_cursor + timedelta(hours=1)
                
                # Calculate overlap fraction
                effective_start = max(slot_start, session_start)
                effective_end = min(slot_end, session_end)
                
                if effective_end > effective_start:
                    fraction = (effective_end - effective_start).total_seconds() / 3600.0
                    fraction = min(fraction, 1.0)
                else:
                    fraction = 0.0
                
                availability.append(fraction)
                time_cursor += timedelta(hours=1)
            
            A_matrix.append(availability)
            L_req.append(session['remaining_energy'])
            session_ids.append(session['sessionID'])
        
        return {
            'T': T_hours,
            'N': len(active_sessions),
            'A': A_matrix,
            'L_req': L_req,
            'session_ids': session_ids,
            'p_grid': p_grid,
            'R': R,
            's': max_data['doubled_max_rate'],
            'eta': 0.9,
            'C_grid': 300,  # Grid capacity
            'delta_t': 1,   # 1 hour time slots
            'current_time': current_time,
            'end_time': end_time
        }
    
    def get_hourly_price(self, price_data, datetime_obj):
        """Get electricity price for specific datetime"""
        try:
            day_str = datetime_obj.strftime("%Y-%m-%d")
            hour_index = datetime_obj.hour
            
            if day_str in price_data and 0 <= hour_index < len(price_data[day_str]):
                return price_data[day_str][hour_index]
            else:
                return 0.0  # Return 0 if no data available
        except Exception as e:
            print(f"Error getting hourly price: {e}")
            return 0.0
            
    def get_price_reason(self, price_data, datetime_obj):
        """Get charging reason based on electricity price"""
        try:
            current_price = self.get_hourly_price(price_data, datetime_obj)
            
            # Get day's price range for comparison
            day_str = datetime_obj.strftime("%Y-%m-%d")
            if day_str in price_data:
                day_prices = price_data[day_str]
                min_price = min(day_prices)
                max_price = max(day_prices)
                avg_price = sum(day_prices) / len(day_prices)
                
                # Categorize the price
                if current_price <= min_price + (max_price - min_price) * 0.25:
                    return "💚 Low Price"
                elif current_price <= avg_price:
                    return "🟡 Medium Price"
                elif current_price <= min_price + (max_price - min_price) * 0.75:
                    return "🟠 High Price"
                else:
                    return "🔴 Peak Price"
            
            return "❓ Unknown"
        except Exception:
            return "❓ Unknown"
    
    def get_electricity_price(self, price_data, time_dt):
        """Get electricity price for a specific datetime"""
        day_str = time_dt.strftime("%Y-%m-%d")
        hour_index = time_dt.hour
        
        if day_str in price_data and 0 <= hour_index < 24:
            # Giá điện được lưu dưới dạng mảng 24 giá trị (0-23 giờ)
            price = price_data[day_str][hour_index]
            return price / 1000  # Convert to appropriate units
        return 0.0  # Default price if not found
    
    def load_sessions_data(self):
        """Load EV charging sessions data"""
        try:
            with open(f"{self.base_path}caltech/final_gop.json", "r") as f:
                final_gop_data = json.load(f)
            
            # Use first week of January 2019 for simulation
            start_date = datetime(2019, 1, 1)
            end_date = datetime(2019, 1, 7)
            
            sessions = self.prepare_sessions(final_gop_data, start_date, end_date)
            print(f"✅ Loaded {len(sessions)} EV sessions")
            return sessions
            
        except FileNotFoundError as e:
            print(f"❌ Error loading sessions data: {e}")
            # Return empty list if file not found
            return []
        except Exception as e:
            print(f"❌ Error processing sessions data: {e}")
            return []
    
    def load_price_data(self):
        """Load electricity price data"""
        try:
            with open(f"{self.base_path}Loc_data_price/price.json", "r") as f:
                price_data = json.load(f)
            
            # Convert to hourly price mapping (0-23 hours)
            hourly_prices = {}
            for hour in range(24):
                # Use first available price or default
                if price_data:
                    first_day = list(price_data.keys())[0]
                    day_prices = price_data[first_day]
                    if hour < len(day_prices):
                        hourly_prices[hour] = day_prices[hour]
                    else:
                        hourly_prices[hour] = 50.0  # Default price
                else:
                    hourly_prices[hour] = 50.0  # Default price
                    
            print(f"✅ Loaded price data for 24 hours")
            return hourly_prices
            
        except FileNotFoundError as e:
            print(f"❌ Error loading price data: {e}")
            # Return default hourly prices
            return {hour: 50.0 for hour in range(24)}
        except Exception as e:
            print(f"❌ Error processing price data: {e}")
            return {hour: 50.0 for hour in range(24)}
    def load_custom_evs(self):
        """Load custom EVs from custom_evs.json file"""
        try:
            self.ev_input_manager.load_custom_evs()
            custom_evs_dict = self.ev_input_manager.custom_evs
            
            if not custom_evs_dict:
                return []
            
            # Count total EVs across all dates
            total_evs = sum(len(evs) for evs in custom_evs_dict.values())
            print(f"📝 Processing {total_evs} custom EVs...")
            
            # Convert custom EV format to simulation format
            processed_evs = []
            for date_key, custom_evs in custom_evs_dict.items():
                for custom_ev in custom_evs:
                # Convert to the format expected by the simulation
                    processed_ev = {
                    "userID": custom_ev["userID"],
                    "sessionID": custom_ev["sessionID"],
                    "kWhDelivered": custom_ev["kWhDelivered"],
                    "connectionTime": custom_ev["connectionTime"],
                    "disconnectTime": custom_ev["disconnectTime"],
                    "doneChargingTime": custom_ev["doneChargingTime"],
                    "stationID": custom_ev["stationID"],
                    "clusterID": custom_ev["clusterID"],
                    "timezone": custom_ev["timezone"]
                    }
                processed_evs.append(processed_ev)
                
            print(f"✅ Successfully processed {len(processed_evs)} custom EVs")
            return processed_evs
            
        except Exception as e:
            print(f"⚠️ Error loading custom EVs: {e}")
            return []
    
    def reload_and_merge_custom_evs(self, existing_sessions):
        """Reload custom EVs and merge with existing sessions"""
        try:
            # Load fresh custom EVs
            custom_evs = self.load_custom_evs()
            
            if not custom_evs:
                print("ℹ️ No custom EVs to reload")
                return existing_sessions, 0
            
            # Check for new EVs (not already in existing sessions)
            existing_session_ids = {session['sessionID'] for session in existing_sessions}
            new_evs = [ev for ev in custom_evs if ev['sessionID'] not in existing_session_ids]
            
            if not new_evs:
                print("ℹ️ No new custom EVs found")
                return existing_sessions, 0
            
            # Convert new custom EVs to session format
            new_sessions = []
            for ev in new_evs:
                session = self.prepare_single_session(ev)
                if session:
                    new_sessions.append(session)
            
            print(f"✅ Loaded {len(new_sessions)} new custom EV sessions")
            
            # Merge with existing sessions
            merged_sessions = existing_sessions + new_sessions
            
            return merged_sessions, len(new_sessions)
            
        except Exception as e:
            print(f"❌ Error reloading custom EVs: {e}")
            return existing_sessions, 0

    def prepare_single_session(self, session_data):
        """Convert single session data to simulation format"""
        try:
            connection_time = self.parse_time(session_data['connectionTime'])
            disconnect_time = self.parse_time(session_data['disconnectTime'])
            done_charging_time = self.parse_time(session_data['doneChargingTime'])
            
            return {
                'sessionID': session_data['sessionID'],
                'connectionTime_dt': connection_time,
                'disconnectTime_dt': disconnect_time,
                'doneChargingTime_dt': done_charging_time,
                'kWhDelivered': session_data['kWhDelivered'],
                'userID': session_data.get('userID', ''),
                'stationID': session_data.get('stationID', ''),
                'remaining_energy': session_data['kWhDelivered'],
                'energy_delivered': 0.0,
                'current_charging_power': 0.0
            }
        except Exception as e:
            print(f"❌ Error preparing session {session_data.get('sessionID', 'unknown')}: {e}")
            return None
