"""
Demo script for EV Input functionality
Shows how to add custom EVs to the simulation
"""

from datetime import datetime, timedelta
from ev_input_manager import EVInputManager
from ev_input_ui import quick_add_ev
import sys

def demo_basic_usage():
    """Demo basic EV input functionality"""
    print("🚀 EV INPUT DEMO - Basic Usage")
    print("=" * 50)
    
    # Create EV input manager
    ev_manager = EVInputManager()
    ev_manager.load_custom_evs()
    
    print(f"Current custom EVs: {len(ev_manager.custom_evs)}")
    
    # Add some example EVs
    examples = [
        {
            "name": "Morning Commuter",
            "arrival": datetime(2018, 7, 1, 8, 30),
            "departure": datetime(2018, 7, 1, 17, 30),
            "energy": 20.0
        },
        {
            "name": "Lunch Visitor", 
            "arrival": datetime(2018, 7, 1, 12, 0),
            "departure": datetime(2018, 7, 1, 14, 0),
            "energy": 8.5
        },
        {
            "name": "Evening Event",
            "arrival": datetime(2018, 7, 1, 18, 0),
            "departure": datetime(2018, 7, 1, 23, 0),
            "energy": 35.0
        }
    ]
    
    print("\\n📝 Adding example EVs...")
    for example in examples:
        try:
            ev = ev_manager.add_custom_ev(
                example["arrival"],
                example["departure"],
                example["energy"]
            )
            print(f"✅ Added {example['name']}")
        except Exception as e:
            print(f"❌ Failed to add {example['name']}: {e}")
    
    # Show summary
    print("\\n" + ev_manager.get_custom_ev_summary())
    
    # Save to file
    ev_manager.save_custom_evs()
    print("\\n💾 Saved to custom_evs.json")

def demo_quick_add():
    """Demo quick add functionality"""
    print("\\n🚀 EV INPUT DEMO - Quick Add")
    print("=" * 50)
    
    # Use quick add function
    examples = [
        ("2018-07-01 09:00", "2018-07-01 15:00", 25.0),
        ("2018-07-01 11:30", "2018-07-01 13:30", 12.0),
        ("2018-07-01 16:00", "2018-07-01 20:00", 18.5),
    ]
    
    for arrival_str, departure_str, energy in examples:
        ev = quick_add_ev(arrival_str, departure_str, energy)
        if ev:
            print(f"✅ Quick added EV: {arrival_str} → {departure_str}, {energy} kWh")

def demo_integration_simulation():
    """Demo how custom EVs integrate with simulation"""
    print("\\n🚀 EV INPUT DEMO - Simulation Integration")
    print("=" * 50)
    
    try:
        from data_loader import DataLoader
        
        # Create data loader (which loads custom EVs automatically)
        data_loader = DataLoader()
        
        # Load simulation data
        print("📊 Loading simulation data...")
        price_data, solar_data, final_gop_data, max_data = data_loader.load_all_data()
        
        # Prepare sessions with custom EVs included
        start_date = datetime(2018, 7, 1)
        end_date = datetime(2018, 7, 2)
        
        print(f"📅 Preparing sessions for {start_date.date()} to {end_date.date()}")
        all_sessions = data_loader.prepare_sessions(final_gop_data, start_date, end_date)
        
        # Show breakdown
        original_sessions = [s for s in all_sessions if not s.get('is_custom', False)]
        custom_sessions = [s for s in all_sessions if s.get('is_custom', False)]
        
        print(f"\\n📊 SESSION BREAKDOWN:")
        print(f"   Original sessions: {len(original_sessions)}")
        print(f"   Custom sessions: {len(custom_sessions)}")
        print(f"   Total sessions: {len(all_sessions)}")
        
        if custom_sessions:
            print(f"\\n🚗 CUSTOM EVS IN SIMULATION:")
            for i, session in enumerate(custom_sessions, 1):
                arrival = session['connectionTime_dt']
                departure = session['disconnectTime_dt']
                print(f"   {i}. {arrival.strftime('%H:%M')} → {departure.strftime('%H:%M')}, {session['kWhDelivered']} kWh")
        
    except ImportError:
        print("❌ Could not import data_loader - simulation integration demo skipped")
    except Exception as e:
        print(f"❌ Error in simulation integration demo: {e}")

def demo_interactive_ui():
    """Demo interactive UI"""
    print("\\n🚀 EV INPUT DEMO - Interactive UI")
    print("=" * 50)
    
    try:
        from ev_input_ui import EVInputUI
        
        print("Starting interactive UI...")
        print("(This will open the interactive menu - you can add EVs manually)")
        
        ui = EVInputUI()
        ui.run()
        
    except KeyboardInterrupt:
        print("\\n👋 Interactive demo cancelled")
    except Exception as e:
        print(f"❌ Error in interactive demo: {e}")

def main():
    """Main demo function"""
    print("🚗 EV CHARGING SIMULATION - CUSTOM EV INPUT DEMO")
    print("=" * 60)
    print("This demo shows how to add custom Electric Vehicle sessions")
    print("to the simulation using the new EV Input functionality.")
    print()
    
    if len(sys.argv) > 1:
        mode = sys.argv[1].lower()
        
        if mode == "basic":
            demo_basic_usage()
        elif mode == "quick":
            demo_quick_add()
        elif mode == "integration":
            demo_integration_simulation()
        elif mode == "interactive":
            demo_interactive_ui()
        else:
            print(f"❌ Unknown mode: {mode}")
            print("Available modes: basic, quick, integration, interactive")
    else:
        # Run all demos
        print("🔄 Running all demos...")
        demo_basic_usage()
        demo_quick_add()
        demo_integration_simulation()
        
        # Ask if user wants interactive demo
        print("\\n" + "="*60)
        answer = input("Would you like to try the interactive UI? (y/n): ").strip().lower()
        if answer in ['y', 'yes']:
            demo_interactive_ui()
        else:
            print("👋 Demo completed!")

if __name__ == "__main__":
    main()
