"""
Real-time Data Sender for EV Charging Simulation
Sends live simulation data to JavaFX application via WebSocket/TCP
"""

import json
import socket
import threading
import time
from datetime import datetime
import websocket
from websocket_server import WebsocketServer

class RealtimeDataSender:
    def __init__(self, session_manager, simulation_clock, port=8765):
        self.session_manager = session_manager
        self.simulation_clock = simulation_clock
        self.port = port
        self.clients = []
        self.server = None
        self.running = False
        
    def start_websocket_server(self):
        """Start WebSocket server to send data to JavaFX"""
        def new_client(client, server):
            print(f"📡 New client connected: {client['address']}")
            self.clients.append(client)
            # Send initial data
            self.send_initial_data(client)
            
        def client_left(client, server):
            print(f"📡 Client disconnected: {client['address']}")
            if client in self.clients:
                self.clients.remove(client)
                
        def message_received(client, server, message):
            print(f"📡 Received from client: {message}")
            # Handle commands from JavaFX if needed
            
        try:
            self.server = WebsocketServer(self.port, host='localhost')
            self.server.set_fn_new_client(new_client)
            self.server.set_fn_client_left(client_left)
            self.server.set_fn_message_received(message_received)
            
            print(f"🌐 WebSocket server starting on port {self.port}")
            self.server.run_forever()
        except Exception as e:
            print(f"❌ WebSocket server error: {e}")
            
    def send_initial_data(self, client):
        """Send initial configuration data to new client"""
        initial_data = {
            "type": "config",
            "data": {
                "stations": ["Station_1", "Station_2", "Station_3", "Station_4", "Station_5"],
                "max_power_per_station": 22.0,
                "total_stations": 5
            },
            "timestamp": datetime.now().isoformat()
        }
        self.server.send_message(client, json.dumps(initial_data))
        
    def collect_realtime_data(self):
        """Collect all real-time data from simulation"""
        try:
            current_time = self.simulation_clock.get_current_time()
            active_sessions = self.session_manager.active_sessions
            completed_sessions = self.session_manager.completed_sessions
            
            # Collect EV data
            ev_data = []
            for session in active_sessions:
                needed = session['kWhDelivered']
                delivered = session.get('energy_delivered', 0.0)
                remaining = session.get('remaining_energy', needed)
                power = session.get('current_charging_power', 0.0)
                progress = min((delivered / needed) * 100, 100) if needed > 0 else 100
                
                # Get station assignment
                station_id = self.get_station_assignment(session['sessionID'])
                
                # Determine status
                if progress >= 99.9:
                    status = "COMPLETED"
                elif power > 0.1:
                    status = "CHARGING"
                else:
                    status = "WAITING"
                    
                ev_data.append({
                    "id": session['sessionID'][:15],
                    "full_id": session['sessionID'],
                    "arrival_time": session['connectionTime_dt'].strftime('%H:%M'),
                    "departure_time": session['disconnectTime_dt'].strftime('%H:%M'),
                    "energy_needed": round(needed, 2),
                    "energy_delivered": round(delivered, 2),
                    "energy_remaining": round(remaining, 2),
                    "progress_percent": round(progress, 1),
                    "current_power": round(power, 2),
                    "station_id": station_id,
                    "status": status
                })
                
            # Collect statistics
            charging_sessions = [s for s in active_sessions if s.get('current_charging_power', 0) > 0.1]
            total_energy = sum(session.get('energy_delivered', 0) for session in active_sessions + completed_sessions)
            avg_power = sum(s.get('current_charging_power', 0) for s in charging_sessions) / max(1, len(charging_sessions))
            
            statistics = {
                "active_evs": len(active_sessions),
                "completed_sessions": len(completed_sessions),
                "currently_charging": len(charging_sessions),
                "total_energy_delivered": round(total_energy, 2),
                "average_power": round(avg_power, 2),
                "total_power": round(sum(s.get('current_charging_power', 0) for s in active_sessions), 2)
            }
            
            # Collect station status
            station_status = {}
            for i in range(1, 6):  # 5 stations
                station_id = f"Station_{i}"
                assigned_session = None
                power = 0.0
                status = "AVAILABLE"
                
                for session in active_sessions:
                    if self.get_station_assignment(session['sessionID']) == station_id:
                        assigned_session = session['sessionID'][:15]
                        power = session.get('current_charging_power', 0.0)
                        if power > 0.1:
                            status = "CHARGING"
                        else:
                            status = "OCCUPIED"
                        break
                        
                station_status[station_id] = {
                    "status": status,
                    "assigned_session": assigned_session,
                    "current_power": round(power, 2)
                }
                
            # Get current price
            current_price = self.get_current_price(current_time)
            
            # Combine all data
            realtime_data = {
                "type": "realtime_update",
                "data": {
                    "simulation_time": current_time.strftime('%Y-%m-%d %H:%M:%S'),
                    "speed_multiplier": self.simulation_clock.speed_multiplier,
                    "evs": ev_data,
                    "statistics": statistics,
                    "stations": station_status,
                    "current_price": round(current_price, 2) if current_price else 0.0
                },
                "timestamp": datetime.now().isoformat()
            }
            
            return realtime_data
            
        except Exception as e:
            print(f"❌ Error collecting realtime data: {e}")
            return None
            
    def get_station_assignment(self, session_id):
        """Get station assignment for a session"""
        try:
            station_manager = self.session_manager.station_manager
            station_id = station_manager.get_station_assignment(session_id)
            return station_id if station_id else "Waiting"
        except:
            return "Unknown"
            
    def get_current_price(self, current_time):
        """Get current electricity price"""
        try:
            if hasattr(self.session_manager, 'price_data') and self.session_manager.price_data:
                hour = current_time.hour
                day_of_year = current_time.timetuple().tm_yday
                # Simple price lookup (adjust based on your price data structure)
                return self.session_manager.price_data.get(hour, 50.0)  # Default 50 €/MWh
            return 50.0
        except:
            return 50.0
            
    def start_data_streaming(self):
        """Start the data streaming loop"""
        self.running = True
        
        def stream_data():
            while self.running:
                try:
                    if self.clients:  # Only send if there are connected clients
                        data = self.collect_realtime_data()
                        if data:
                            message = json.dumps(data, indent=2)
                            for client in self.clients[:]:  # Copy list to avoid modification during iteration
                                try:
                                    self.server.send_message(client, message)
                                except Exception as e:
                                    print(f"❌ Error sending to client: {e}")
                                    if client in self.clients:
                                        self.clients.remove(client)
                    
                    time.sleep(1)  # Send data every second
                    
                except Exception as e:
                    print(f"❌ Data streaming error: {e}")
                    time.sleep(5)  # Wait before retrying
                    
        # Start streaming in a separate thread
        streaming_thread = threading.Thread(target=stream_data, daemon=True)
        streaming_thread.start()
        
    def start(self):
        """Start the realtime data sender"""
        # Start data streaming
        self.start_data_streaming()
        
        # Start WebSocket server (this will block)
        server_thread = threading.Thread(target=self.start_websocket_server, daemon=True)
        server_thread.start()
        
        print(f"🚀 Realtime data sender started on port {self.port}")
        print(f"📡 JavaFX can connect to: ws://localhost:{self.port}")
        
        return server_thread
        
    def stop(self):
        """Stop the realtime data sender"""
        self.running = False
        if self.server:
            self.server.shutdown()
        print("🛑 Realtime data sender stopped")
